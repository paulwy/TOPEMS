--
-- PostgreSQL database dump
--


-- Dumped from database version 18.4 (Homebrew)
-- Dumped by pg_dump version 18.4 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: core_finance_currencies; Type: TABLE DATA; Schema: finance; Owner: -
--

COPY finance.core_finance_currencies (id, tenant_id, code, name, symbol, exchange_rate, is_active, created_at, updated_at) FROM stdin;
6ad5936e-4d7c-4148-91eb-275284d6f3f0	\N	CNY	人民币	¥	1.00000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
e5ebd741-22ad-4dbd-ba6f-d998a0a23721	\N	USD	美元	$	7.10000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
cf9b715d-8dd4-422d-a8cd-741fc93121c4	\N	EUR	欧元	€	7.80000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
0becc1f7-26e4-486c-9079-7055ed1a06e4	\N	JPY	日元	¥	0.04700000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
aa4e5b73-b94a-4fc0-a32a-e23380548ad0	\N	HKD	港币	HK$	0.91000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
9aa48b66-25e7-40c7-9931-4aee64124e84	\N	GBP	英镑	£	9.30000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
b9f3dc60-558f-4ff3-8a95-93a0d5c73ba5	\N	AUD	澳元	A$	4.70000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
32adf76a-f459-4020-9513-42dd1b038bab	\N	SGD	新加坡元	S$	5.30000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
d44ad4ae-4835-47eb-81bd-48100480a692	00000000-0000-0000-0000-000000000001	CNY	人民币	¥	1.00000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
cf2e3b67-0157-4921-9653-c60f2fb45a32	00000000-0000-0000-0000-000000000001	USD	美元	$	7.10000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
5f7f3035-c723-4040-95b9-1bc243ef88ac	00000000-0000-0000-0000-000000000001	EUR	欧元	€	7.80000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
a4c1d9fa-6899-4998-8fae-fc3b3daca038	00000000-0000-0000-0000-000000000001	JPY	日元	¥	0.04700000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
67c759ea-ef13-4116-a5cb-19e58d66ac37	00000000-0000-0000-0000-000000000001	HKD	港币	HK$	0.91000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
8c1725cb-8e0f-4ae6-87b8-a9c29379caef	00000000-0000-0000-0000-000000000001	GBP	英镑	£	9.30000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
2ddf4e04-9058-4f64-ae06-4339da9b17a5	00000000-0000-0000-0000-000000000001	AUD	澳元	A$	4.70000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
a02cb1ac-953d-48f5-bd71-e8041baf8372	00000000-0000-0000-0000-000000000001	SGD	新加坡元	S$	5.30000000	t	2026-10-26 14:03:20.516746+08	2026-10-26 14:03:20.516746+08
\.


--
-- Data for Name: core_finance_report_line_map; Type: TABLE DATA; Schema: finance; Owner: -
--

COPY finance.core_finance_report_line_map (id, tenant_id, company_id, report_type, line_code, line_name, line_name_en, line_level, sort_no, direction, match_type, match_value, created_at, updated_at, section, include_unclosed_pl) FROM stdin;
fa62a3e5-561f-41e3-885e-25bbb57ccc83	\N	\N	balance_sheet	monetary_funds	货币资金	Monetary funds	1	1	debit	prefix	1001%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
49b38b8b-9ca6-43ed-b61f-8e15c04f8166	\N	\N	balance_sheet	monetary_funds	货币资金	Monetary funds	1	1	debit	prefix	1002%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
f49b41d6-1af4-4521-9f46-935dd251bef5	\N	\N	balance_sheet	monetary_funds	货币资金	Monetary funds	1	1	debit	prefix	1012%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
f96f8e62-4e96-42c5-ad37-4fdd94597993	\N	\N	balance_sheet	other_receivables	其他应收款	Other receivables	1	6	debit	prefix	1221%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
c6f9ddad-988e-4511-94f0-8980c42d1c65	\N	\N	balance_sheet	trading_financial_assets	交易性金融资产	Trading financial assets	1	2	debit	prefix	1101%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
a053c006-9f90-4c6b-b64d-6badc3e19d69	\N	\N	balance_sheet	notes_receivable	应收票据	Notes receivable	1	3	debit	prefix	1121%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
a8df922e-6fc9-42b1-9f8b-2317f7161b3c	\N	\N	balance_sheet	accounts_receivable	应收账款	Accounts receivable	1	4	debit	prefix	1122%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
c76685c1-9992-4677-80ca-c8e48d8cc8e8	\N	\N	balance_sheet	prepayments	预付款项	Prepayments	1	5	debit	prefix	1123%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
15c11896-4f2f-446f-8489-d6df712277f0	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1401%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
036d2406-adba-4499-814e-009a13b902ae	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1402%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
5026c5d1-5261-4bc9-8f8d-d34e89600b15	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1403%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
49d9e38c-be5f-4fcd-961a-5b93e01bbe35	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1404%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
52dbc18b-d117-4e5d-9f82-9ddc94d57cc3	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1405%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
2c789149-62bb-4d79-b894-028b619206a1	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1408%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
68493a68-8241-4d5d-9ea4-63dae6371bd5	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1411%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
9ab26e44-e9da-4545-ac39-9ee0b91542f6	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	1421%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
f7544a2c-4f09-4562-8841-03a0fa1a9df9	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	5001%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
23a97797-5422-4da4-88f6-1a6db8e50da6	\N	\N	balance_sheet	inventory	存货	Inventory	1	7	debit	prefix	5101%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
119f3cbc-317f-4773-b5b6-f7e468826a4b	\N	\N	balance_sheet	fixed_assets	固定资产	Fixed assets	1	8	debit	prefix	1601%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
021c1c39-635e-47c2-817a-ecb0e7df0159	\N	\N	balance_sheet	fixed_assets	固定资产	Fixed assets	1	8	debit	prefix	1602%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
8792e966-19c7-44d3-b33f-2e6e62b62b50	\N	\N	balance_sheet	construction_in_progress	在建工程	Construction in progress	1	9	debit	prefix	1604%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
7a0dae95-c192-4dde-aa61-9f55b8afb33f	\N	\N	balance_sheet	intangible_assets	无形资产	Intangible assets	1	10	debit	prefix	1701%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
afec7315-a9b2-4687-b90e-38838280785e	\N	\N	balance_sheet	intangible_assets	无形资产	Intangible assets	1	10	debit	prefix	1702%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
b7b2c8a2-aa2a-4da8-abbd-f29c903c9be7	\N	\N	balance_sheet	long_term_deferred_expenses	长期待摊费用	Long-term deferred expenses	1	11	debit	prefix	1801%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	asset	f
e4f69082-d8ec-4696-9a8e-e3bac0f597c6	\N	\N	balance_sheet	short_term_loans	短期借款	Short-term loans	1	20	credit	prefix	2001%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
725a5428-285d-4c7c-9c8f-09d0cae42d92	\N	\N	balance_sheet	notes_payable	应付票据	Notes payable	1	21	credit	prefix	2201%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
ab9446d5-9ce7-4e5f-9925-ddf9aa31ad9d	\N	\N	balance_sheet	accounts_payable	应付账款	Accounts payable	1	22	credit	prefix	2202%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
bf7503d9-06d5-4c7f-b85c-7ae427b6bd7c	\N	\N	balance_sheet	advances_from_customers	预收款项	Advances from customers	1	23	credit	prefix	2203%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
bd19fd8e-4715-403a-8ade-3295670c2028	\N	\N	balance_sheet	payroll_payable	应付职工薪酬	Payroll payable	1	24	credit	prefix	2211%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
9d7d04ee-b310-4f85-b321-33a3860618ca	\N	\N	balance_sheet	taxes_payable	应交税费	Taxes payable	1	25	credit	prefix	2221%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
0b35a01f-b372-487e-bc7e-162dab573f59	\N	\N	balance_sheet	other_payables	其他应付款	Other payables	1	26	credit	prefix	2241%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
beb32775-8705-457d-841d-26e4fe7f71dd	\N	\N	balance_sheet	long_term_loans	长期借款	Long-term loans	1	27	credit	prefix	2501%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	liability	f
b73cfcc2-4282-4d55-aff7-d768e20c21f7	\N	\N	balance_sheet	paid_in_capital	实收资本	Paid-in capital	1	30	credit	prefix	4001%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	equity	f
cc51ebf1-4303-46eb-b11b-657e51def9bb	\N	\N	balance_sheet	capital_reserve	资本公积	Capital reserve	1	31	credit	prefix	4002%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	equity	f
d387ab44-966f-4d7d-a388-1f386f4b6aa2	\N	\N	balance_sheet	surplus_reserve	盈余公积	Surplus reserve	1	32	credit	prefix	4101%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	equity	f
7d77de09-666c-41af-b531-350842f07fe2	\N	\N	balance_sheet	retained_earnings	未分配利润	Retained earnings	1	34	credit	prefix	4104%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	equity	f
54ccd2a2-458f-4ffc-9993-6de520c54fc6	\N	\N	income_statement	operating_revenue	营业收入	Operating revenue	1	1	credit	prefix	6001%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	income	f
c840ac78-cfe8-4ca8-bdce-22bb0b68c1d6	\N	\N	income_statement	operating_revenue	营业收入	Operating revenue	1	1	credit	prefix	6051%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	income	f
bbaa2de2-a382-4166-89dd-bd208a16916c	\N	\N	income_statement	operating_cost	营业成本	Operating cost	1	2	debit	prefix	6401%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
99124151-a000-447a-9c6d-7c91752ee4de	\N	\N	income_statement	operating_cost	营业成本	Operating cost	1	2	debit	prefix	6402%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
251e43a4-0e39-46ba-9b20-5389cf126cd1	\N	\N	income_statement	taxes_and_surcharges	税金及附加	Taxes and surcharges	1	3	debit	prefix	6403%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
80e765fc-442d-41a8-9d16-b02cbf193329	\N	\N	income_statement	selling_expenses	销售费用	Selling expenses	1	4	debit	prefix	6601%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
e39cae67-6586-4447-b55e-72334d8cafb2	\N	\N	income_statement	administrative_expenses	管理费用	Administrative expenses	1	5	debit	prefix	6602%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
35c59572-a43d-4d9d-b887-f425920d5f1a	\N	\N	income_statement	financial_expenses	财务费用	Financial expenses	1	6	debit	prefix	6603%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
68d8856c-265a-4140-abd3-c94bfcd94bb0	\N	\N	income_statement	non_operating_income	营业外收入	Non-operating income	1	7	credit	prefix	6301%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	income	f
f9716718-5143-4341-bcf8-8ac892a0b7b6	\N	\N	income_statement	non_operating_expense	营业外支出	Non-operating expense	1	8	debit	prefix	6711%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
1bd8157a-0626-4045-bd5d-3c5dd4e52ce4	\N	\N	income_statement	income_tax_expense	所得税费用	Income tax expense	1	9	debit	prefix	6801%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	expense	f
ad2ea6d1-04ca-457c-81f2-6cb5b9c2739c	\N	\N	balance_sheet	current_year_profit	本年利润	Current year profit	1	33	credit	prefix	4103%	2026-11-09 18:07:25.377909+08	2026-11-09 18:07:25.377909+08	equity	t
\.


--
-- Data for Name: sync_policies; Type: TABLE DATA; Schema: mobile; Owner: -
--

COPY mobile.sync_policies (id, deleted_at, auto_sync_enabled, conflict_strategy, created_at, sync_interval_minutes, sync_on_network_change, tenant_id, updated_at, user_id) FROM stdin;
a58ea9f8-a47a-4247-8b4a-da4078e3e63d	\N	t	server_wins	2026-11-02 11:38:20.519354+08	15	t	\N	2026-11-07 04:09:01.998679+08	e91e2228-ab9d-4ac3-99f4-fdcd9c723f21
\.


--
-- Data for Name: project_type_configs; Type: TABLE DATA; Schema: pm; Owner: -
--

COPY pm.project_type_configs (id, deleted_at, created_at, default_milestones, default_phases, default_workflow, description, is_active, tenant_id, type_code, type_name, updated_at, name_en) FROM stdin;
22499759-f32b-4ac6-b058-35b410110f06	2026-10-26 20:14:54.837477+08	2026-10-26 20:14:52.394507+08	\N	\N	\N	\N	t	\N	L1-T9	L1 类型v2	2026-10-26 20:14:54.837477+08	\N
\.


--
-- Data for Name: core_menu_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_menu_groups (id, tenant_id, name, code, icon, sort_order, status, created_at, updated_at, deleted_at) FROM stdin;
d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	财务管理分析	finance_analytics	BarChart3	9	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
abca96b5-c469-4769-890f-a709c83b2904	\N	财务管理业务	finance_business	Briefcase	7	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
96e23d67-21e6-4bc6-b1fd-24a35475cf18	\N	财务管理概览	finance_overview	LayoutDashboard	6	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
fbb2b200-54f7-4379-92e3-586141315663	\N	财务管理流程	finance_process	GitBranch	8	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	生产执行分析	mes_analytics	BarChart3	11	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	生产执行业务	mes_business	Briefcase	9	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
38127719-50b2-444f-86fe-4fc20a3fafe7	\N	生产执行概览	mes_overview	LayoutDashboard	8	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	生产执行流程	mes_process	GitBranch	10	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6e920de5-e727-4c1c-a8ab-ac95ee6da1b2	\N	人力资源分析	hrm_analytics	BarChart3	8	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4b11a313-324f-45d8-af76-813ebff97bc0	\N	人力资源业务	hrm_business	Briefcase	6	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6bbb428e-f334-4ddc-8dfa-7db0c86a587e	\N	人力资源概览	hrm_overview	LayoutDashboard	5	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	人力资源流程	hrm_process	GitBranch	7	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
37577e90-7500-4310-bc1b-757d7f146ce9	\N	产品数据分析	pdm_analytics	BarChart3	16	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	产品数据业务	pdm_business	Briefcase	14	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c3d15966-e2cf-4ef9-8465-87097000821d	\N	产品数据概览	pdm_overview	LayoutDashboard	13	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
85324143-b4d0-409e-80c3-14f5095c398f	\N	产品数据流程	pdm_process	GitBranch	15	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	仓储管理分析	wms_analytics	BarChart3	15	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
bc7346a7-b86a-417c-82cd-0337dd065848	\N	仓储管理业务	wms_business	Briefcase	13	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
adcbe5df-0504-4e95-94b0-1233dcc93604	\N	仓储管理概览	wms_overview	LayoutDashboard	12	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
cbf65c4e-0acc-4181-b0f4-03473220867c	\N	仓储管理流程	wms_process	GitBranch	14	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
be53f9f6-6115-40d1-ba7e-d57934a6228b	\N	安全环保分析	ehs_analytics	BarChart3	13	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	安全环保业务	ehs_business	Briefcase	11	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c33cc178-5c5e-4474-b919-a0cf4977294d	\N	安全环保概览	ehs_overview	LayoutDashboard	10	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
16c7ee43-ac8f-4d09-8b47-22b01223fa75	\N	安全环保流程	ehs_process	GitBranch	12	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
78f61b0a-b6c8-4ed2-8cfe-c7068737f7fe	\N	实验室管理分析	lims_analytics	BarChart3	14	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	实验室管理业务	lims_business	Briefcase	12	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d3ca564b-086c-499e-93a3-36bfaff5873d	\N	实验室管理概览	lims_overview	LayoutDashboard	11	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c27d9700-2934-4973-a351-68f34289ed8a	\N	实验室管理设置	lims_settings	Settings	15	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
973dce82-ca38-4813-99a3-8791843cc370	\N	客户关系分析	crm_analytics	BarChart3	10	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
25cb9763-4307-49b9-9b0b-70732600eb34	\N	客户关系业务	crm_business	Briefcase	8	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
380835f0-2eae-49dc-8b1d-12404e4ce73b	\N	客户关系概览	crm_overview	LayoutDashboard	7	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
35cc0691-c927-4690-8aa4-c1bb5c6ccc27	\N	客户关系流程	crm_process	GitBranch	9	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	质量管理分析	qms_analytics	BarChart3	12	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
a7dfc40b-3650-41c8-8750-9ba13d29cf7d	\N	质量管理业务	qms_business	Briefcase	10	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
64930fe3-c66b-43e9-ab8a-6370a62a7d04	\N	质量管理概览	qms_overview	LayoutDashboard	9	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6da00511-bb5d-4eeb-a226-81d24b4fe6ac	\N	质量管理流程	qms_process	GitBranch	11	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
2529cbb4-d27e-4d5f-b4cd-ae279cfbdf62	\N	供应链管理分析	scm_analytics	BarChart3	13	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	供应链管理业务	scm_business	Briefcase	11	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
49fda5bf-c812-4dce-807d-2a37a05bae2c	\N	供应链管理概览	scm_overview	LayoutDashboard	10	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	供应链管理流程	scm_process	GitBranch	12	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ce6cd55f-1377-4574-ae9d-9cc15a03e22b	\N	供应商关系分析	srm_analytics	BarChart3	17	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	供应商关系业务	srm_business	Briefcase	15	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5338990a-ef78-4d0a-8ba5-244b3675233a	\N	供应商关系概览	srm_overview	LayoutDashboard	14	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
abca79a9-d15f-4c40-950b-75aaff9d9b64	\N	供应商关系流程	srm_process	GitBranch	16	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4a281af2-b8c9-494e-a0e2-d48bec0b15c2	\N	供应商关系设置	srm_settings	Settings	18	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
240fb6a1-5509-45dc-9053-d000abb2236d	\N	报表中心业务	report_business	Briefcase	7	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
a7155705-ee27-4e1c-a965-a2646426b3c9	\N	报表中心概览	report_overview	LayoutDashboard	6	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c173f2c7-491a-4388-9e5d-b5bf378c7490	\N	报表中心流程	report_process	GitBranch	8	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
18404d54-5552-439e-a121-19a0a96f3768	\N	资产流程	asset_process	Workflow	54	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
82bce5fe-e7d2-46a9-97e7-75b83570ade4	\N	报表中心设置	report_settings	Settings	10	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
676a32bb-5dbd-4b0d-9c05-6685789fb78b	\N	项目管理分析	pm_analytics	BarChart3	16	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6bbbf37b-84d0-49a9-89f1-f9f0c440eddb	\N	项目管理业务	pm_business	Briefcase	14	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4b775d8c-6659-4082-928a-b9b5bcf7b81a	\N	项目管理概览	pm_overview	LayoutDashboard	13	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
f102cfb6-ff27-44bd-88ec-2389ed0fcc31	\N	项目管理流程	pm_process	GitBranch	15	active	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6e0e0eb1-deab-4462-ba99-667e45705e0d	\N	运输概览	tms_overview	LayoutDashboard	40	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
98a42ca6-5251-4e63-ba51-fcfd5d656dc5	\N	运输主数据	tms_master	Database	41	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
027601c9-4658-4793-b134-166b2711716d	\N	运输业务	tms_business	Truck	42	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
211b7e22-de40-451f-9137-2dd34338d4e6	\N	运输分析	tms_analytics	BarChart3	43	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
784eb3bc-2557-47a7-895d-434a5cb0d41d	\N	ERP 概览	erp_overview	LayoutDashboard	30	active	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
f58f804d-4931-4a05-b224-c0add69d553a	\N	ERP 流程	erp_process	Workflow	31	active	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
17909c55-c149-4dae-8f9f-0d51074a42e7	\N	ERP 业务	erp_business	Briefcase	32	active	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
dbf10a25-081c-436c-81a1-dba1b4311f46	\N	系统概览	admin_overview	FileText	60	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
e03c2f6d-a558-44a2-a5bc-a323dc957f14	\N	系统主数据	admin_master	FileText	61	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
00163a30-8d42-4849-8bb8-abd00601ffab	\N	系统设置	admin_setting	FileText	62	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
aac20b2b-c3e5-4f1e-95a6-56116e9151ba	\N	系统分析	admin_analytics	FileText	63	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	主数据管理	master_data_master	FileText	70	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
d3336cde-1fe3-4a61-8269-ffc46d68dd4c	\N	自动化概览	automation_overview	FileText	80	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
2eeb8ce9-17ba-4af0-abbf-cea4d0c559f3	\N	自动化流程	automation_process	FileText	81	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
b0acf438-ba5c-403f-b853-d0884d19fa8a	\N	自动化分析	automation_analytics	FileText	82	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
1f2148e9-b5ab-46ed-9ab2-174a7d9d532e	\N	自动化设置	automation_setting	FileText	83	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
1d033415-afb5-478a-8714-cf6e4754e716	\N	监控概览	monitor_overview	FileText	90	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
1b44b62a-dfef-46c5-ab76-b900960c0fa4	\N	监控流程	monitor_process	FileText	91	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
073e2ccf-f4aa-4764-a8d5-7a27ca35cb9a	\N	监控业务	monitor_business	FileText	92	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
aed445cb-3309-4ba1-872c-b85810e164cb	\N	监控设置	monitor_setting	FileText	93	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
4f9fa549-037b-4a52-be06-100323c337df	\N	监控分析	monitor_analytics	FileText	94	active	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
be881738-26d7-4782-8dff-0ef8cf1cf090	\N	身份概览	iam_overview	FileText	100	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
20a34097-75fd-4c1f-b015-ce79daddad91	\N	身份主数据	iam_master	FileText	101	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
f7b5b451-10a3-416d-ac06-4678daa89b56	\N	AI 概览	ai_overview	FileText	110	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
d509cf72-6212-4bcf-9654-85b5e394ff1d	\N	AI 流程	ai_process	FileText	111	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
da22f67c-df3e-4b87-a187-492ca92187d5	\N	AI 业务	ai_business	FileText	112	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
597c8817-896f-421c-b04a-af84ccc8efbc	\N	AI 设置	ai_setting	FileText	113	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
fac90620-11a7-431b-bdef-603b4f90360c	\N	集成概览	integration_overview	FileText	120	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
b03246e2-4458-4ec9-9aa2-1776cb15227c	\N	集成主数据	integration_master	FileText	121	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
42994238-38f7-48f5-b40b-a40be68a47a9	\N	集成分析	integration_analytics	FileText	122	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
0b38f8fe-d89f-4273-8bbb-319fb6b63aa1	\N	集成流程	integration_process	FileText	123	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
6afa1624-0a11-4178-974a-d20382ea2639	\N	研发概览	rd_overview	FileText	130	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
6e4cce42-b58f-4d4f-8483-36d582fd7000	\N	研发业务	rd_business	FileText	131	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
7164c85a-3c19-4a14-a0bf-464f2e8fd82b	\N	研发主数据	rd_master	FileText	132	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	研发流程	rd_process	FileText	133	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
19989296-5f8b-47d3-a821-92ad06d7bb1c	\N	研发分析	rd_analytics	FileText	134	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
c4365675-4b37-4028-bd74-71b45b3666ff	\N	研发设置	rd_setting	FileText	135	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e1a73253-f129-428b-b987-8124ccf13b41	\N	通知概览	notification_overview	FileText	140	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
3b69aa66-8301-419e-8ae0-24790fff1f96	\N	通知设置	notification_setting	FileText	141	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
82449dd4-6c16-47ec-815d-80ac9247c5d3	\N	通知分析	notification_analytics	FileText	142	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
056e6540-b643-4fa6-afc6-f7a8440411fd	\N	OA 概览	oa_overview	FileText	150	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
07c6b941-2a7b-4895-be92-860acf2bebda	\N	OA 业务	oa_business	FileText	151	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
f3d373eb-3e80-4c25-a882-5913795f41b5	\N	OA 主数据	oa_master	FileText	152	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
f4eaf662-ac27-4b5a-9e09-865bc7897369	\N	OA 流程	oa_process	FileText	153	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
73cbe878-92b8-4628-bb7c-00589abf44e9	\N	GIS 概览	gis_overview	FileText	160	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
943126fb-5fb8-45d2-9747-51bee009e0e7	\N	GIS 业务	gis_process	FileText	161	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
a5f43871-9da8-45b4-9812-9ed3d382a765	\N	GIS 主数据	gis_master	FileText	162	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
7f1c05e5-7afd-4b0d-9c9b-928cfaa3b81d	\N	插件概览	plugin_overview	FileText	170	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
14ec8c58-ae32-4b5a-b302-8473e6755186	\N	插件设置	plugin_setting	FileText	171	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
68ea6181-fbef-43e1-9345-badee0f036b7	\N	文档概览	doc_overview	FileText	180	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
4c71be4e-c78a-4814-ac9c-bfd0bad732c4	\N	文档管理	doc_master	FileText	181	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
0bf2b4bc-a29f-4ca0-b8b7-80c1e98e7a34	\N	流程概览	workflow_overview	FileText	190	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
61c07c32-97c2-408b-82d4-e4fdb888257a	\N	流程定义	workflow_process	FileText	191	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
10c46b46-c42a-4c05-b1de-0d7cab0ab79f	\N	流程分析	workflow_analytics	FileText	192	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
7824d76b-dfd5-4182-94ed-4f672864ebc3	\N	流程设置	workflow_setting	FileText	193	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
888147a9-20f3-4df2-9f50-0ae6b01fa39d	\N	工单概览	ticket_overview	FileText	200	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
59ff837f-a1ad-4c91-9ebc-b6832b416921	\N	工单业务	ticket_business	FileText	201	active	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	ERP 主数据	erp_master	Database	33	active	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
054803ba-0320-4ef1-a0ad-f152eedfa1ee	\N	ERP 分析	erp_analytics	BarChart3	34	active	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
beecb71f-30a0-442b-9a48-2b02c691a224	\N	ERP 设置	erp_settings	Settings2	35	active	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
4241e3b2-5cb1-419e-927f-2ae3e6384474	\N	资产概览	asset_overview	LayoutDashboard	50	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
ac1a23c2-7bae-49c2-95ab-f0d45410f0f3	\N	资产业务	asset_business	Briefcase	51	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
2f87316c-8422-44ef-b0b0-7bcb5f5e2466	\N	资产主数据	asset_master	Database	52	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
bcccf4f3-a36c-4c80-b2b1-67a37e986933	\N	资产分析	asset_analytics	BarChart3	53	active	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
b97c3e13-3ddf-42d7-a3cc-5af7ff1fd8c0	\N	集成设置	integration_setting	FileText	124	active	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
897c002e-53fd-4758-a922-27703174286b	\N	排产概览	aps_overview	LayoutDashboard	210	active	2026-11-02 14:56:32.960401+08	2026-11-02 14:56:32.960401+08	\N
9913602b-d7d9-4574-80fe-a8e526a346f3	\N	排产业务	aps_business	CalendarCheck	211	active	2026-11-02 14:56:32.960401+08	2026-11-02 14:56:32.960401+08	\N
21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	排产分析	aps_analytics	BarChart3	212	active	2026-11-02 14:56:32.960401+08	2026-11-02 14:56:32.960401+08	\N
acad5cf7-3d3b-4b9d-a0a3-3be115fc43d9	\N	BI 概览	bi_overview	FileText	170	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	BI 分析	bi_analytics	FileText	171	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
c3549484-9146-4b04-84c0-82e90369f3ca	\N	BI 设置	bi_business	FileText	172	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
8873097f-a8d0-42f9-ac54-08bc1444cad3	\N	IM 概览	im_overview	FileText	173	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
079144de-930b-4c7c-8273-71be86fbd72b	\N	IM 业务	im_business	FileText	174	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
7b72a59e-442c-4cf8-a6a4-42ec1f45964f	\N	移动端概览	mobile_overview	FileText	175	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	移动端流程	mobile_process	FileText	176	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
15a872a7-ffa6-4444-8346-849423b31f7f	\N	移动端设置	mobile_business	FileText	177	active	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
\.


--
-- Data for Name: core_menus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_menus (id, tenant_id, group_id, parent_id, name, code, path, icon, sort_order, status, permissions, created_at, updated_at, deleted_at) FROM stdin;
fa5e0017-78f5-476d-a0b0-1843999b6e75	\N	784eb3bc-2557-47a7-895d-434a5cb0d41d	\N	ERP 仪表盘	erp-dashboard	/erp/dashboard	LayoutDashboard	1	active	{"permission": "erp:dashboard:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
e347b463-5c13-45d0-afd9-21b66d6a01bd	\N	f58f804d-4931-4a05-b224-c0add69d553a	\N	销售订单	erp-sales-orders	/erp/sales-orders	FileText	3	active	{"permission": "erp:sales_order:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
6a5e5e5d-894f-4da7-bca3-c79bc27c99b2	\N	f58f804d-4931-4a05-b224-c0add69d553a	\N	采购订单	erp-purchase-order	/erp/purchase-order	ShoppingCart	2	active	{"permission": "erp:purchase_order:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
6f6147ed-b18e-4e2a-82a5-77a161c3b40c	\N	17909c55-c149-4dae-8f9f-0d51074a42e7	\N	用车申请	erp-vehicle-request	/erp/vehicle-request	ClipboardCheck	7	active	{"permission": "erp:vehicle_request:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
bbdb00ce-657b-4d84-bd76-c461c166c3f0	\N	17909c55-c149-4dae-8f9f-0d51074a42e7	\N	预算管理	erp-budget-management	/erp/budget-management	Target	6	active	{"permission": "erp:budget:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
80434227-a00e-4994-9df1-b0262511afb0	\N	17909c55-c149-4dae-8f9f-0d51074a42e7	\N	应收应付	erp-receivable-payable	/erp/receivable-payable	CreditCard	5	active	{"permission": "erp:receivable_payable:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
352887e4-b278-4fb1-a2a3-3e5c6527b000	\N	17909c55-c149-4dae-8f9f-0d51074a42e7	\N	总账管理	erp-general-ledger	/erp/voucher-management	Wallet	4	active	{"permission": "erp:general_ledger:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
5caab559-9125-4d00-891e-665c8b1e9664	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	公告管理	erp-announcement	/erp/announcement	Bell	18	active	{"permission": "erp:announcement:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
061543ed-6f2c-405b-9a72-370e7a628157	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	会议室管理	erp-meeting-room	/erp/meeting-room	Calendar	17	active	{"permission": "erp:meeting_room:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
3ea3f219-8a46-4181-83e1-9d8365cf3e34	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	会计科目	erp-accounting-management	/erp/accounting-management	FileSpreadsheet	16	active	{"permission": "erp:accounting_subject:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
bc4c48f8-2996-479f-b7f1-767d5eed9cd0	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	银行账户	erp-bank-account	/erp/bank-account	Building	15	active	{"permission": "erp:bank_account:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
17cda3bd-b3f2-4dc8-95ca-9d297dcfc9ce	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	资产管理	erp-asset-management	/erp/asset-management	Landmark	14	active	{"permission": "erp:asset:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
a5da92ef-5bb4-4891-a423-4327f8d562d7	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	车辆管理	erp-vehicle-management	/erp/vehicle-management	Car	13	active	{"permission": "erp:vehicle:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
67308a07-6505-4cb1-8180-d945f29b06d2	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	办公用品	erp-office-supplies	/erp/office-supplies	Package	12	active	{"permission": "erp:office_supply:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
9dfea21b-fa47-4e3f-8e45-71402a662ae6	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	物料管理	erp-material-management	/erp/material-management	Layers	11	active	{"permission": "erp:material:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
39b5a8df-09db-49eb-b27e-e648d8f4b05e	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	库存管理	erp-inventory-management	/erp/inventory-management	Package	10	active	{"permission": "erp:inventory:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
80c70ec5-0430-4c3c-96a5-29f7aaa98fb5	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	供应商管理	erp-supplier-management	/erp/supplier-management	Building2	9	active	{"permission": "erp:supplier:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
69f71bce-0bfd-4689-932e-35f9f1343c79	\N	13df91d9-a96f-45f7-8e9f-76c92a66ad86	\N	客户管理	erp-customer-management	/erp/customer-management	Users	8	active	{"permission": "erp:customer:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
29eba46b-e4de-45d7-9962-1eb85909fa17	\N	054803ba-0320-4ef1-a0ad-f152eedfa1ee	\N	财务分析	erp-financial-analysis	/erp/financial-analysis	BarChart3	21	active	{"permission": "erp:financial_analysis:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
13b221e1-e1c8-416a-af62-fb5d0ea048a6	\N	054803ba-0320-4ef1-a0ad-f152eedfa1ee	\N	财务报表	erp-financial-statements	/erp/financial-report	FileSpreadsheet	20	active	{"permission": "erp:financial_statement:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
018b3de8-914e-4c3b-9cd5-5c9278d8011d	\N	beecb71f-30a0-442b-9a48-2b02c691a224	\N	审计日志	erp-audit-log	/erp/audit-log	FileCheck	24	active	{"permission": "erp:audit:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
5fc2cb63-3c63-4157-a051-315e66849c1f	\N	beecb71f-30a0-442b-9a48-2b02c691a224	\N	数据库管理	erp-database-management	/erp/database-management	Database	23	active	{"permission": "erp:database:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
b03a94dc-5256-4c84-af28-7ce1eab936e7	\N	beecb71f-30a0-442b-9a48-2b02c691a224	\N	数据字典	erp-dictionaries	/erp/dict-management	BookOpen	22	active	{"permission": "erp:dictionary:read"}	2026-11-02 12:26:59.80655+08	2026-11-02 12:26:59.80655+08	\N
ff75d36a-45de-4c6d-8e1f-d3c90ce66259	\N	897c002e-53fd-4758-a922-27703174286b	\N	排产仪表盘	aps-dashboard	/aps/dashboard	LayoutDashboard	1	active	{"permission": "aps:dashboard:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
eb5cc9a4-9b40-46b0-9c07-2766ed0385c5	\N	9913602b-d7d9-4574-80fe-a8e526a346f3	\N	物料计划	aps-material-plans	/aps/material-plans	Package	5	active	{"permission": "aps:material_plan:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
c20f3bd5-88ac-4480-b447-7e03abb8d6ed	\N	9913602b-d7d9-4574-80fe-a8e526a346f3	\N	产能管理	aps-capacities	/aps/capacities	Gauge	4	active	{"permission": "aps:capacity:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
179101c2-a48a-42f3-b8ec-1b7acd236104	\N	21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	OEE 看板	aps-analytics-oee-dashboard	/aps/analytics/oee-dashboard	Activity	12	active	{"permission": "aps:dashboard:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
69e47280-afa9-4252-894a-7b637b23754f	\N	21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	预测准确度	aps-analytics-forecast-accuracy	/aps/analytics/forecast-accuracy	Target	11	active	{"permission": "aps:forecast:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
d2dbb528-7abc-4e76-9215-ebc56a23d5a8	\N	21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	物料短缺	aps-analytics-material-shortage	/aps/analytics/material-shortage	AlertTriangle	10	active	{"permission": "aps:material_plan:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
d6d39008-24be-4613-8722-143aa86e330f	\N	21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	产能利用率	aps-analytics-capacity-utilization	/aps/analytics/capacity-utilization	Gauge	9	active	{"permission": "aps:capacity:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
400293af-db14-4db1-aa03-65a40de6093f	\N	21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	排程甘特图	aps-analytics-schedule-gantt	/aps/analytics/schedule-gantt	GanttChart	8	active	{"permission": "aps:schedule:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
1480ed96-2ac1-4e3f-9df7-5dc7947e2b4c	\N	21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	计划达成率	aps-analytics-plan-adherence	/aps/analytics/plan-adherence	BarChart3	7	active	{"permission": "aps:dashboard:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
fc64bba2-9d13-4d95-a55d-29fe388e4c68	\N	21d5b3b7-2dbd-4256-a50b-36866a13b3dd	\N	需求预测	aps-forecasts	/aps/forecasts	TrendingUp	6	active	{"permission": "aps:forecast:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
82fdfae6-e6b5-4b34-80d0-545270b7116d	\N	98a42ca6-5251-4e63-ba51-fcfd5d656dc5	\N	司机管理	tms-drivers	/tms/drivers	Users	3	active	{"permission": "tms:driver:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
10916919-b2bd-41c6-933d-e2cdcdf63e2b	\N	98a42ca6-5251-4e63-ba51-fcfd5d656dc5	\N	车辆管理	tms-vehicles	/tms/vehicles	Truck	2	active	{"permission": "tms:vehicle:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
7817ab7e-ce8e-4599-9c7b-f07ecbe235bb	\N	027601c9-4658-4793-b134-166b2711716d	\N	运单管理	tms-shipments	/tms/shipments	Package	6	active	{"permission": "tms:shipment:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
54027799-c58b-41cb-9a97-dabfc0add38d	\N	211b7e22-de40-451f-9137-2dd34338d4e6	\N	运费成本	tms-freight-cost	/tms/analytics/freight-cost	DollarSign	12	active	{"permission": "tms:analytics:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
99dcf153-bff9-4836-b918-6bc72d7349eb	\N	211b7e22-de40-451f-9137-2dd34338d4e6	\N	路线效率	tms-route-efficiency	/tms/analytics/route-efficiency	Map	11	active	{"permission": "tms:analytics:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
4d8b57af-1cd3-4ef7-9719-5a86d1575f4d	\N	211b7e22-de40-451f-9137-2dd34338d4e6	\N	承运商绩效	tms-carrier-performance	/tms/analytics/carrier-performance	Building2	10	active	{"permission": "tms:analytics:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
7818bef4-4861-40ab-a319-9c452ece6937	\N	211b7e22-de40-451f-9137-2dd34338d4e6	\N	司机绩效	tms-driver-performance	/tms/analytics/driver-performance	UserCheck	9	active	{"permission": "tms:analytics:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
d917701f-939a-4e74-9dc7-dcdcad37f2fd	\N	211b7e22-de40-451f-9137-2dd34338d4e6	\N	车辆利用率	tms-vehicle-utilization	/tms/analytics/vehicle-utilization	Gauge	8	active	{"permission": "tms:analytics:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
25f44077-bdfa-4e59-8b44-ba12915f1a43	\N	211b7e22-de40-451f-9137-2dd34338d4e6	\N	运量趋势	tms-shipment-trend	/tms/analytics/shipment-trend	TrendingUp	7	active	{"permission": "tms:analytics:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
e1e19a7f-a59e-4481-a088-90fec56afd55	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	菜单管理	admin-menu	/admin/menu	Menu	16	active	{"permission": "system:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
5366d161-bd4d-42b8-abcb-90239e2b128b	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	功能开关	admin-feature-flag	/admin/feature-flag	ToggleLeft	15	active	{"permission": "system:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
9d4f2933-1316-4055-97c6-94cf8ca752a4	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	限流策略	admin-rate-limit	/admin/rate-limit	ShieldCheck	14	active	{"permission": "admin:system:write"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
61659bf2-2018-4f4c-99c6-aa574016d469	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	配置调试	admin-config-debug	/admin/config-debug	Bug	12	active	{"permission": "admin:debug:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
891ec4ee-1701-458a-86ee-672af960d8de	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	迁移管理	admin-migration	/admin/migration	RefreshCw	11	active	{"permission": "admin:migration:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
c6a25299-c8a2-425d-8e2b-6d1bb0df40b5	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	插件管理	admin-plugin	/admin/plugin	Puzzle	9	active	{"permission": "admin:plugin:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
d807c952-0de3-4131-a945-96e3d838d514	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	系统设置	admin-system-settings	/admin/system-settings	Settings2	8	active	{"permission": "admin:system:write"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
64bc8ec0-78b1-434d-9b00-114d6157394f	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	系统信息	admin-system	/admin/system	Server	7	active	{"permission": "admin:system:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
fe4957fd-69b9-4a4f-94cf-bafc230efd78	\N	00163a30-8d42-4849-8bb8-abd00601ffab	\N	平台字典	admin-dictionary	/admin/dictionary	BookOpen	6	active	{"permission": "admin:dictionary:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
5fe66370-c2f0-4c77-9a7b-289e9814ad72	\N	aac20b2b-c3e5-4f1e-95a6-56116e9151ba	\N	监控告警	admin-monitoring-alert	/admin/monitoring-alert	AlertTriangle	20	active	{"permission": "admin:monitor:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
d47c0c0a-1090-416e-85b1-87dfe51f6dd9	\N	aac20b2b-c3e5-4f1e-95a6-56116e9151ba	\N	权限审计	admin-permission-audit	/admin/permission-audit	Shield	19	active	{"permission": "admin:audit:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
24ef2a9a-7f28-46f9-bbbc-54a9ab4de1e7	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	知识图谱	master-knowledge-graph	/master/knowledge-graph	Network	10	active	{"permission": "master-data:knowledge:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
c505ac00-0bc6-4ee1-a404-4d3ebfa5e310	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	数据质量	master-quality	/master/quality	ShieldCheck	9	active	{"permission": "master-data:quality:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
95dcfa89-8ca6-480a-8fa8-a9f980799055	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	主数据治理	master-governance	/master/governance	Gauge	8	active	{"permission": "master-data:governance:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
8d42ff2d-1146-4046-9016-92cdaf3269fc	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	版本管理	master-versioning	/master/versioning	History	7	active	{"permission": "master-data:versioning:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
ba98751b-d5bb-4c61-947d-c4f617338a04	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	公共主数据	master-public-master-data	/master/public-master-data	Boxes	6	active	{"permission": "master-data:data-asset:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
031bdf4d-a7b8-4f9f-963f-73603261828b	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	商业主数据	master-commercial	/master/commercial	Storefront	5	active	{"permission": "master-data:commercial:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
8136eabb-7cb5-499a-ad79-98f2d23bd22b	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	AI 治理	master-ai-governance	/master/ai-governance	AutoAwesome	4	active	{"permission": "master-data:ai_governance:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
f902d7e0-3e30-4bc0-a768-bc7a2cdff75a	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	血缘分析	master-lineage-analytics	/master/lineage-analytics	AccountTree	3	active	{"permission": "master-data:lineage:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
190f1523-495e-46ad-8c58-ec4f66c2f427	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	元数据注册	master-schema-registry	/master/schema-registry	Database	2	active	{"permission": "master-data:schema:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
1627cf43-d266-4df9-a0c3-af30835b3da6	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	数据资产目录	master-data-asset-catalog	/master/data-asset-catalog	Database	1	active	{"permission": "master-data:data-asset:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
fd64aeed-0dd5-43f9-85c0-8946e4dd53bf	\N	da22f67c-df3e-4b87-a187-492ca92187d5	\N	RAG 问答	ai-dsh-rag	/ai/dsh-rag	Search	13	active	{"permission": "ai:knowledge:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
67fc68d9-a0a6-49ce-93e2-43f3d7ca4b84	\N	da22f67c-df3e-4b87-a187-492ca92187d5	\N	知识库检索	ai-dsh-knowledge	/ai/dsh-knowledge	Network	12	active	{"permission": "ai:knowledge:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
efd2b2c1-ee89-4d41-b477-fd44481d3f0c	\N	da22f67c-df3e-4b87-a187-492ca92187d5	\N	业务 Copilot	ai-businessCopilot	/ai/businessCopilot	Briefcase	10	active	{"permission": "ai:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
b7e8b9a6-0d65-4b36-b4ef-38bd8885dea7	\N	da22f67c-df3e-4b87-a187-492ca92187d5	\N	知识库	ai-knowledge	/ai/knowledge	BookOpen	5	active	{"permission": "ai:knowledge:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
19372636-a8ea-490d-be08-6331851aa184	\N	da22f67c-df3e-4b87-a187-492ca92187d5	\N	AI 文档	ai-document	/ai/document	FileText	4	active	{"permission": "ai:document:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
ec458311-66c5-433f-bbe7-1c0566b81cfe	\N	597c8817-896f-421c-b04a-af84ccc8efbc	\N	AI 设置	ai-settings	/ai/settings	Settings	7	active	{"permission": "ai:dashboard:admin"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
c32519ef-4432-4697-848e-412ef62d62a7	\N	597c8817-896f-421c-b04a-af84ccc8efbc	\N	提示词管理	ai-prompts	/ai/prompts	Library	6	active	{"permission": "ai:prompt:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
71b85261-11ac-4202-93d8-606bfe04e575	\N	0b38f8fe-d89f-4273-8bbb-319fb6b63aa1	\N	MES-ERP 集成	integration-mes-erp	/integration/mes-erp	Factory	7	active	{"permission": "integration:mes:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
229a4f93-56e4-40e1-b10d-e69c9fb29740	\N	0b38f8fe-d89f-4273-8bbb-319fb6b63aa1	\N	LIMS/QMS 集成	integration-lims-qms	/integration/lims-qms	FlaskConical	6	active	{"permission": "integration:lims:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
ada5740a-82f5-400f-8427-672b3ec042df	\N	0b38f8fe-d89f-4273-8bbb-319fb6b63aa1	\N	ERP 集成	integration-erp	/integration/erp-overview	Building2	5	active	{"permission": "integration:erp:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
c9c6441d-0701-499d-bfa2-2cb3b29b88f3	\N	b97c3e13-3ddf-42d7-a3cc-5af7ff1fd8c0	\N	集成设置	integration-settings	/integration/settings	Settings	9	active	{"permission": "integration:dashboard:admin"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e5c7cbad-fa24-4f69-adf4-cf65c9dcafbd	\N	e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	部署管理	rd-deploy	/rd/deploy	CloudUpload	12	active	{"permission": "rd:deploy:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
fe015fc7-37a1-460b-8526-81da1db1969f	\N	e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	代码评审	rd-review	/rd/review	GitBranch	11	active	{"permission": "rd:review:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
543ad07e-25f9-4db3-b5ce-d60978ed7bd6	\N	e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	缺陷管理	rd-bug	/rd/bug	AlertTriangle	10	active	{"permission": "rd:bug:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
26b21ffc-eb82-46ad-a21b-9d64571e2d50	\N	e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	构建管理	rd-build	/rd/build	Hammer	8	active	{"permission": "rd:build:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
c8963539-e248-4d9e-8741-0a39a27474f7	\N	19989296-5f8b-47d3-a821-92ad06d7bb1c	\N	研发报表	rd-report	/rd/report	BarChart3	16	active	{"permission": "rd:report:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
4a3752d0-d5a2-401b-b92a-4d333ede5408	\N	c4365675-4b37-4028-bd74-71b45b3666ff	\N	研发设置	rd-settings	/rd/settings	Settings	17	active	{"permission": "rd:settings:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e4bf66b0-74f6-44fd-989f-83cf65397e14	\N	f4eaf662-ac27-4b5a-9e09-865bc7897369	\N	会议管理	oa-meetings	/oa/meetings	FileText	4	active	{"permission": "oa:meeting:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
177dd606-2c0e-465a-bb67-97bfc544252c	\N	4c71be4e-c78a-4814-ac9c-bfd0bad732c4	\N	文档列表	doc-list	/doc/list	FolderOpen	2	active	{"permission": "doc:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
a553065a-1978-4361-b09b-3225dd4ae05a	\N	61c07c32-97c2-408b-82d4-e4fdb888257a	\N	流程设计器	workflow-designer	/workflow/designer	Pencil	3	active	{"permission": "workflow:definition:write"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
2551a537-0229-42a3-8d30-0d42ba21c458	\N	61c07c32-97c2-408b-82d4-e4fdb888257a	\N	流程定义	workflow-definitions	/workflow/definitions	FileCode	2	active	{"permission": "workflow:definition:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
18fda69a-20f9-4bbc-94d1-4c65ec7cdac6	\N	10c46b46-c42a-4c05-b1de-0d7cab0ab79f	\N	流程统计	workflow-statistics	/workflow/statistics	BarChart3	9	active	{"permission": "workflow:statistics:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
8ff638fa-4142-489c-9299-c08f0766c963	\N	10c46b46-c42a-4c05-b1de-0d7cab0ab79f	\N	流程监控	workflow-monitor	/workflow/monitor	Activity	8	active	{"permission": "workflow:monitor:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
c55b99df-e0b2-440b-a71f-cafc542e9b6c	\N	7824d76b-dfd5-4182-94ed-4f672864ebc3	\N	流程设置	workflow-settings	/workflow/settings	Settings	11	active	{"permission": "workflow:dashboard:admin"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
25f583bf-3bcb-44be-a196-9d687c843f04	\N	7824d76b-dfd5-4182-94ed-4f672864ebc3	\N	流程模板	workflow-templates	/workflow/templates	Layers	10	active	{"permission": "workflow:template:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
40b76921-9dd4-4b70-8a9f-448c76bee1af	\N	d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	财务报表	finance-reports	/finance/reports	FileSpreadsheet	1	active	{"permission": "finance:report:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
eb3ce97f-43d1-4c63-8270-a61085841762	\N	d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	期初余额	finance-opening-balance	/finance/opening-balance	CircleDot	2	active	{"permission": "finance:opening_balance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
e7ddba3a-0cac-455d-a975-82e9795853ed	\N	d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	合并报表	finance-consolidation	/finance/consolidation	Layers	3	active	{"permission": "finance:consolidation:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ab8f097d-6e64-4160-8550-f99c07817fc3	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	凭证管理	finance-vouchers	/finance/vouchers	FileText	1	active	{"permission": "finance:voucher:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
619855b7-27be-499c-b35c-b8926d54ee9a	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	总账管理	finance-ledger	/finance/ledger	FileSpreadsheet	2	active	{"permission": "finance:ledger:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
47590b05-ee6d-4da4-9556-101f34f89542	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	应收应付	finance-receivable-payable	/finance/receivable-payable	TrendingUp	3	active	{"permission": "finance:receivable:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
9e3ce2f0-a34a-43ab-9c38-ca1400d55d36	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	收款管理	finance-receipts	/finance/receipts	ArrowDownCircle	4	active	{"permission": "finance:receipt:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
16242f70-983b-483d-b7ba-d5a36d5c1bb0	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	付款管理	finance-payments	/finance/payments	ArrowUpCircle	5	active	{"permission": "finance:payment:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5708f3cd-6409-4cc2-b24b-c160a467dbdc	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	审批配置	finance-approval-config	/finance/approval-config	Settings	6	active	{"permission": "finance:approval_config:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
eedb5000-0e29-4ccd-b546-b5884c99a736	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	发票管理	finance-invoices	/finance/invoices	FileText	7	active	{"permission": "finance:invoice:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6eeb033f-cb4a-4f58-83e9-248e5dad467a	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	费用管理	finance-expense	/finance/expense	CreditCard	8	active	{"permission": "finance:expense:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
613a603d-1523-4726-812f-f14899bb4541	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	费用审批	finance-expense-approval	/finance/expense-approval	ClipboardList	9	active	{"permission": "finance:expense_approval:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c6d9fbbe-5ef2-4e41-a7fe-8fe4447a2b69	\N	96e23d67-21e6-4bc6-b1fd-24a35475cf18	\N	仪表盘	finance-dashboard	/finance/dashboard	LayoutDashboard	0	active	{"permission": "finance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
b8d06389-600b-46f6-be9f-3b939c312127	\N	fbb2b200-54f7-4379-92e3-586141315663	\N	预算管理	finance-budget	/finance/budget	PieChart	1	active	{"permission": "finance:budget:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
601adf50-27a8-4179-ab12-0ef33ee54be8	\N	fbb2b200-54f7-4379-92e3-586141315663	\N	资产管理	finance-assets	/finance/assets	Briefcase	2	active	{"permission": "finance:asset:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6e584b26-a6aa-4cac-a605-1c326fb00c2c	\N	fbb2b200-54f7-4379-92e3-586141315663	\N	税务管理	finance-tax	/finance/tax	FileCheck	3	active	{"permission": "finance:tax:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d3d02e22-d4e3-4cd6-98fa-a56c12db5ac7	\N	fbb2b200-54f7-4379-92e3-586141315663	\N	成本管理	finance-cost	/finance/cost	BarChart3	4	active	{"permission": "finance:cost:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ff83afd1-cf9f-4291-a2aa-b10825ae7a8d	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	生产看板	mes-production-kanban	/mes/production-kanban	LayoutGrid	1	active	{"permission": "mes:kanban:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
47113c34-a1dc-49ba-ae74-54c7d35bd9ef	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	生产记录	mes-production-record	/mes/production-record	ScrollText	2	active	{"permission": "mes:production_record:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
f12decdc-f63b-4800-a87c-671653008c94	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	工作报告	mes-work-report	/mes/work-report	FileCheck	3	active	{"permission": "mes:work_report:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
350a857e-ddbd-4406-a582-e62c1c786d38	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	设备OEE	mes-equipment-oee	/mes/equipment-oee	Gauge	4	active	{"permission": "mes:oee:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
f79c79a6-ad18-4486-8e3c-978dbaa098e2	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	生产总览	mes-production-dashboard	/mes/production-dashboard	BarChart3	5	active	{"permission": "mes:production_dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
93fce50a-e256-4890-a101-df04a10279ae	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	生产成本核算	mes-production-cost	/mes/production-cost	DollarSign	6	active	{"permission": "mes:production_cost:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
e4bfba6b-facc-4e86-bd2f-aed2534078d7	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	能耗管理	mes-energy-management	/mes/energy-management	Zap	7	active	{"permission": "mes:energy_management:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
2617a7f7-5ec3-4570-a700-f344e8d2c2ce	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	异常预警	mes-anomaly-detection	/mes/anomaly-detection	AlertTriangle	8	active	{"permission": "mes:anomaly_detection:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
53297af8-325d-4533-a43f-4728bba333d1	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	生产订单	mes-production-orders	/mes/production-orders	ClipboardList	1	active	{"permission": "mes:production_order:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8b677136-e821-4a9f-8d8a-8dc44f88e6f5	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	设备管理	mes-equipment	/mes/equipment	Wrench	3	active	{"permission": "mes:equipment:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
a0e58d2f-9ed2-48d1-8f2a-929a4843d153	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	班组管理	mes-teams	/mes/teams	Users	5	active	{"permission": "mes:team:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
406ace40-1729-4e1b-be12-f04cd212d268	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	物料需求	mes-material-requirement	/mes/material-requirement	Package	6	active	{"permission": "mes:material:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8b2e2a26-8146-467c-a681-c1bdaa70a3fd	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	工单管理(新)	mes-work-order	/mes/work-order	ClipboardList	7	active	{"permission": "mes:work_order:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
e1c5ecd7-3294-4615-9c7a-bef1787a9a09	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	质量管理	mes-quality	/mes/quality	CheckCircle	8	active	{"permission": "mes:quality:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
9a68d857-c13e-43ba-a028-276c3600cc34	\N	38127719-50b2-444f-86fe-4fc20a3fafe7	\N	仪表盘	mes-dashboard	/mes/dashboard	LayoutDashboard	0	active	{"permission": "mes:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
990170e7-d62b-4357-8ed5-3bea09c8a95b	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	工艺路线	mes-process-routes	/mes/process-routes	Route	1	active	{"permission": "mes:process_route:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
154e25bc-4955-4e22-8130-71d38cfc3d3f	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	工艺流程	mes-process-flow	/mes/process-flow	GitBranch	2	active	{"permission": "mes:process_flow:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5fae1946-d341-4cdc-8a6f-d3e1103b3f22	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	生产过程	mes-production-process	/mes/production-process	Activity	3	active	{"permission": "mes:production_process:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
e0631d39-2a0d-486e-9ba8-20968fa5bd25	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	生产计划	mes-production-schedule	/mes/production-schedule	Calendar	4	active	{"permission": "mes:production_schedule:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c7d9fa8f-31a8-4366-829a-73fa4562524f	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	在制品	mes-wip	/mes/wip	Box	5	active	{"permission": "mes:wip:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
b57bd955-612b-4d8a-8eb2-83cddd73097a	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	过程质检	mes-quality-inspection	/mes/quality-inspection	CheckCircle	6	active	{"permission": "mes:quality:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
0a7a551c-f6b7-442c-85b6-5ae8b769661a	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	质量追溯	mes-traceability	/mes/traceability	Search	7	active	{"permission": "mes:traceability:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ebded6f3-347b-4b25-9039-b041f09bb770	\N	4c4ec4c7-e9b2-48ef-a5f5-09c1ae7ebff9	\N	APS高级排程	mes-aps-scheduling	/mes/aps-scheduling	Brain	8	active	{"permission": "mes:production_schedule:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
643ba66b-ebce-4afc-9431-cdb744ac4e76	\N	6e920de5-e727-4c1c-a8ab-ac95ee6da1b2	\N	统计报表	hrm-reports	/hrm/reports	BarChart3	1	active	{"permission": "hrm:report:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
9ffa330a-0d6e-4067-8c43-9a3181329cbf	\N	6e920de5-e727-4c1c-a8ab-ac95ee6da1b2	\N	数据概览	hrm-overview	/hrm/overview	PieChart	2	active	{"permission": "hrm:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8f7cfe75-b772-4926-838f-e001d7da9cfe	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	员工管理	hrm-employees	/hrm/employees	User	1	active	{"permission": "hrm:employee:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
9171f7a6-45df-4e7d-ae85-17f364a06774	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	部门管理	hrm-departments	/hrm/departments	Network	2	active	{"permission": "hrm:department:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d31aaeb6-3aae-42d4-8458-078ea59286eb	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	组织架构	hrm-organization	/hrm/organization	Building2	3	active	{"permission": "hrm:organization:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
37e1af62-14b8-494c-8e9b-cc5c9fdb47af	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	岗位管理	hrm-positions	/hrm/positions	Briefcase	4	active	{"permission": "hrm:position:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5e8fa734-e6bd-4570-80a1-f0e3d6061113	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	合同管理	hrm-contracts	/hrm/contracts	FileText	5	active	{"permission": "hrm:contract:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8604927e-c6d0-4dc5-8c9f-7ff08a74e671	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	公司信息	hrm-company	/hrm/company	Building	6	active	{"permission": "hrm:company:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
b418cd5f-6326-47c2-9a04-77363c21ba38	\N	6bbb428e-f334-4ddc-8dfa-7db0c86a587e	\N	仪表盘	hrm-dashboard	/hrm/dashboard	LayoutDashboard	0	active	{"permission": "hrm:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
3d51df3b-ff73-4ea8-b064-1edbe462bc92	\N	25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	考勤管理	hrm-attendance	/hrm/attendance	Clock	1	active	{"permission": "hrm:attendance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d09de438-6493-4f4c-8986-0079f3223f94	\N	25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	请假管理	hrm-leave	/hrm/leave	Calendar	2	active	{"permission": "hrm:leave:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
968f67e3-f361-401f-a456-6e90a80c40bd	\N	25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	薪资管理	hrm-payroll	/hrm/payroll	Wallet	3	active	{"permission": "hrm:payroll:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
9f7cfaf0-5e36-4396-9978-6df1e436a0cb	\N	25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	调薪管理	hrm-salary-adjustment	/hrm/salary-adjustment	TrendingUp	4	active	{"permission": "hrm:salary_adjustment:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
2523e5ef-401e-4082-b14a-e4b9f880748f	\N	25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	招聘管理	hrm-recruitment	/hrm/recruitment	UserPlus	5	active	{"permission": "hrm:recruitment:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
41764bbe-1beb-4b4a-9cc0-73fcefc6b1ce	\N	25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	培训管理	hrm-training	/hrm/training	GraduationCap	6	active	{"permission": "hrm:training:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
27dbe96d-405f-4529-b2f5-f4a70060dde0	\N	25ad7d82-062e-4cb7-a6a3-6c489c4b5d48	\N	绩效管理	hrm-performance	/hrm/performance	Trophy	7	active	{"permission": "hrm:performance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
56ab3627-0ec5-4e42-a5aa-d62b5d921baf	\N	37577e90-7500-4310-bc1b-757d7f146ce9	\N	统计分析	pdm-stats	/pdm/stats	BarChart3	1	active	{"permission": "pdm:stats:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
1270c0b2-0c3e-451f-9df5-987b8e27972c	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	产品管理	pdm-product	/pdm/product	Box	1	active	{"permission": "pdm:product:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
cc345063-fc9d-409c-99c7-c5d6711d9fcf	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	物料管理	pdm-material	/pdm/material	Layers	2	active	{"permission": "pdm:material:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
0202c9f3-5e5f-47a5-8685-7a77337a1324	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	BOM管理	pdm-bom	/pdm/bom	GitBranch	3	active	{"permission": "pdm:bom:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
7d05d439-970f-48c9-9acf-7950eb170725	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	PDM BOM	pdm-pdm-bom	/pdm/pdm-bom	Network	4	active	{"permission": "pdm:bom:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
eccf448f-e70d-4e53-9631-72439e2da0ae	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	文档管理	pdm-document	/pdm/document	FileText	5	active	{"permission": "pdm:document:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
059b15fe-7f7d-4985-9b2f-133b9e957180	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	项目管理	pdm-project	/pdm/project	FolderKanban	6	active	{"permission": "pdm:project:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d0aaed7f-ff3b-4365-a904-9da3e074d43a	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	产品配置	pdm-product-config	/pdm/product-config	Settings2	7	active	{"permission": "pdm:product:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
77cb8feb-860a-44bd-b24c-632bbfeeca64	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	配方管理	pdm-formula	/pdm/formula	FlaskConical	8	active	{"permission": "pdm:formula:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
82d33389-3216-4beb-8afa-904c600b2e73	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	工艺管理	pdm-process	/pdm/process	Activity	9	active	{"permission": "pdm:process:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4238da29-ae14-4954-b6d5-af31d58cd86e	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	批次管理	pdm-batch	/pdm/batch	Hash	10	active	{"permission": "pdm:batch:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
fec5ca6b-1b52-4ba9-944a-d1c6b6e8e523	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	步骤管理	pdm-step	/pdm/step	CircleDot	11	active	{"permission": "pdm:step:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4145cf92-93d1-4c6f-b1a7-26059ab3b6f3	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	产品类别	pdm-product-category	/pdm/product-category	Tags	12	active	{"permission": "pdm:product_category:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
94f1f0e8-ce49-43b1-8068-a2dd5db2dc13	\N	c3d15966-e2cf-4ef9-8465-87097000821d	\N	仪表盘	pdm-dashboard	/pdm/dashboard	LayoutDashboard	0	active	{"permission": "pdm:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5ad0ff7e-af3c-4f8b-b136-8730ec5eaa29	\N	85324143-b4d0-409e-80c3-14f5095c398f	\N	版本管理	pdm-version	/pdm/version	Tag	1	active	{"permission": "pdm:version:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ecaa82f3-7abd-4b0f-bf05-f0d1acbd8636	\N	85324143-b4d0-409e-80c3-14f5095c398f	\N	变更管理	pdm-change	/pdm/change	RefreshCw	2	active	{"permission": "pdm:change:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
938317d2-88e0-4905-9caa-51a20de01058	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	库存查询	wms-items	/wms/inventory	Package	1	active	{"permission": "wms:inventory:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
df4f58c4-2b5d-4c33-903e-9d588a45c66b	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	库存报表	wms-inventory-report	/wms/inventory-report	BarChart3	2	active	{"permission": "wms:report:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
e3d49338-a820-4c1b-baf1-495d5243e316	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	仓库管理	wms-warehouses	/wms/warehouse-management	Warehouse	1	active	{"permission": "wms:warehouse:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5a45a7c4-9403-4c27-b390-4a91ce82093e	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	库位管理	wms-locations	/wms/location-management	MapPin	2	active	{"permission": "wms:location:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6c499453-fe8f-4302-aa5f-8dbd418d1dfb	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	批次管理	wms-batches	/wms/batch-management	Layers	3	active	{"permission": "wms:batch:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
2590e218-f78c-4203-aaeb-d3872a64827c	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	序列号管理	wms-serial-number	/wms/serial-number	Hash	4	active	{"permission": "wms:serial_number:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
abcb0c05-694f-472f-841d-4a08213cc2b5	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	供应商管理	wms-supplier-management	/wms/supplier-management	Building2	5	active	{"permission": "wms:supplier:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
af463f42-cb73-4fb6-8ded-f8d00be72f46	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	库区管理	wms-area	/wms/area	Map	6	active	{"permission": "wms:area:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
eb9c67d4-2149-4256-88ff-6481c567726a	\N	adcbe5df-0504-4e95-94b0-1233dcc93604	\N	仪表盘	wms-dashboard	/wms/dashboard	LayoutDashboard	0	active	{"permission": "wms:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8b5df1dc-a57e-4404-ad9d-b9224b7f4d6a	\N	cbf65c4e-0acc-4181-b0f4-03473220867c	\N	入库管理	wms-inbound	/wms/inbound	ArrowDownToLine	1	active	{"permission": "wms:inbound:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
53bb13ee-984a-4737-906c-d736d12fc5c7	\N	cbf65c4e-0acc-4181-b0f4-03473220867c	\N	入库单	wms-inbound-order	/wms/inbound-order	FileText	2	active	{"permission": "wms:inbound:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
0f969568-65c9-42a5-947c-0a797db08d5c	\N	cbf65c4e-0acc-4181-b0f4-03473220867c	\N	出库管理	wms-outbound	/wms/outbound	ArrowUpFromLine	3	active	{"permission": "wms:outbound:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
cdd1e051-bfda-4cba-9723-b4273c733a42	\N	cbf65c4e-0acc-4181-b0f4-03473220867c	\N	出库单	wms-outbound-order	/wms/outbound-order	FileText	4	active	{"permission": "wms:outbound:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
0327eec4-91f8-4fdb-86c2-29c9424b9d5f	\N	cbf65c4e-0acc-4181-b0f4-03473220867c	\N	调拨管理	wms-transfer	/wms/transfer	ArrowRightLeft	5	active	{"permission": "wms:transfer:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c770dcdd-5ab7-4b81-8eab-7c8837e36a58	\N	cbf65c4e-0acc-4181-b0f4-03473220867c	\N	库存盘点	wms-inventory-check	/wms/stock-take	ClipboardCheck	6	active	{"permission": "wms:inventory_check:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d1dadb44-fb9c-4f69-b05e-113d24956398	\N	cbf65c4e-0acc-4181-b0f4-03473220867c	\N	补货管理	wms-replenishment	/wms/replenishment	RefreshCw	7	active	{"permission": "wms:replenishment:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
f36a8bff-1ea3-450e-9ff1-3a0cbb90df33	\N	be53f9f6-6115-40d1-ba7e-d57934a6228b	\N	环境监测	ehs-environment	/ehs/environment	Leaf	1	active	{"permission": "ehs:environment:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
54fc357f-caf2-4128-b830-43c100410500	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	安全检查	ehs-check	/ehs/check	ClipboardCheck	1	active	{"permission": "ehs:check:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
62025599-ba7c-46df-9df0-b4f255cc752a	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	危险源管理	ehs-hazard	/ehs/hazard	AlertTriangle	2	active	{"permission": "ehs:hazard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c9288b79-5250-4873-b789-4a23f032a553	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	事故管理	ehs-accident	/ehs/accident	AlertCircle	3	active	{"permission": "ehs:accident:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
bc00e1d7-d36d-4523-b5ba-9326844ca899	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	合规管理	ehs-compliance	/ehs/compliance	FileCheck	4	active	{"permission": "ehs:compliance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
afd6abc2-14bf-4a46-9184-a8cba06b145f	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	职业病管理	ehs-occupational-disease	/ehs/occupational-disease	Heart	5	active	{"permission": "ehs:occupational_disease:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
982112e8-accd-4c4e-8b31-8d5ac802eca7	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	健康管理	ehs-health-management	/ehs/health-management	Activity	6	active	{"permission": "ehs:health:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
9711aa89-b6e4-4d22-b3ab-883479781cf2	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	危化品管理	ehs-hazardous-material	/ehs/hazardous-material	FlaskConical	7	active	{"permission": "ehs:hazardous_material:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
b9676b88-94d2-483c-9d97-2e1f1fe8c36d	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	应急管理	ehs-emergency	/ehs/emergency	Zap	8	active	{"permission": "ehs:emergency:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
cf3c6699-2cf3-4608-b46e-0fccaf146673	\N	d4793077-1bc7-49cb-8cde-eb5569cdc979	\N	事件报告	ehs-incident-report	/ehs/incident-report	FileText	9	active	{"permission": "ehs:incident:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
3a70b750-a2b3-44ea-b0c3-b397731cf8e7	\N	c33cc178-5c5e-4474-b919-a0cf4977294d	\N	仪表盘	ehs-dashboard	/ehs/dashboard	LayoutDashboard	0	active	{"permission": "ehs:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
3af60021-b8cc-49bd-ae21-a14bf5d2ad8d	\N	16c7ee43-ac8f-4d09-8b47-22b01223fa75	\N	工作计划	ehs-plan	/ehs/plan	Calendar	1	active	{"permission": "ehs:plan:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
50586bbe-4abe-41b7-8c53-1417cf06c495	\N	16c7ee43-ac8f-4d09-8b47-22b01223fa75	\N	培训管理	ehs-training	/ehs/training	GraduationCap	2	active	{"permission": "ehs:training:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5b4804ae-a519-441a-8e31-ff1e29eff6a2	\N	16c7ee43-ac8f-4d09-8b47-22b01223fa75	\N	应急演练	ehs-drill	/ehs/drill	LifeBuoy	3	active	{"permission": "ehs:drill:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
99a3f396-00ba-4e31-a29f-93b20185d30a	\N	78f61b0a-b6c8-4ed2-8cfe-c7068737f7fe	\N	不确定度	lims-uncertainty	/lims/uncertainty	Activity	1	active	{"permission": "lims:uncertainty:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8cc463fb-0b17-4922-b22d-e6db8ec6db51	\N	78f61b0a-b6c8-4ed2-8cfe-c7068737f7fe	\N	检验结果	lims-inspection-result	/lims/inspection-result	FileCheck	2	active	{"permission": "lims:result:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
02658ba6-3f0c-4078-8620-ff45bde233c9	\N	78f61b0a-b6c8-4ed2-8cfe-c7068737f7fe	\N	能力验证	lims-proficiency-testing	/lims/proficiency-testing	Award	3	active	{"permission": "lims:proficiency:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
7cf43505-0de8-47da-935b-ac2533944783	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	样品管理	lims-sample	/lims/sample	Package	1	active	{"permission": "lims:sample:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
33308f50-1ebe-43db-bb7a-1dc08ef49aa4	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	样品接收	lims-sample-receive	/lims/sample-receive	FilePlus	2	active	{"permission": "lims:sample:write"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
65fc764e-73a9-408c-b5ed-614134fd1f9f	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	检验任务	lims-task	/lims/task	ClipboardList	3	active	{"permission": "lims:task:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4570aeb5-aded-46c0-8bf8-4c04e0fb441e	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	检验任务列表	lims-inspection-task	/lims/inspection-task	CheckSquare	4	active	{"permission": "lims:task:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
bf39cd24-c446-40b3-b200-b661daf9c03f	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	检验流程	lims-process	/lims/process	GitBranch	5	active	{"permission": "lims:process:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
49ecd11a-2127-4b51-9034-8348c352e3a1	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	仪器设备	lims-instrument	/lims/instrument	Microscope	6	active	{"permission": "lims:instrument:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
3e0091dc-fe06-464e-96d5-709f167b4ab2	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	仪器维护	lims-instrument-maintenance	/lims/instrument-maintenance	Wrench	7	active	{"permission": "lims:instrument:write"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
b5be80b5-433d-4df4-af12-d50a4be7262d	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	试剂管理	lims-reagent	/lims/reagent	FlaskRound	8	active	{"permission": "lims:reagent:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
b4e9ca31-8a4e-4460-9f65-331f8bdb9acc	\N	d3ca564b-086c-499e-93a3-36bfaff5873d	\N	仪表盘	lims-dashboard	/lims/dashboard	LayoutDashboard	0	active	{"permission": "lims:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8553a693-df19-46a0-806b-f49fa3840e16	\N	c27d9700-2934-4973-a351-68f34289ed8a	\N	测试方法	lims-test-method	/lims/test-method	FileText	1	active	{"permission": "lims:test_method:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6d609200-6e98-4e90-a1bb-7020f3e546e8	\N	c27d9700-2934-4973-a351-68f34289ed8a	\N	条码管理	lims-barcode	/lims/barcode	Barcode	2	active	{"permission": "lims:barcode:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
113668e0-4f3e-41c1-afca-889ea7209369	\N	973dce82-ca38-4813-99a3-8791843cc370	\N	智能推荐	crm-recommendation	/crm/recommendation	Sparkles	1	active	{"permission": "crm:recommendation:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ca33e7a5-4626-4ac9-9d72-0a3a17512ebd	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	客户管理	crm-customers	/crm/customers	UserCircle	1	active	{"permission": "crm:customer:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
d9904a33-7565-4dc1-ac04-5f447cfabbad	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	联系人	crm-contacts	/crm/contacts	User	2	active	{"permission": "crm:contact:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
09fa99ed-5162-4ea0-9d2f-cb979d21ac48	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	商机管理	crm-opportunities	/crm/opportunities	Target	3	active	{"permission": "crm:opportunity:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
cdb21752-201e-4c6c-a875-97af6af0be29	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	互动记录	crm-interactions	/crm/interactions	MessageSquare	4	active	{"permission": "crm:interaction:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ec572ca5-a6bd-48ca-8609-cda96fea1783	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	退货/售后	crm-returns	/crm/returns	RotateCcw	5	active	{"permission": "crm:return:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
9199e6ef-c8b3-40a1-82e4-e1ec6d306737	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	客户评分	crm-customer-scoring	/crm/customer-scoring	Award	7	active	{"permission": "crm:customer_scoring:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6490cf4e-d159-4217-9307-65dee53ccba0	\N	380835f0-2eae-49dc-8b1d-12404e4ce73b	\N	仪表盘	crm-dashboard	/crm/dashboard	LayoutDashboard	0	active	{"permission": "crm:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5b817eaf-7b8e-415b-9aac-47c0f4b4dcc3	\N	35cc0691-c927-4690-8aa4-c1bb5c6ccc27	\N	销售漏斗	crm-sales-funnel	/crm/sales-funnel	TrendingUp	1	active	{"permission": "crm:sales_funnel:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8c87e814-bda5-4905-86a2-2c44e25ef6fa	\N	35cc0691-c927-4690-8aa4-c1bb5c6ccc27	\N	销售预测	crm-sales-forecast	/crm/sales-forecast	BarChart3	2	active	{"permission": "crm:sales_forecast:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c2ca6a3f-2e20-4d3a-8709-fc00aa10d888	\N	35cc0691-c927-4690-8aa4-c1bb5c6ccc27	\N	计费管理	crm-billing	/crm/billing	CreditCard	3	active	{"permission": "crm:billing:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
4f87d695-47e8-45bc-83f7-5cc0a06e2acf	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	质量成本	qms-quality-cost	/qms/quality-cost	Wallet	2	active	{"permission": "qms:quality_cost:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
a5847ee7-2daa-4dde-b264-af9490411854	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	SPC统计	qms-spc	/qms/spc	TrendingUp	1	active	{"permission": "qms:spc:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
32e39be8-dd6e-4112-a01a-a1bb20347e1e	\N	a7dfc40b-3650-41c8-8750-9ba13d29cf7d	\N	质量标准	qms-standards	/qms/standards	FileText	4	active	{"permission": "qms:standard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
fbbfb235-74b8-4244-9031-bd6fe1191228	\N	a7dfc40b-3650-41c8-8750-9ba13d29cf7d	\N	不合格品	qms-nonconformance	/qms/nonconformance	XCircle	3	active	{"permission": "qms:nonconformance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
71fe5e60-0042-4c9f-a1bf-1c1a00c7205b	\N	a7dfc40b-3650-41c8-8750-9ba13d29cf7d	\N	质量控制	qms-quality-control	/qms/quality-control	ClipboardList	2	active	{"permission": "qms:quality_control:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
14bd0514-09ea-4c5e-9f10-20108e42518b	\N	a7dfc40b-3650-41c8-8750-9ba13d29cf7d	\N	质检任务	qms-inspection	/qms/inspection	CheckSquare	1	active	{"permission": "qms:inspection:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
2987c320-8445-400d-b74c-4e7fc93919b7	\N	64930fe3-c66b-43e9-ab8a-6370a62a7d04	\N	仪表盘	qms-dashboard	/qms/dashboard	LayoutDashboard	0	active	{"permission": "qms:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
42f1464f-1baa-4358-ae8b-a3255aa6c9bd	\N	6da00511-bb5d-4eeb-a226-81d24b4fe6ac	\N	8D报告	qms-eightd	/qms/eightd	FileCheck	4	active	{"permission": "qms:eightd:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
fd3fd4ab-d5ed-49cb-a5ba-5ab3d094a056	\N	6da00511-bb5d-4eeb-a226-81d24b4fe6ac	\N	FMEA分析	qms-fmea	/qms/fmea	AlertTriangle	3	active	{"permission": "qms:fmea:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
bd3c9ca8-e293-48e9-8f5c-8f712709b6eb	\N	6da00511-bb5d-4eeb-a226-81d24b4fe6ac	\N	APQP管理	qms-apqp	/qms/apqp	BookOpen	2	active	{"permission": "qms:apqp:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
7aab9ecc-4673-4ab3-bf3f-b714aa4f4ebc	\N	6da00511-bb5d-4eeb-a226-81d24b4fe6ac	\N	审核管理	qms-audit-management	/qms/audit-management	SearchCheck	1	active	{"permission": "qms:audit:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
cf046c80-635b-45e2-b446-19ce3f900aec	\N	2529cbb4-d27e-4d5f-b4cd-ae279cfbdf62	\N	供应链概览	scm-overview	/scm/overview	PieChart	1	active	{"permission": "scm:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
7ba04e81-d962-4339-b13a-d8048a59bc1a	\N	2529cbb4-d27e-4d5f-b4cd-ae279cfbdf62	\N	库存周转	scm-inventory-turnover	/scm/inventory-turnover	TrendingUp	2	active	{"permission": "scm:inventory_turnover:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
edfb5296-af5c-45cc-8de0-402a40121ee8	\N	2529cbb4-d27e-4d5f-b4cd-ae279cfbdf62	\N	价格对比	scm-price-comparison	/scm/price-comparison	BarChart3	3	active	{"permission": "scm:price_comparison:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6779546c-01a1-4088-bce1-5b3d9941201e	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	采购订单	scm-purchase-orders	/scm/purchase-orders	ClipboardList	1	active	{"permission": "scm:purchase_order:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
86009471-5ec1-4886-8557-5f0892c122b3	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	采购申请	scm-purchase-requisition	/scm/purchase-requisition	FileText	2	active	{"permission": "scm:purchase_requisition:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
5524dc23-4bfa-4cf3-b9f9-ffd263ee4cd4	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	采购明细	scm-purchase-items	/scm/purchase-items	List	3	active	{"permission": "scm:purchase_item:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ebaaf816-ef52-4b1f-8362-1da44dcd30f4	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	供应商管理	scm-suppliers	/scm/suppliers	Building	4	active	{"permission": "scm:supplier:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
067ca9ca-0ffc-4830-b629-e6634cdde1e1	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	供应商准入	scm-supplier-admission	/scm/supplier-admission	UserPlus	5	active	{"permission": "scm:supplier_admission:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
79ae3cb9-b766-4b71-8eea-b9bafa4bd744	\N	49fda5bf-c812-4dce-807d-2a37a05bae2c	\N	仪表盘	scm-dashboard	/scm/dashboard	LayoutDashboard	0	active	{"permission": "scm:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
dfffcc01-7bdc-44a4-87c5-83dd8d244945	\N	98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	供应商评估	scm-supplier-evaluation	/scm/supplier-evaluation	Award	1	active	{"permission": "scm:supplier_evaluation:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ac261437-b818-4163-8df4-0fe4889d8236	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	客户分群	crm-customer-segmentation	/crm/customer-segmentation	Layers	6	active	{"permission": "crm:customer_segmentation:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
7066b6fa-fa8a-420a-84ea-be6ef01f7996	\N	98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	交期预约	scm-delivery-appointment	/scm/delivery-appointment	Calendar	3	active	{"permission": "scm:delivery_appointment:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
01c37312-9a3a-4acc-af50-9438fe8ae200	\N	98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	MRP计划	scm-mrp-plan	/scm/mrp-plan	LayoutGrid	4	active	{"permission": "scm:mrp_plan:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
96cbc381-bdc5-489d-8041-2bf530287750	\N	98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	MRP建议	scm-mrp-suggestion	/scm/mrp-suggestion	Lightbulb	5	active	{"permission": "scm:mrp_suggestion:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
71c29469-1a19-4f69-9207-6f504528d9fc	\N	98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	采购合同	scm-purchase-contract	/scm/purchase-contract	FileText	6	active	{"permission": "scm:contract:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
30575d71-16f1-4d97-83fa-aca327a2d407	\N	ce6cd55f-1377-4574-ae9d-9cc15a03e22b	\N	供应商评估	srm-evaluation	/srm/evaluation	Star	1	active	{"permission": "srm:evaluation:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
119f7bdd-7e2c-46e9-9b07-05467daaf45d	\N	ce6cd55f-1377-4574-ae9d-9cc15a03e22b	\N	绩效分析	srm-performance	/srm/performance	TrendingUp	2	active	{"permission": "srm:performance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
0750d0ae-8cfd-4384-bc1d-a2d5d5d239a3	\N	33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	供应商管理	srm-supplier	/srm/supplier	Building2	1	active	{"permission": "srm:supplier:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
1010eb08-9e0f-43da-8fc0-b23bdeba1b59	\N	33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	品类管理	srm-category	/srm/category	Tags	2	active	{"permission": "srm:category:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
38fffd42-6549-4611-9afc-5349828996d5	\N	33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	产品管理	srm-product	/srm/product	Package	3	active	{"permission": "srm:product:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
83a3843e-004b-4413-a709-410f4ba64d4e	\N	33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	合同管理	srm-contract	/srm/contract	FileCheck	4	active	{"permission": "srm:contract:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
78e7447f-637f-466e-b9bf-acd2dad3f55e	\N	33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	采购订单	srm-order	/srm/order	ShoppingCart	5	active	{"permission": "srm:order:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ea8f4d14-ffba-4113-93f4-c06b786d1dd8	\N	33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	财务管理	srm-finance	/srm/finance	Wallet	6	active	{"permission": "srm:finance:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
34f78a26-7115-4e52-b8b2-7d92f5e46f0a	\N	33b5eef1-6f06-403d-bfe3-4fe8f4e6cdc3	\N	供应商门户	srm-portal	/srm/portal	ExternalLink	7	active	{"permission": "srm:portal:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
74cd6290-bebf-4064-9443-13221464ad00	\N	5338990a-ef78-4d0a-8ba5-244b3675233a	\N	仪表盘	srm-dashboard	/srm/dashboard	LayoutDashboard	0	active	{"permission": "srm:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
c09be252-9bdc-44f9-8f5e-6a9aff3620b8	\N	abca79a9-d15f-4c40-950b-75aaff9d9b64	\N	询报价管理	srm-inquiry	/srm/inquiry	MessageSquareQuote	1	active	{"permission": "srm:inquiry:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
b375c61b-bd41-458b-aa2b-879ccc0a7c3d	\N	abca79a9-d15f-4c40-950b-75aaff9d9b64	\N	招标管理	srm-bidding	/srm/bidding	Award	2	active	{"permission": "srm:bidding:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
19e3e799-5af9-4f6f-9ef0-ce870d04b36b	\N	abca79a9-d15f-4c40-950b-75aaff9d9b64	\N	报价管理	srm-quotation	/srm/quotation	FileText	3	active	{"permission": "srm:quotation:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
e133dc25-88ae-4ba5-a2ea-f94ccb1e5d50	\N	4a281af2-b8c9-494e-a0e2-d48bec0b15c2	\N	评分维度	srm-scoring-dimension	/srm/scoring-dimension	Target	1	active	{"permission": "srm:evaluation:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
59f729b8-4e7f-4ee3-8a14-f15ada483590	\N	240fb6a1-5509-45dc-9053-d000abb2236d	\N	报表	report-report	/report/report	FileSpreadsheet	4	active	{"permission": "report:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
61f8fa84-477f-4112-a6d3-da6886d5c1b1	\N	240fb6a1-5509-45dc-9053-d000abb2236d	\N	报表构建	report-builder	/report/builder	Blocks	3	active	{"permission": "report:builder:write"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
40ad89c5-aa6f-4c12-8330-b2aacf883ca2	\N	240fb6a1-5509-45dc-9053-d000abb2236d	\N	报表设计	report-design	/report/design	Wand2	2	active	{"permission": "report:design:write"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8782c1db-e498-46ee-a4a9-2a480e233426	\N	240fb6a1-5509-45dc-9053-d000abb2236d	\N	报表列表	report-list	/report/list	List	1	active	{"permission": "report:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
1077fc93-81d9-486d-b5e5-719b6fcb8e5c	\N	a7155705-ee27-4e1c-a965-a2646426b3c9	\N	报表中心	report-dashboard	/report/dashboard	LayoutDashboard	0	active	{"permission": "report:dashboard:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
1e10b2ca-1130-4be3-b8c1-8f16f3f16ee1	\N	c173f2c7-491a-4388-9e5d-b5bf378c7490	\N	报表订阅	report-subscription	/report/subscription	Bell	2	active	{"permission": "report:subscription:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
47256458-f182-417e-972a-6d9aae54f375	\N	c173f2c7-491a-4388-9e5d-b5bf378c7490	\N	定时任务	report-schedule	/report/schedule	Clock	1	active	{"permission": "report:schedule:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8b771066-ade0-4ef6-b0d7-ddfe49f2802c	\N	82bce5fe-e7d2-46a9-97e7-75b83570ade4	\N	模板管理	report-template	/report/template	FolderKanban	1	active	{"permission": "report:template:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
7e006174-e92e-4f62-92b1-9ca7011424f5	\N	676a32bb-5dbd-4b0d-9c05-6685789fb78b	\N	项目报表	pm-reports	/pm/reports	BarChart3	1	active	{"permission": "pm:report:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
6e04ec6c-a108-46d5-b2f3-c0546bc57992	\N	6bbbf37b-84d0-49a9-89f1-f9f0c440eddb	\N	合同管理	pm-contracts	/pm/contracts	FileText	2	active	{"permission": "pm:contract:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
205917b5-f8cb-4511-8d8b-9896dc75aace	\N	6bbbf37b-84d0-49a9-89f1-f9f0c440eddb	\N	项目列表	pm-projects	/pm/projects	FolderKanban	1	active	{"permission": "pm:project:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
ec21195e-e554-4ef6-b977-4115059aaa75	\N	4b775d8c-6659-4082-928a-b9b5bcf7b81a	\N	仪表盘	pm-dashboard	/pm/dashboard	LayoutDashboard	0	active	{"permission": "pm:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
84ece469-4422-4918-b99a-79916f2eae66	\N	f102cfb6-ff27-44bd-88ec-2389ed0fcc31	\N	模板管理	pm-templates	/pm/templates	LayoutTemplate	2	active	{"permission": "pm:template:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
3639c14b-1c22-45c8-9b8c-888f0c38bffb	\N	f102cfb6-ff27-44bd-88ec-2389ed0fcc31	\N	资源管理	pm-resources	/pm/resources	Users	1	active	{"permission": "pm:resource:read"}	2026-10-26 14:01:29.447011+08	2026-10-26 14:01:29.447011+08	\N
8bd06600-bb45-450e-ada2-5869ccd86245	\N	973dce82-ca38-4813-99a3-8791843cc370	\N	RFM 分析	crm-rfm	/crm/rfm	Activity	100	active	{"permission": "crm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
5d8c5df9-18e0-4e50-b329-917538291c77	\N	973dce82-ca38-4813-99a3-8791843cc370	\N	预测算法	crm-forecast-algorithm	/crm/forecast-algorithm	Calculator	101	active	{"permission": "crm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
77a37ab3-af8d-44a3-b9f3-e0f3d7ecf1ec	\N	25cb9763-4307-49b9-9b0b-70732600eb34	\N	crm-tags	crm-tags	/crm/tags	Tags	102	active	{"permission": "crm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
e3087797-4610-4bd0-914e-7de7441e9cbb	\N	d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	合并报表中心	finance-consolidation-reports	/finance/consolidation-reports	FileSpreadsheet	100	active	{"permission": "finance:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
37fde825-5079-415d-bcf6-aa977b8de474	\N	abca96b5-c469-4769-890f-a709c83b2904	\N	预算明细	finance-budget-detail	/finance/budget-detail	PieChart	101	active	{"permission": "finance:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
6f227006-e57d-470b-a8cd-2eb225b5e6cd	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	培训计划	hrm-training-plan	/hrm/setting/training-plan	GraduationCap	104	active	{"permission": "hrm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
e2907732-00ac-47f3-80f7-a0933a443670	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	招聘流程	hrm-recruitment-flow	/hrm/setting/recruitment-flow	UserPlus	103	active	{"permission": "hrm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
c2093e17-36d0-42fb-964d-3db32634d82f	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	薪资模板	hrm-payroll-template	/hrm/setting/payroll-template	Wallet	102	active	{"permission": "hrm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
19aaf2ea-ffae-475f-83fe-9dfcd9d421cb	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	考勤规则	hrm-attendance-rule	/hrm/setting/attendance-rule	Clock	101	active	{"permission": "hrm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
849eb9ee-7af1-43c2-a70c-7a6b6ee38a5f	\N	4b11a313-324f-45d8-af76-813ebff97bc0	\N	系统初始化	hrm-setup	/hrm/setup	Settings	100	active	{"permission": "hrm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
e67fe100-9e05-4fdd-ae43-d257f29186c1	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	仪器数据	lims-instrument-data	/lims/instrument-data	Database	100	active	{"permission": "lims:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
ee7504e9-829c-4d34-ad84-eb10fba7bf4d	\N	cdf6285c-d10e-42c5-8970-ccf651af3b07	\N	lims-method-categories	lims-method-categories	/lims/method-categories	Layers	101	active	{"permission": "lims:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
f5deaab3-dc6b-4138-966c-ed0612f77a5a	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	物料BOM	mes-material-bom	/mes/material-bom	GitBranch	100	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
239322a4-bb26-45fe-9013-9cc93ead7a1d	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	物料领用	mes-material-issue	/mes/material-issue	ArrowUpFromLine	101	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
a2d1f450-03dc-4584-a005-2d26a43eb9e8	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	物料退库	mes-material-return	/mes/material-return	ArrowDownToLine	102	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
9602cbe7-9ad7-4ecb-86bb-f0463f2aa62b	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	OEE分析	mes-analytics-oee	/mes/analytics/oee	Gauge	103	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
3d14b961-3e9c-474c-86c3-267819d05fc7	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	交付分析	mes-analytics-delivery	/mes/analytics/delivery	Truck	104	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
5dac6f0a-0802-4192-90ea-46f230ea7a10	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	质量帕累托	mes-analytics-quality-pareto	/mes/analytics/quality-pareto	BarChart3	105	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
814a7322-fde3-42a5-8f09-86b655965cee	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	MTBF分析	mes-analytics-mtbf	/mes/analytics/mtbf	Wrench	106	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
ea3e9d1f-81e2-4170-8187-c58c4a88e345	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	能耗分析	mes-analytics-energy	/mes/analytics/energy	Zap	107	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
6c8912e9-8b30-45e5-8d1b-149970bb7dc0	\N	5be9b947-9e63-4c94-a7e7-d6c150bb1490	\N	产能分析	mes-analytics-capacity	/mes/analytics/capacity	TrendingUp	108	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
75bc4c1c-3a03-4eff-bdde-7c1533565fdc	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	质检模板	mes-quality-template	/mes/setting/quality-template	ClipboardCheck	109	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
6b19bd7e-d059-4472-9b93-be65772b391b	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	BOM版本策略	mes-bom-version-policy	/mes/setting/bom-version-policy	GitBranch	110	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
2bf8a594-48a7-4009-bb17-2718ff33c306	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	APS配置	mes-aps-config	/mes/setting/aps-config	Settings2	111	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
6d538fe6-4cd6-40d5-a939-fd0d3c14eb8d	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	设备预警阈值	mes-equipment-threshold	/mes/setting/equipment-threshold	Gauge	112	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
cdef33b8-e13c-4e50-bd95-c868b9f248f9	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	主数据	mes-master-data	/mes/master-data	Factory	113	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
94218b87-5de5-4d9b-804d-00b4707029c7	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	mes-capacity	mes-capacity	/mes/capacity	CalendarDays	114	active	{"permission": "mes:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
dd16353a-470d-49d3-86e9-e7a2d2201743	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	变更模板	pdm-change-template	/pdm/setting/change-template	RefreshCw	104	active	{"permission": "pdm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
72cff5ce-b0cf-451f-a054-8611e0113811	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	文档审批流	pdm-doc-approval-flow	/pdm/setting/doc-approval-flow	FileCheck	103	active	{"permission": "pdm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
f2b9a5fc-c5c1-4d92-ad38-feb1aa5ef8bc	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	分类规则	pdm-category-rule	/pdm/setting/category-rule	Tags	102	active	{"permission": "pdm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
137456b6-5a53-4a6f-9246-f13a9f91782a	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	BOM 模板	pdm-bom-template	/pdm/setting/bom-template	GitBranch	101	active	{"permission": "pdm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
2e9e7c0e-3a5a-49b5-bb96-8ea9dd43d5a1	\N	4a9ebbed-4f7b-4393-af1a-6002f1a0acbb	\N	图纸管理	pdm-drawing	/pdm/drawing	FileText	100	active	{"permission": "pdm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
2a5781f6-eaf1-422f-a1c4-9bf263e90761	\N	676a32bb-5dbd-4b0d-9c05-6685789fb78b	\N	项目时间线	pm-timeline	/pm/timeline	Clock	104	active	{"permission": "pm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
eacc4633-ef09-4d33-a48f-cecf5c32f2f1	\N	6bbbf37b-84d0-49a9-89f1-f9f0c440eddb	\N	项目向导	pm-project-wizard	/pm/project-wizard	Wand2	102	active	{"permission": "pm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
1748c0e3-20e4-4ce2-aee3-6a65247c5ece	\N	6bbbf37b-84d0-49a9-89f1-f9f0c440eddb	\N	任务看板	pm-task-kanban	/pm/task-kanban	SquareKanban	101	active	{"permission": "pm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
fc1478e0-e81a-4e3f-9683-5ddee025558e	\N	6bbbf37b-84d0-49a9-89f1-f9f0c440eddb	\N	项目列表	pm-project-list	/pm/project-list	ListTree	100	active	{"permission": "pm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
d4320a25-5e69-446c-b9eb-cce8446b92f5	\N	f102cfb6-ff27-44bd-88ec-2389ed0fcc31	\N	项目类型模板	pm-project-type-config	/pm/project-type-config	ClipboardList	103	active	{"permission": "pm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
3c17e159-2446-49e3-a60f-d045f4326f67	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	合规审核	qms-audit-compliance	/qms/analytics/audit-compliance	ShieldCheck	107	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
0532ab77-35fe-49cf-90f2-b2f86ee5c69c	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	风险矩阵	qms-fmea-risk-matrix	/qms/analytics/fmea-risk-matrix	Grid3x3	105	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
2c0407d5-431f-4668-90a2-8d9b9412481e	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	控制图	qms-spc-control-chart	/qms/analytics/spc-control-chart	Activity	104	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
ea5eb154-4514-46a1-b8f5-3c01b1f95501	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	成本分析	qms-cost-analysis	/qms/analytics/cost-analysis	PieChart	103	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
77def789-40e3-4ba3-9c67-6f6b90100fe2	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	缺陷帕累托	qms-defect-pareto	/qms/analytics/defect-pareto	BarChart3	102	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
eefb6cff-faf8-4582-9a51-30ce962b58d5	\N	297a35e6-1e85-4a0d-ace2-da76fcb20ed0	\N	质量趋势	qms-quality-trend	/qms/analytics/quality-trend	LineChart	101	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
269aef4a-e001-48e5-83c6-2b058fe7b82a	\N	a7dfc40b-3650-41c8-8750-9ba13d29cf7d	\N	检验标准配置	qms-inspection-standard	/qms/inspection-standard	ClipboardList	106	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
7af997e8-1258-42fc-98cd-ea180beb905b	\N	a7dfc40b-3650-41c8-8750-9ba13d29cf7d	\N	纠正措施	qms-corrective-actions	/qms/corrective-actions	Wrench	100	active	{"permission": "qms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
c4431cb5-80f4-4377-85c6-55e7edb79336	\N	240fb6a1-5509-45dc-9053-d000abb2236d	\N	报表查看	report-viewer	/report/viewer	Eye	100	active	{"permission": "report:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
211196b5-2244-4968-a391-be98af54700b	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	供应商分级	scm-supplier-tier	/scm/setting/supplier-tier	Award	105	active	{"permission": "scm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
2630a901-64a3-4e0e-95c6-0e3705660b07	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	采购阈值	scm-purchase-threshold	/scm/setting/purchase-threshold	AlertTriangle	104	active	{"permission": "scm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
731d9412-bf3f-47bc-b9b2-40310089bf19	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	配额模板	scm-quota-template	/scm/setting/quota-template	PieChart	103	active	{"permission": "scm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
4a08d408-be68-4609-8154-41db40475577	\N	16fac7d0-222e-4d36-953b-9f6c72d9b144	\N	寻源策略	scm-sourcing-strategy	/scm/setting/sourcing-strategy	Search	102	active	{"permission": "scm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
d55f5beb-34a5-476c-948c-0698b1c8db88	\N	98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	来料检验	scm-incoming-inspections	/scm/incoming-inspections	ClipboardCheck	101	active	{"permission": "scm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
6acb37e5-4584-48b2-9bfa-f091182e3666	\N	98645495-a9c8-450d-a0d7-19b2c1fe6329	\N	到货通知	scm-incoming-notices	/scm/incoming-notices	Truck	100	active	{"permission": "scm:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
ece4e501-1e0e-451d-9530-46b480669fc8	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	订单履约	wms-analytics-fulfillment	/wms/analytics/order-fulfillment	Gauge	105	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
aea206d3-f67b-4512-b729-1a4224486512	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	库位利用率	wms-analytics-locutil	/wms/analytics/location-utilization	MapPin	104	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
f5a4685f-103a-4348-a388-c233774aceb2	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	ABC 分析	wms-analytics-abc	/wms/analytics/abc-analysis	PieChart	103	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
4267e4a0-a071-49ac-b702-fbc5fa9b3824	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	出入库趋势	wms-analytics-flow	/wms/analytics/flow-trend	AreaChart	102	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
dd85fc72-d564-4c31-afec-07a8343d3d52	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	帕累托分析	wms-analytics-pareto	/wms/analytics/age-pareto	BarChart2	101	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
21a73d3a-3762-42f3-82b9-859f83f0e9e4	\N	bc25b48b-81b5-4906-8f46-ef596f7802a2	\N	库存周转分析	wms-analytics-turnover	/wms/analytics/inventory-turnover	TrendingUp	100	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
60277653-0e1b-4602-938a-9f5467c1854c	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	库存阈值设置	wms-inventory-threshold	/wms/setting/inventory-threshold	AlertTriangle	109	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
859b8cf8-2e6a-4c86-ad2c-840b48373239	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	盘点周期设置	wms-inventory-cycle	/wms/setting/inventory-cycle	ClipboardCheck	108	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
0dea960a-849d-4110-b57a-50857f5bc2cd	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	FIFO 策略	wms-fifo-policy	/wms/setting/fifo-policy	ArrowRightLeft	107	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
4c1a7327-ddff-4cf6-ad9f-837ed567af87	\N	bc7346a7-b86a-417c-82cd-0337dd065848	\N	库位规则	wms-location-rule	/wms/setting/location-rule	MapPin	106	active	{"permission": "wms:read"}	2026-11-02 12:26:59.798044+08	2026-11-02 12:26:59.798044+08	\N
27e5dfcd-50cd-49ec-932b-a98d1723043c	\N	8db6dbe3-9cce-4648-b626-fcedb74010b2	\N	工位管理	mes-work-stations	/mes/workstations	MapPin	4	active	{"permission": "mes:work_station:read"}	2026-10-26 14:01:29.447011+08	2026-11-02 12:26:59.802176+08	\N
3ad37e90-e791-4688-bdbe-4cf6c4986351	\N	6e0e0eb1-deab-4462-ba99-667e45705e0d	\N	运输仪表盘	tms-dashboard	/tms/dashboard	LayoutDashboard	1	active	{"permission": "tms:dashboard:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
caa0de06-ddd2-46cb-b980-ed65fc7a829f	\N	98a42ca6-5251-4e63-ba51-fcfd5d656dc5	\N	路线管理	tms-routes	/tms/routes	Route	5	active	{"permission": "tms:route:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
ba1d93f4-20e8-4449-acd8-0c045e0e8fc8	\N	98a42ca6-5251-4e63-ba51-fcfd5d656dc5	\N	承运商管理	tms-carriers	/tms/carriers	Building	4	active	{"permission": "tms:carrier:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
453c0edd-72aa-4be3-bf4d-63a42b936ee2	\N	4241e3b2-5cb1-419e-927f-2ae3e6384474	\N	资产仪表盘	asset-dashboard	/asset/dashboard	LayoutDashboard	1	active	{"permission": "asset:dashboard:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
c9732f53-a567-4185-a4ef-4451cdc62747	\N	ac1a23c2-7bae-49c2-95ab-f0d45410f0f3	\N	资产台账	asset-list	/asset/list	FileText	2	active	{"permission": "asset:list:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
2ebb5cc1-9738-4ac4-b345-b59c096c1ad9	\N	2f87316c-8422-44ef-b0b0-7bcb5f5e2466	\N	资产分类	asset-categories	/asset/categories	Tags	3	active	{"permission": "asset:category:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
ca1936d8-773c-4d29-846b-5ff6197f10a3	\N	bcccf4f3-a36c-4c80-b2b1-67a37e986933	\N	折旧分析	asset-depreciation	/asset/depreciation	TrendingDown	4	active	{"permission": "asset:depreciation:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
ac6d8ac8-c7fc-499d-ba18-01a836a9095f	\N	18404d54-5552-439e-a121-19a0a96f3768	\N	资产调拨	asset-transfers	/asset/transfers	ArrowRightLeft	5	active	{"permission": "asset:transfer:read"}	2026-11-02 12:26:59.812281+08	2026-11-02 12:26:59.812281+08	\N
78315793-d28b-491b-9cce-418a4f6d0c50	\N	dbf10a25-081c-436c-81a1-dba1b4311f46	\N	系统仪表盘	admin-dashboard	/admin/dashboard	LayoutDashboard	1	active	{"permission": "admin:dashboard:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
aad3f41b-53b4-48dc-bde6-e6a652fc8335	\N	e03c2f6d-a558-44a2-a5bc-a323dc957f14	\N	数据库管理	admin-database	/admin/database	Database	10	active	{"permission": "admin:database:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
8ff33148-5ace-45a2-8976-a0682806f7a5	\N	e03c2f6d-a558-44a2-a5bc-a323dc957f14	\N	平台银行账户	admin-bank-account	/admin/bank-account	CreditCard	5	active	{"permission": "admin:bank:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
286e39af-ef80-436f-97ec-ba8fc0122053	\N	e03c2f6d-a558-44a2-a5bc-a323dc957f14	\N	账号管理	admin-account	/admin/account	UserCircle	4	active	{"permission": "admin:account:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
f8bbc8e6-f66b-4b8d-81c9-4caa664c3a90	\N	e03c2f6d-a558-44a2-a5bc-a323dc957f14	\N	租户计费	admin-tenant-billing	/admin/tenant-billing	Wallet	3	active	{"permission": "admin:tenant:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
c38613db-d07d-4263-a571-7fc7c87063ed	\N	e03c2f6d-a558-44a2-a5bc-a323dc957f14	\N	租户管理	admin-tenant	/admin/tenant	Building2	2	active	{"permission": "admin:tenant:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
0ca18075-1bf8-45f5-b2f6-8834907614bf	\N	aac20b2b-c3e5-4f1e-95a6-56116e9151ba	\N	性能监控	admin-performance	/admin/performance	Gauge	18	active	{"permission": "admin:monitor:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
95088f32-41e9-4be4-949f-bb041befe960	\N	aac20b2b-c3e5-4f1e-95a6-56116e9151ba	\N	系统监控	admin-monitor	/admin/monitor	Activity	17	active	{"permission": "admin:monitor:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
e9dc6e80-a684-488c-bdc1-328919687e5f	\N	aac20b2b-c3e5-4f1e-95a6-56116e9151ba	\N	审计日志	admin-audit-log	/admin/audit-log	ScrollText	13	active	{"permission": "admin:audit:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
edff2205-8a6e-49ed-a50b-5ba939ac1a57	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	灾备管理	master-disaster-recovery	/master/disaster-recovery	LifeBuoy	12	active	{"permission": "master-data:disaster:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
ead0bbb6-117b-4a64-9022-d83c85a924f0	\N	d2bfae87-824c-4e53-9a92-e0e937cbbc64	\N	语义检索	master-semantic-search	/master/semantic-search	Search	11	active	{"permission": "master-data:semantic:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
70194f6b-643d-4484-97cc-a39f31c640e6	\N	d3336cde-1fe3-4a61-8269-ffc46d68dd4c	\N	自动化仪表盘	automation-dashboard	/automation/dashboard	LayoutDashboard	1	active	{"permission": "automation:dashboard:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
28f373bc-fc8a-4908-9c78-4b937899efb3	\N	2eeb8ce9-17ba-4af0-abbf-cea4d0c559f3	\N	流程设计器	automation-designer	/automation/designer	Workflow	4	active	{"permission": "automation:rule:write"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
c48cebaa-4d97-438f-a60b-9c618b440d51	\N	2eeb8ce9-17ba-4af0-abbf-cea4d0c559f3	\N	规则管理	automation-rules	/automation/rules	Zap	2	active	{"permission": "automation:rule:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
0443b935-94e9-4bbf-9c26-0fa27879fbd2	\N	b0acf438-ba5c-403f-b853-d0884d19fa8a	\N	运行记录	automation-runs	/automation/runs	History	3	active	{"permission": "automation:run:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
e4d5e054-aa97-4994-8187-f402671d09d7	\N	1f2148e9-b5ab-46ed-9ab2-174a7d9d532e	\N	变量管理	automation-variables	/automation/variables	KeyRound	5	active	{"permission": "automation:variable:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
4269806a-f8de-4041-8da2-e9cfa79daa20	\N	1d033415-afb5-478a-8714-cf6e4754e716	\N	监控仪表盘	monitor-dashboard	/monitor/dashboard	LayoutDashboard	1	active	{"permission": "monitor:dashboard:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
633b11ab-483d-4389-91a4-18ea0a83e4db	\N	1b44b62a-dfef-46c5-ab76-b900960c0fa4	\N	告警管理	monitor-alerts	/monitor/alerts	AlertTriangle	2	active	{"permission": "monitor:alert:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
3f9652da-e2e6-4a1a-a0ca-1f4829e77fa4	\N	073e2ccf-f4aa-4764-a8d5-7a27ca35cb9a	\N	告警历史	monitor-alert-history	/monitor/alerts/history	History	3	active	{"permission": "monitor:alert:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
721343cd-c908-44fd-878c-6c785a14ccec	\N	aed445cb-3309-4ba1-872c-b85810e164cb	\N	监控设置	monitor-settings	/monitor/settings	Settings	7	active	{"permission": "monitor:dashboard:admin"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
d76bce96-7918-4054-9904-ac446f901ae2	\N	aed445cb-3309-4ba1-872c-b85810e164cb	\N	告警规则	monitor-rules	/monitor/rules	Settings	4	active	{"permission": "monitor:rule:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
251bcacc-f14c-4761-b28f-cf825085ba4c	\N	4f9fa549-037b-4a52-be06-100323c337df	\N	日志查询	monitor-logs	/monitor/logs	FileText	6	active	{"permission": "monitor:log:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
e44071bb-a828-42f0-9b71-885bf1eed0e2	\N	4f9fa549-037b-4a52-be06-100323c337df	\N	指标监控	monitor-metrics	/monitor/metrics	BarChart3	5	active	{"permission": "monitor:metric:read"}	2026-11-02 12:26:59.814156+08	2026-11-02 12:26:59.814156+08	\N
8e9ab126-3f80-4009-808e-fe2f8b7f6233	\N	be881738-26d7-4782-8dff-0ef8cf1cf090	\N	身份仪表盘	iam-dashboard	/iam/dashboard	LayoutDashboard	1	active	{"permission": "iam:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
4a84647b-9235-417f-b539-eae141c68e55	\N	20a34097-75fd-4c1f-b015-ce79daddad91	\N	组织架构	iam-company-structure	/iam/company-structure	Network	5	active	{"permission": "iam:structure:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
77733875-f5ce-4566-bc32-c192db0159f8	\N	20a34097-75fd-4c1f-b015-ce79daddad91	\N	权限管理	iam-permission	/iam/permission	Key	4	active	{"permission": "iam:permission:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
26fb2bd0-669d-41bd-bda3-ddce788dfe12	\N	20a34097-75fd-4c1f-b015-ce79daddad91	\N	角色管理	iam-role	/iam/role	UserCheck	3	active	{"permission": "iam:role:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
edde8a92-bae5-477b-a050-1415f547e0de	\N	20a34097-75fd-4c1f-b015-ce79daddad91	\N	用户管理	iam-user	/iam/user	Users	2	active	{"permission": "iam:user:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e487246b-74cf-4b0a-8b87-b7ead6b6439a	\N	f7b5b451-10a3-416d-ac06-4678daa89b56	\N	AI 治理看板	ai-governanceDashboard	/ai/governanceDashboard	Shield	11	active	{"permission": "ai:governance:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e3040898-ddb8-4966-8a62-23bf3074f5e2	\N	f7b5b451-10a3-416d-ac06-4678daa89b56	\N	AI 仪表盘	ai-dashboard	/ai/dashboard	LayoutDashboard	1	active	{"permission": "ai:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
de83c2b8-16c3-476f-90eb-bd3e08bd6864	\N	d509cf72-6212-4bcf-9654-85b5e394ff1d	\N	Dify 对话	ai-dify-chat	/ai/dify-chat	Bot	9	active	{"permission": "ai:chat:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
0f393544-24ff-4cd9-9eb3-06a4570cbe76	\N	d509cf72-6212-4bcf-9654-85b5e394ff1d	\N	智能助手	ai-assistant	/ai/assistant	Sparkles	8	active	{"permission": "ai:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
9ccdd568-c882-4580-9e20-b6f7bdbf19d2	\N	d509cf72-6212-4bcf-9654-85b5e394ff1d	\N	AI 代码	ai-code	/ai/code	Code	3	active	{"permission": "ai:code:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
286fc84a-2bbb-4f5d-a043-1ea9fc2f3319	\N	d509cf72-6212-4bcf-9654-85b5e394ff1d	\N	AI 对话	ai-chat	/ai/chat	MessageSquare	2	active	{"permission": "ai:chat:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
1760d660-ac32-4493-952c-d9cf775110bb	\N	fac90620-11a7-431b-bdef-603b4f90360c	\N	集成仪表盘	integration-dashboard	/integration/dashboard	LayoutDashboard	1	active	{"permission": "integration:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
ab57e744-1388-4b8f-a8b6-88106842c0ac	\N	b03246e2-4458-4ec9-9aa2-1776cb15227c	\N	映射配置	integration-mappings	/integration/mappings	GitMerge	3	active	{"permission": "integration:mapping:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
52e64a5f-7d04-4408-8fcb-cdbde6c85db7	\N	b03246e2-4458-4ec9-9aa2-1776cb15227c	\N	连接管理	integration-connections	/integration/connections	Plug	2	active	{"permission": "integration:connection:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
d227eb21-08e2-492e-9bef-82cd2946f914	\N	42994238-38f7-48f5-b40b-a40be68a47a9	\N	事件中心	integration-events	/integration/events	Activity	4	active	{"permission": "integration:event:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
06288caa-5dae-4113-873b-c79527cfebba	\N	0b38f8fe-d89f-4273-8bbb-319fb6b63aa1	\N	WMS-SCM 集成	integration-wms-scm	/integration/wms-scm	Warehouse	8	active	{"permission": "integration:wms:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
fe45c260-95a2-4931-9fb3-4f130fba4b8f	\N	6afa1624-0a11-4178-974a-d20382ea2639	\N	研发总览	rd-overview	/rd/overview	Grid3X3	2	active	{"permission": "rd:overview:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
4d0ebb1f-b825-41c4-810c-40141ce332eb	\N	6afa1624-0a11-4178-974a-d20382ea2639	\N	研发仪表盘	rd-dashboard	/rd/dashboard	LayoutDashboard	1	active	{"permission": "rd:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
2edcd1c1-1d37-449b-b4ae-38871a43579e	\N	6e4cce42-b58f-4d4f-8483-36d582fd7000	\N	研发文档	rd-doc	/rd/doc	FileText	15	active	{"permission": "rd:doc:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
adf39120-f08f-41cb-9d15-1755a8200f8b	\N	6e4cce42-b58f-4d4f-8483-36d582fd7000	\N	代码管理	rd-code	/rd/code	Code2	7	active	{"permission": "rd:code:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
16cefcf4-0401-4556-b506-27d54c941763	\N	6e4cce42-b58f-4d4f-8483-36d582fd7000	\N	实验管理	rd-experiment	/rd/experiment	FlaskRound	4	active	{"permission": "rd:experiment:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e7e3ad5e-2e1c-45bf-bf9e-abe2612dcaf4	\N	6e4cce42-b58f-4d4f-8483-36d582fd7000	\N	项目管理	rd-project	/rd/project	FolderKanban	3	active	{"permission": "rd:project:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
da952834-c9e5-45ec-8558-6fd3b7584742	\N	7164c85a-3c19-4a14-a0bf-464f2e8fd82b	\N	物料管理	rd-material	/rd/material	Layers	6	active	{"permission": "rd:material:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
f6d184be-5aef-4235-84d3-402d4931f7eb	\N	7164c85a-3c19-4a14-a0bf-464f2e8fd82b	\N	配方管理	rd-formula	/rd/formula	Beaker	5	active	{"permission": "rd:formula:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
4ed50b2f-5259-4981-ba9e-e3c155acf9ec	\N	e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	里程碑	rd-milestone	/rd/milestone	Flag	14	active	{"permission": "rd:milestone:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
a09b179c-e89b-4920-9e44-e959ffff5d35	\N	e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	发布管理	rd-release	/rd/release	Rocket	13	active	{"permission": "rd:release:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
ccd2b233-0cb4-4cd5-9e70-f0776a7a30b9	\N	e84e82a7-071c-4192-b700-f7e2cb0cdb1e	\N	测试管理	rd-test	/rd/test	Bug	9	active	{"permission": "rd:test:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
1f1b8293-0f77-4676-9d25-95c974107f9b	\N	e1a73253-f129-428b-b987-8124ccf13b41	\N	通知仪表盘	notification-dashboard	/notification/dashboard	LayoutDashboard	1	active	{"permission": "notification:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
1caf917a-356e-4b06-9a07-e9776bf76916	\N	3b69aa66-8301-419e-8ae0-24790fff1f96	\N	通知设置	notification-settings	/notification/settings	Settings	7	active	{"permission": "notification:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
547486ec-5f89-4cc1-8ab2-e88d071d3db0	\N	3b69aa66-8301-419e-8ae0-24790fff1f96	\N	通知模板	notification-templates	/notification/templates	FileText	5	active	{"permission": "notification:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e840c1da-6466-439a-98c4-fa8a55e1e8de	\N	3b69aa66-8301-419e-8ae0-24790fff1f96	\N	通知中心	notification-center	/notification/center	Bell	4	active	{"permission": "notification:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
90db2e34-a402-4b8f-9e04-774c48ead548	\N	3b69aa66-8301-419e-8ae0-24790fff1f96	\N	通知归档	notification-archive	/notification/archive	Archive	3	active	{"permission": "notification:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e5a0f1f9-c7f6-4d6f-95dc-fa56545f9ca4	\N	3b69aa66-8301-419e-8ae0-24790fff1f96	\N	通知列表	notification-list	/notification/list	ScrollText	2	active	{"permission": "notification:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
848cc8e9-81be-447e-ba75-d572ac39cc59	\N	82449dd4-6c16-47ec-815d-80ac9247c5d3	\N	通知统计	notification-statistics	/notification/statistics	BarChart3	6	active	{"permission": "notification:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
27434474-03c0-4afb-b3e2-9683be67b123	\N	056e6540-b643-4fa6-afc6-f7a8440411fd	\N	OA 仪表盘	oa-dashboard	/oa/dashboard	LayoutDashboard	1	active	{"permission": "oa:dashboard:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
e7450b79-235e-4bbe-ae54-77993bb808e0	\N	07c6b941-2a7b-4895-be92-860acf2bebda	\N	车辆管理	oa-vehicles	/oa/vehicles	FileText	5	active	{"permission": "oa:vehicle:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
26338b15-892c-4e90-b49b-1f7f7f887fcd	\N	07c6b941-2a7b-4895-be92-860acf2bebda	\N	公文管理	oa-documents	/oa/documents	FileText	2	active	{"permission": "oa:document:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
eec481a5-2c0d-4ad5-9ec3-c17b8f78f2ea	\N	f3d373eb-3e80-4c25-a882-5913795f41b5	\N	公告管理	oa-announcements	/oa/announcements	FileText	3	active	{"permission": "oa:announcement:read"}	2026-11-02 12:26:59.815779+08	2026-11-02 12:26:59.815779+08	\N
3afd18fa-f79e-4731-9754-788166fc32b2	\N	73cbe878-92b8-4628-bb7c-00589abf44e9	\N	GIS 仪表盘	gis-dashboard	/gis/dashboard	LayoutDashboard	1	active	{"permission": "gis:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
21bce591-682d-4fb9-8149-4357f4215b03	\N	943126fb-5fb8-45d2-9747-51bee009e0e7	\N	电子围栏	gis-fence	/gis/fence	MapPin	4	active	{"permission": "gis:fence:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
dfb3b160-af76-4bda-97a9-12729de984c5	\N	943126fb-5fb8-45d2-9747-51bee009e0e7	\N	轨迹追踪	gis-tracking	/gis/tracking	Navigation	3	active	{"permission": "gis:tracking:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
8f31d046-f938-4d98-82ea-02ac94b0426a	\N	943126fb-5fb8-45d2-9747-51bee009e0e7	\N	地图管理	gis-map	/gis/map	MapPin	2	active	{"permission": "gis:map:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
4f4cf31b-70f8-4764-886d-bfa4473c7ed0	\N	a5f43871-9da8-45b4-9812-9ed3d382a765	\N	设备定位	gis-devices	/gis/devices	MapPin	5	active	{"permission": "gis:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
83158051-61e7-4408-812e-41e4792b4ad6	\N	7f1c05e5-7afd-4b0d-9c9b-928cfaa3b81d	\N	插件仪表盘	plugin-dashboard	/plugin/dashboard	LayoutDashboard	1	active	{"permission": "plugin:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
d9c91989-66b2-4918-b86c-e1a880bb6d4e	\N	14ec8c58-ae32-4b5a-b302-8473e6755186	\N	插件上传	plugin-upload	/plugin/upload	Upload	3	active	{"permission": "admin:plugin:write"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
5ffe5b55-50c7-463f-a6c2-bee6210c11f9	\N	14ec8c58-ae32-4b5a-b302-8473e6755186	\N	插件市场	plugin-marketplace	/plugin/marketplace	ShoppingCart	2	active	{"permission": "plugin:marketplace:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
b04cbc74-8f74-43bc-82b6-f932a2bc9647	\N	68ea6181-fbef-43e1-9345-badee0f036b7	\N	文档仪表盘	doc-dashboard	/doc/dashboard	LayoutDashboard	1	active	{"permission": "doc:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
b3f92a82-96da-4a3e-bfda-ea0c26e9efd6	\N	4c71be4e-c78a-4814-ac9c-bfd0bad732c4	\N	文件详情	doc-file-detail	/doc/documents/:id	FileText	6	active	{"permission": "doc:document:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
0f8eaba5-58c9-4cd7-8d3c-e6e10e646133	\N	4c71be4e-c78a-4814-ac9c-bfd0bad732c4	\N	知识库	doc-knowledge-base	/doc/knowledge-base	BookOpen	5	active	{"permission": "doc:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
e2df8d7d-64bb-4575-be45-38443d6c3d4b	\N	4c71be4e-c78a-4814-ac9c-bfd0bad732c4	\N	文档中心	doc-document-center	/doc/document-center	FolderOpen	4	active	{"permission": "doc:center:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
d6158c9e-a219-4e1b-8313-fc15fc3db176	\N	4c71be4e-c78a-4814-ac9c-bfd0bad732c4	\N	文档管理	doc-documents	/doc/documents	FileText	3	active	{"permission": "doc:document:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
05fd6c23-ebee-457b-8d28-f4576a4f2823	\N	0bf2b4bc-a29f-4ca0-b8b7-80c1e98e7a34	\N	流程仪表盘	workflow-dashboard	/workflow/dashboard	LayoutDashboard	1	active	{"permission": "workflow:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
b0cd97d1-a938-454f-8cfe-1699ecc23537	\N	61c07c32-97c2-408b-82d4-e4fdb888257a	\N	流程通知	workflow-notification-center	/workflow/notification-center	Bell	7	active	{"permission": "workflow:notification:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
bb8ed7c4-2c38-4f8d-ac1c-5e9f12e47345	\N	61c07c32-97c2-408b-82d4-e4fdb888257a	\N	审批任务	workflow-approvals	/workflow/approvals	CheckSquare	6	active	{"permission": "workflow:approval:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
2b1a0ab5-d632-4f71-a7dd-c79571446d56	\N	61c07c32-97c2-408b-82d4-e4fdb888257a	\N	流程实例	workflow-instances	/workflow/instances	PlaySquare	5	active	{"permission": "workflow:instance:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
03ac8857-bac6-4d10-9f23-db3e4e5d7f21	\N	61c07c32-97c2-408b-82d4-e4fdb888257a	\N	版本历史	workflow-version-history	/workflow/version-history/:id?	History	4	active	{"permission": "workflow:definition:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
235e3008-a81b-466c-becd-07ab5bd030d6	\N	888147a9-20f3-4df2-9f50-0ae6b01fa39d	\N	工单仪表盘	ticket-dashboard	/ticket/dashboard	LayoutDashboard	1	active	{"permission": "ticket:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
e8b9d13d-1399-4706-a91c-865969c443fe	\N	59ff837f-a1ad-4c91-9ebc-b6832b416921	\N	工单中心	ticket-center	/ticket/center	Ticket	2	active	{"permission": "ticket:dashboard:read"}	2026-11-02 12:26:59.818429+08	2026-11-02 12:26:59.818429+08	\N
2362270e-f23a-47dd-b04b-6f07c9e43a8d	\N	9913602b-d7d9-4574-80fe-a8e526a346f3	\N	排程管理	aps-schedules	/aps/schedules	CalendarCheck	3	active	{"permission": "aps:schedule:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
1b766bdc-b7a8-4cbb-94de-716d054a2c36	\N	9913602b-d7d9-4574-80fe-a8e526a346f3	\N	生产计划	aps-production-plans	/aps/production-plans	ClipboardList	2	active	{"permission": "aps:production_plan:read"}	2026-11-02 14:56:32.962392+08	2026-11-02 14:56:32.962392+08	\N
a8241d89-fe56-4575-85fd-0aa157f02626	\N	acad5cf7-3d3b-4b9d-a0a3-3be115fc43d9	\N	分析概览	bi-dashboard	/bi/dashboard	LayoutDashboard	0	active	{"permission": "bi:dashboard:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
b7f574f8-e183-459c-817d-1fd09bcf3d22	\N	2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	销售分析	bi-data-analysis	/bi/data-analysis	LineChart	7	active	{"permission": "bi:analytics:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
14748bef-dd01-4b37-b998-9f6fca5d6e14	\N	2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	空间分析	bi-gis	/bi/gis	Map	6	active	{"permission": "bi:gis:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
dfa2e691-71e9-44c8-bbd6-c49d02f56864	\N	2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	报表设计器	bi-report-builder	/bi/report-builder	Wand2	5	active	{"permission": "bi:report:write"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
b5f2f67d-648a-47fb-8a58-5c3302acd60f	\N	2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	可视化	bi-visualization	/bi/visualization	PieChart	4	active	{"permission": "bi:visualization:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
1b10bdec-4a60-42bd-8053-d78df648934f	\N	2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	报表中心	bi-report	/bi/report	FileSpreadsheet	3	active	{"permission": "bi:report:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
f7a5d7e8-6770-4a8f-8b7a-10254db60549	\N	2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	对比分析	bi-comparison	/bi/comparison	GitCompare	2	active	{"permission": "bi:comparison:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
7dff8b9a-8419-4bd6-bb93-317c9cd111a8	\N	2c605f5d-f5c8-420f-ae8c-ebed98efa424	\N	数据分析	bi-analytics	/bi/analytics	TrendingUp	1	active	{"permission": "bi:analytics:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
69f5665a-53a0-4499-b893-69b3d9d3d9bd	\N	c3549484-9146-4b04-84c0-82e90369f3ca	\N	指标管理	bi-index	/bi/index	Target	4	active	{"permission": "bi:index:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
c4a1c47c-a2bc-438e-be25-10a46dff978e	\N	c3549484-9146-4b04-84c0-82e90369f3ca	\N	权限管理	bi-permission	/bi/permission	Lock	3	active	{"permission": "bi:dashboard:admin"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
6da7f2a0-c94e-4f98-a173-64d56aafa061	\N	c3549484-9146-4b04-84c0-82e90369f3ca	\N	数据集	bi-dataset	/bi/dataset	Table	2	active	{"permission": "bi:dataset:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
f3c3957a-24b9-49c2-97bb-10e3e7e41b93	\N	c3549484-9146-4b04-84c0-82e90369f3ca	\N	数据源	bi-data-source	/bi/data-source	Database	1	active	{"permission": "bi:data_source:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
0d42d23d-bfcd-439e-a023-55e400754398	\N	8873097f-a8d0-42f9-ac54-08bc1444cad3	\N	消息概览	im-dashboard	/im/dashboard	LayoutDashboard	0	active	{"permission": "im:dashboard:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
16754c87-f9f3-47e9-b5dc-8364418fa946	\N	079144de-930b-4c7c-8273-71be86fbd72b	\N	邮件管理	im-mail	/im/mail	Mail	1	active	{"permission": "im:mail:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
7203f11a-7041-4938-bff6-b417c8f914d9	\N	7b72a59e-442c-4cf8-a6a4-42ec1f45964f	\N	工作台	mobile-workbench	/mobile/workbench	LayoutDashboard	1	active	{"permission": "mobile:home:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
e4503ec7-760a-412c-a10f-674a3f6f4f68	\N	7b72a59e-442c-4cf8-a6a4-42ec1f45964f	\N	移动首页	mobile-home	/mobile/home	Home	0	active	{"permission": "mobile:home:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
8815c511-a7a0-4fdb-a059-756c41a38afd	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	消息通知	mobile-notifications	/mobile/notifications	Bell	8	active	{"permission": "mobile:notification:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
28e1b2fc-85ca-4123-8ad0-d86294cc95a9	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	扫码	mobile-scan	/mobile/scan	Scan	7	active	{"permission": "mobile:scan:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
cd3e4963-5ff7-43aa-ae62-a0eccd059362	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	移动生产	mobile-production	/mobile/production	Factory	6	active	{"permission": "mobile:production:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
99cc7c3b-ce82-4b0e-a94e-e58760a4197b	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	移动质检	mobile-quality	/mobile/quality	ClipboardCheck	5	active	{"permission": "mobile:quality:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
8fc9857e-1b5c-4662-97f4-17813b7ee2a1	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	移动库存	mobile-inventory	/mobile/inventory	Package	4	active	{"permission": "mobile:inventory:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
3ca8fb31-7307-4b11-9f57-2096c3f1d35b	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	移动审批	mobile-approvals	/mobile/approvals	FileCheck	3	active	{"permission": "mobile:approval:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
e48e31f8-dddc-4c11-82af-59399f441817	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	移动任务	mobile-tasks	/mobile/tasks	CheckSquare	2	active	{"permission": "mobile:task:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
3efd759a-5293-4ca2-83d9-c427ffc4854e	\N	9c755ef0-73ff-48f7-85b0-0a747049ce15	\N	移动考勤	mobile-attendance	/mobile/attendance	Clock	1	active	{"permission": "mobile:attendance:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
ab670531-eb55-4d52-9d8a-9a8bf296f8bb	\N	15a872a7-ffa6-4444-8346-849423b31f7f	\N	移动设置	mobile-settings	/mobile/settings	Settings	2	active	{"permission": "mobile:home:admin"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
f5f88138-221f-48d6-a349-8ec9b8d473d6	\N	15a872a7-ffa6-4444-8346-849423b31f7f	\N	个人中心	mobile-profile	/mobile/profile	User	1	active	{"permission": "mobile:home:read"}	2026-11-08 06:05:24.381812+08	2026-11-08 06:05:24.381812+08	\N
761843a7-9543-42bc-8ac2-0d97e227da68	\N	d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	利润表	finance-income-statement-report	/finance/income-statement	TrendingUp	6	active	{"permission": "finance:report:read"}	2026-11-09 18:07:46.287619+08	2026-11-09 18:07:46.287619+08	\N
15500cf2-a569-4058-8f4d-03c058b1eb8a	\N	d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	资产负债表	finance-balance-sheet-report	/finance/balance-sheet	FileSpreadsheet	5	active	{"permission": "finance:report:read"}	2026-11-09 18:07:46.287619+08	2026-11-09 18:07:46.287619+08	\N
d254bb89-d36a-4324-84d1-b9c294c9bc1a	\N	d957dc3c-7163-4fa5-ae3f-5a6a6b7bfed1	\N	科目余额表	finance-account-balance-report	/finance/account-balance	Table	4	active	{"permission": "finance:report:read"}	2026-11-09 18:07:46.287619+08	2026-11-09 18:07:46.287619+08	\N
\.


--
-- Data for Name: core_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_permissions (id, code, name, description, resource, action, created_at, deleted_at, level) FROM stdin;
a8e0c9ce-4e68-4220-8873-07b3e174fc55	finance:read	财务模块访问	\N	finance	read	2026-10-26 14:01:29.435478+08	\N	\N
5fd4c317-345c-4082-acd3-86b2d1a628d0	finance:dashboard:read	财务仪表盘	\N	finance_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
a8b5e958-a6c9-45b4-b1d1-b9bc24436942	finance:voucher:read	凭证读取	\N	finance_voucher	read	2026-10-26 14:01:29.435478+08	\N	\N
bf58df65-0a9f-4350-8ebf-6f935cd76f55	finance:voucher:create	凭证创建	\N	finance_voucher	create	2026-10-26 14:01:29.435478+08	\N	\N
0fde9d79-d70b-4d67-98e5-39013bca2049	finance:voucher:update	凭证更新	\N	finance_voucher	update	2026-10-26 14:01:29.435478+08	\N	\N
c133dc2a-a880-4aac-b3cb-f5eee2d7a956	finance:voucher:delete	凭证删除	\N	finance_voucher	delete	2026-10-26 14:01:29.435478+08	\N	\N
4b3b52c2-6275-4a92-9605-8542cce2c447	finance:ledger:read	总账读取	\N	finance_ledger	read	2026-10-26 14:01:29.435478+08	\N	\N
51c19f90-6687-4771-aedd-a46847a2e3a4	finance:ledger:create	总账创建	\N	finance_ledger	create	2026-10-26 14:01:29.435478+08	\N	\N
546fe75c-e5a5-4504-b119-0c7606b3f601	finance:ledger:update	总账更新	\N	finance_ledger	update	2026-10-26 14:01:29.435478+08	\N	\N
9b7e89f6-e91f-47bb-97b7-97e34155e1fa	finance:ledger:delete	总账删除	\N	finance_ledger	delete	2026-10-26 14:01:29.435478+08	\N	\N
96b56a30-f52b-4ba5-aeee-b887d80dac17	finance:receivable:read	应收应付读取	\N	finance_receivable	read	2026-10-26 14:01:29.435478+08	\N	\N
85ebece3-d64e-4319-8c01-74cac6f0e8f7	finance:receivable:create	应收应付创建	\N	finance_receivable	create	2026-10-26 14:01:29.435478+08	\N	\N
8d0e2a15-51d1-4ee4-8a1f-9b6dacee6d84	finance:receivable:update	应收应付更新	\N	finance_receivable	update	2026-10-26 14:01:29.435478+08	\N	\N
5c1fd4b4-e938-4409-8676-c07461a78592	finance:receivable:delete	应收应付删除	\N	finance_receivable	delete	2026-10-26 14:01:29.435478+08	\N	\N
960bc690-d63e-4487-921e-83fbfc1f92b5	finance:receipt:read	收款读取	\N	finance_receipt	read	2026-10-26 14:01:29.435478+08	\N	\N
646429bc-10c0-48a0-bca7-9d1f3ddd0a09	finance:receipt:create	收款创建	\N	finance_receipt	create	2026-10-26 14:01:29.435478+08	\N	\N
d7e3bbf7-ef49-4a4b-87e7-64abe01d89f1	finance:receipt:update	收款更新	\N	finance_receipt	update	2026-10-26 14:01:29.435478+08	\N	\N
013a8f85-655b-4605-bd89-c5753b208e84	finance:receipt:delete	收款删除	\N	finance_receipt	delete	2026-10-26 14:01:29.435478+08	\N	\N
55db4ace-61f3-4e5e-af33-aef22de617c4	finance:payment:read	付款读取	\N	finance_payment	read	2026-10-26 14:01:29.435478+08	\N	\N
edac3ada-a2b4-4dae-aafc-314c8cbe9b88	finance:payment:create	付款创建	\N	finance_payment	create	2026-10-26 14:01:29.435478+08	\N	\N
5977d93d-c1d1-489d-b82b-0d4bc7d82ea8	finance:payment:update	付款更新	\N	finance_payment	update	2026-10-26 14:01:29.435478+08	\N	\N
e66d1aaa-4a3a-4e49-88a9-c6752fe68b13	finance:payment:delete	付款删除	\N	finance_payment	delete	2026-10-26 14:01:29.435478+08	\N	\N
3804bf4b-84ac-4353-857a-7199a4e17d05	finance:approval_config:read	审批配置读取	\N	finance_approval_config	read	2026-10-26 14:01:29.435478+08	\N	\N
0b3fcb81-17ac-410f-afda-0813de7613fa	finance:approval_config:create	审批配置创建	\N	finance_approval_config	create	2026-10-26 14:01:29.435478+08	\N	\N
eb60c8ca-b38e-47f3-8146-bdf18701e15f	finance:approval_config:update	审批配置更新	\N	finance_approval_config	update	2026-10-26 14:01:29.435478+08	\N	\N
7236630c-200c-4c3b-b5a9-37f917e97520	finance:approval_config:delete	审批配置删除	\N	finance_approval_config	delete	2026-10-26 14:01:29.435478+08	\N	\N
010ae5d8-3f48-49d0-bef3-5e4a8f5d10a5	finance:invoice:read	发票读取	\N	finance_invoice	read	2026-10-26 14:01:29.435478+08	\N	\N
4d384c77-8040-4971-ae47-51b53e37843f	finance:invoice:create	发票创建	\N	finance_invoice	create	2026-10-26 14:01:29.435478+08	\N	\N
dd45992d-1935-4d08-a87d-a92079ae1539	finance:invoice:update	发票更新	\N	finance_invoice	update	2026-10-26 14:01:29.435478+08	\N	\N
001ceb18-bfdf-4c96-9de2-45dfed32d0ac	finance:invoice:delete	发票删除	\N	finance_invoice	delete	2026-10-26 14:01:29.435478+08	\N	\N
936aa7b2-c830-4231-9045-08c0b6a7ccaa	finance:tax:read	税务读取	\N	finance_tax	read	2026-10-26 14:01:29.435478+08	\N	\N
01e15450-5a56-429b-b81c-09bb1427f13d	finance:tax:create	税务创建	\N	finance_tax	create	2026-10-26 14:01:29.435478+08	\N	\N
808a44a1-7906-4bb7-92e7-69cd0c45c9c8	finance:tax:update	税务更新	\N	finance_tax	update	2026-10-26 14:01:29.435478+08	\N	\N
455aae0b-d0c1-48ef-8193-4ed35482702f	finance:tax:delete	税务删除	\N	finance_tax	delete	2026-10-26 14:01:29.435478+08	\N	\N
762d54d2-5f86-4e60-ad17-87a38d8984d7	finance:expense:read	费用读取	\N	finance_expense	read	2026-10-26 14:01:29.435478+08	\N	\N
e736e259-e2c0-49e7-9f72-a8b53000bfd9	finance:expense:create	费用创建	\N	finance_expense	create	2026-10-26 14:01:29.435478+08	\N	\N
4e6e1cf6-3460-4dfb-9132-f68183f530c3	finance:expense:update	费用更新	\N	finance_expense	update	2026-10-26 14:01:29.435478+08	\N	\N
636d4e26-b3e2-4ae7-a032-229a4a8a7841	finance:expense:delete	费用删除	\N	finance_expense	delete	2026-10-26 14:01:29.435478+08	\N	\N
d9f4aab1-3bf8-4fef-bb18-d46f5e0cc5e1	finance:expense_approval:read	费用审批读取	\N	finance_expense_approval	read	2026-10-26 14:01:29.435478+08	\N	\N
01f82c34-63d7-439b-9960-77cf6d630db6	finance:expense_approval:create	费用审批创建	\N	finance_expense_approval	create	2026-10-26 14:01:29.435478+08	\N	\N
9a9b4f53-9d77-4a92-b56c-910cb5f679c1	finance:expense_approval:update	费用审批更新	\N	finance_expense_approval	update	2026-10-26 14:01:29.435478+08	\N	\N
c0e150ca-03d8-41bd-bcdd-ef8ebbdc754d	finance:expense_approval:delete	费用审批删除	\N	finance_expense_approval	delete	2026-10-26 14:01:29.435478+08	\N	\N
2ff29ce8-ef9e-4548-ada3-7d9f4d31f4b2	finance:cost:read	成本读取	\N	finance_cost	read	2026-10-26 14:01:29.435478+08	\N	\N
6710c623-a245-477b-8268-eecc6fcf876b	finance:cost:create	成本创建	\N	finance_cost	create	2026-10-26 14:01:29.435478+08	\N	\N
945f8e67-6a22-4cd4-8392-c78f5e6ef327	finance:cost:update	成本更新	\N	finance_cost	update	2026-10-26 14:01:29.435478+08	\N	\N
f84d58c1-1cc1-4cf9-a03f-cdb54ebd7a09	finance:cost:delete	成本删除	\N	finance_cost	delete	2026-10-26 14:01:29.435478+08	\N	\N
190c81a3-8393-4cb1-9c04-5f2ad649af5d	finance:asset:read	资产读取	\N	finance_asset	read	2026-10-26 14:01:29.435478+08	\N	\N
27412e21-3e81-4d36-9c9e-a99f3d38046f	finance:asset:create	资产创建	\N	finance_asset	create	2026-10-26 14:01:29.435478+08	\N	\N
f0d65596-18de-4dc4-b72b-8a79818a207d	finance:asset:update	资产更新	\N	finance_asset	update	2026-10-26 14:01:29.435478+08	\N	\N
07cd1e24-e4a1-4dbb-b25e-9f6f88b9367d	finance:asset:delete	资产删除	\N	finance_asset	delete	2026-10-26 14:01:29.435478+08	\N	\N
fa723e87-1395-4aca-9237-10ac9a57ee5e	finance:budget:read	预算读取	\N	finance_budget	read	2026-10-26 14:01:29.435478+08	\N	\N
3ce5e888-9e7d-4b00-b7e3-e4339f3424d8	finance:opening_balance:read	期初余额读取	\N	finance_opening_balance	read	2026-10-26 14:01:29.435478+08	\N	\N
cfeab591-d11a-469d-9b99-4ba15bc8f49a	finance:opening_balance:create	期初余额创建	\N	finance_opening_balance	create	2026-10-26 14:01:29.435478+08	\N	\N
c3c6fa15-32f9-4d98-aaa6-49264d1b7313	finance:opening_balance:update	期初余额更新	\N	finance_opening_balance	update	2026-10-26 14:01:29.435478+08	\N	\N
d4906907-0467-4dab-8e20-52e1c8baae9e	finance:opening_balance:delete	期初余额删除	\N	finance_opening_balance	delete	2026-10-26 14:01:29.435478+08	\N	\N
0e2a882b-9d5f-4652-b4cb-3fdbf1ae5316	finance:consolidation:read	合并报表读取	\N	finance_consolidation	read	2026-10-26 14:01:29.435478+08	\N	\N
41b622cf-c723-4c96-a24c-24fc3f08ebe3	finance:report:read	财务报表读取	\N	finance_report	read	2026-10-26 14:01:29.435478+08	\N	\N
10921a0f-4d4c-4a8b-80f7-36dd49329e08	mes:read	生产执行模块访问	\N	mes	read	2026-10-26 14:01:29.435478+08	\N	\N
1c7b23ea-b36e-4ccf-9da0-ea25555afcea	mes:dashboard:read	MES仪表盘	\N	mes_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
6bbab1e7-cd92-41d4-8a6f-f1a8f9a24447	ehs:drill:delete	drill删除	\N	ehs_drill	delete	2026-10-26 14:01:29.435478+08	\N	\N
4fc78ace-01fa-4e7b-8bfd-cda3ed05ac48	mes:production_order:read	生产订单读取	\N	mes_production_order	read	2026-10-26 14:01:29.435478+08	\N	\N
e06dc873-56c7-4336-b870-63a9ead79648	mes:production_order:create	生产订单创建	\N	mes_production_order	create	2026-10-26 14:01:29.435478+08	\N	\N
83120ae4-ec9d-42e5-ba97-4992b821337a	mes:production_order:update	生产订单更新	\N	mes_production_order	update	2026-10-26 14:01:29.435478+08	\N	\N
571c2e47-915a-48b8-8bef-d07e887975f9	mes:production_order:delete	生产订单删除	\N	mes_production_order	delete	2026-10-26 14:01:29.435478+08	\N	\N
a02f8a09-8e60-41d3-ae57-31290ebff1ea	mes:work_order:read	工单读取	\N	mes_work_order	read	2026-10-26 14:01:29.435478+08	\N	\N
d7a1a601-c219-45c9-ac46-9a59c25bd468	mes:work_order:create	工单创建	\N	mes_work_order	create	2026-10-26 14:01:29.435478+08	\N	\N
2c9382d8-5ae1-4624-ac4c-915cf8ee2b8d	mes:work_order:update	工单更新	\N	mes_work_order	update	2026-10-26 14:01:29.435478+08	\N	\N
fe70ea88-828e-4738-9007-3dd1fe53f8ea	mes:work_order:delete	工单删除	\N	mes_work_order	delete	2026-10-26 14:01:29.435478+08	\N	\N
168b2e7d-f672-475e-8b5f-57fe73ccd6de	mes:equipment:read	设备读取	\N	mes_equipment	read	2026-10-26 14:01:29.435478+08	\N	\N
6fb10e1e-f330-48c7-ad0c-feca214c574b	mes:equipment:create	设备创建	\N	mes_equipment	create	2026-10-26 14:01:29.435478+08	\N	\N
10662b93-a8e6-4518-8eb3-f9b256915fcc	mes:equipment:update	设备更新	\N	mes_equipment	update	2026-10-26 14:01:29.435478+08	\N	\N
b5b41188-23f9-4b8c-94b4-5874f9e20bea	mes:equipment:delete	设备删除	\N	mes_equipment	delete	2026-10-26 14:01:29.435478+08	\N	\N
009e9f52-2e61-40b4-932f-0e131dd6f8c1	mes:work_station:read	工位读取	\N	mes_work_station	read	2026-10-26 14:01:29.435478+08	\N	\N
6c32eb6d-4e11-4d46-a975-74bb96409c39	mes:work_station:create	工位创建	\N	mes_work_station	create	2026-10-26 14:01:29.435478+08	\N	\N
6869a699-602f-4d2c-8150-26c975d94562	mes:work_station:update	工位更新	\N	mes_work_station	update	2026-10-26 14:01:29.435478+08	\N	\N
6d6e5327-5026-487e-b845-04d4fcf2923e	mes:work_station:delete	工位删除	\N	mes_work_station	delete	2026-10-26 14:01:29.435478+08	\N	\N
98e3ab60-733c-4d10-a21a-8134c294645b	mes:team:read	班组读取	\N	mes_team	read	2026-10-26 14:01:29.435478+08	\N	\N
1e5ab521-a55b-41d0-8ec9-58406058fa61	mes:team:create	班组创建	\N	mes_team	create	2026-10-26 14:01:29.435478+08	\N	\N
4bd8e98a-d4bd-49eb-84cc-bf5fe790b571	mes:team:update	班组更新	\N	mes_team	update	2026-10-26 14:01:29.435478+08	\N	\N
509148e7-f34e-4e44-b637-0b83085ade65	mes:team:delete	班组删除	\N	mes_team	delete	2026-10-26 14:01:29.435478+08	\N	\N
165d6ddd-16a4-46ed-b0f8-2ca7a777ac7d	mes:material:read	物料读取	\N	mes_material	read	2026-10-26 14:01:29.435478+08	\N	\N
fa720e0d-e494-4d9e-87f6-62a609e9a103	mes:material:create	物料创建	\N	mes_material	create	2026-10-26 14:01:29.435478+08	\N	\N
03c480ab-e62a-45f0-b159-1c0b882934dd	mes:material:update	物料更新	\N	mes_material	update	2026-10-26 14:01:29.435478+08	\N	\N
5c24b0ca-ae87-444e-ae30-de8e099cebed	mes:material:delete	物料删除	\N	mes_material	delete	2026-10-26 14:01:29.435478+08	\N	\N
ed8284f0-b8b8-4ae8-8ca4-ef91de0d0c34	mes:process_route:read	工艺路线读取	\N	mes_process_route	read	2026-10-26 14:01:29.435478+08	\N	\N
ad8bbdd3-1f75-4836-ad56-a27f0a01e292	mes:process_route:create	工艺路线创建	\N	mes_process_route	create	2026-10-26 14:01:29.435478+08	\N	\N
e745cac8-9415-4e23-b3a0-a5993c4f374d	mes:process_route:update	工艺路线更新	\N	mes_process_route	update	2026-10-26 14:01:29.435478+08	\N	\N
1edeb642-b711-4af3-a5ca-d48682dc2442	mes:process_route:delete	工艺路线删除	\N	mes_process_route	delete	2026-10-26 14:01:29.435478+08	\N	\N
3e2033bb-34fb-4693-bb5e-e367af2f626a	mes:process_flow:read	工艺流程读取	\N	mes_process_flow	read	2026-10-26 14:01:29.435478+08	\N	\N
ecbf4abe-bcc8-4e4e-82d3-d807a9cd38db	mes:process_flow:create	工艺流程创建	\N	mes_process_flow	create	2026-10-26 14:01:29.435478+08	\N	\N
3b2e6c70-8248-4075-b0ad-4b9f613dc6e0	mes:process_flow:update	工艺流程更新	\N	mes_process_flow	update	2026-10-26 14:01:29.435478+08	\N	\N
4c2454aa-a2e0-4223-adca-a1669ad62a02	mes:process_flow:delete	工艺流程删除	\N	mes_process_flow	delete	2026-10-26 14:01:29.435478+08	\N	\N
ca69cb47-4c0e-4e29-bcb8-afce2c41fb47	mes:production_process:read	生产过程读取	\N	mes_production_process	read	2026-10-26 14:01:29.435478+08	\N	\N
5ce25f80-91f8-4f98-bc09-28e2d63cc39a	mes:production_process:create	生产过程创建	\N	mes_production_process	create	2026-10-26 14:01:29.435478+08	\N	\N
48ed375b-8c51-40e8-b400-4969107d8add	mes:production_process:update	生产过程更新	\N	mes_production_process	update	2026-10-26 14:01:29.435478+08	\N	\N
655d7299-4fbb-48fd-9a67-b4073fa4dc5f	mes:production_process:delete	生产过程删除	\N	mes_production_process	delete	2026-10-26 14:01:29.435478+08	\N	\N
c8ed86f5-ce14-4069-a332-0bf43a28b9eb	mes:production_schedule:read	生产计划读取	\N	mes_production_schedule	read	2026-10-26 14:01:29.435478+08	\N	\N
19a6d6f4-803d-4e51-9610-d3dde318b566	mes:production_schedule:create	生产计划创建	\N	mes_production_schedule	create	2026-10-26 14:01:29.435478+08	\N	\N
faa09e9f-fc85-4dfc-8ca5-9c4ea1043a11	mes:production_schedule:update	生产计划更新	\N	mes_production_schedule	update	2026-10-26 14:01:29.435478+08	\N	\N
0840d1e7-a0df-49eb-889c-05090219c464	mes:production_schedule:delete	生产计划删除	\N	mes_production_schedule	delete	2026-10-26 14:01:29.435478+08	\N	\N
2c8614cd-e470-4f92-a189-19a06080c19c	mes:wip:read	在制品读取	\N	mes_wip	read	2026-10-26 14:01:29.435478+08	\N	\N
0820e071-6289-4079-bf92-919475011b3d	mes:wip:create	在制品创建	\N	mes_wip	create	2026-10-26 14:01:29.435478+08	\N	\N
9230a691-7d05-41b2-b03c-77c786a32c35	mes:wip:update	在制品更新	\N	mes_wip	update	2026-10-26 14:01:29.435478+08	\N	\N
9e01ba74-2e21-440b-bd7b-bc75ed9e0f4d	mes:wip:delete	在制品删除	\N	mes_wip	delete	2026-10-26 14:01:29.435478+08	\N	\N
a8ba07cd-57ce-4bca-b956-788e42505749	mes:quality:read	质量读取	\N	mes_quality	read	2026-10-26 14:01:29.435478+08	\N	\N
a47e6e07-4923-4574-b03c-51863791b181	mes:quality:create	质量创建	\N	mes_quality	create	2026-10-26 14:01:29.435478+08	\N	\N
f272fde9-ef6b-4fc1-bb26-5498354b82e3	mes:quality:update	质量更新	\N	mes_quality	update	2026-10-26 14:01:29.435478+08	\N	\N
bef7b45a-f638-4097-bfe6-91099e90e3f4	mes:quality:delete	质量删除	\N	mes_quality	delete	2026-10-26 14:01:29.435478+08	\N	\N
850dff23-444d-4cb7-a9a8-e92259725eae	mes:traceability:read	质量追溯读取	\N	mes_traceability	read	2026-10-26 14:01:29.435478+08	\N	\N
473919fc-b929-4a5a-be7e-78da5ed172d8	mes:kanban:read	生产看板读取	\N	mes_kanban	read	2026-10-26 14:01:29.435478+08	\N	\N
dc5e30e2-9930-4122-ab9f-e09eb611c355	mes:production_record:read	生产记录读取	\N	mes_production_record	read	2026-10-26 14:01:29.435478+08	\N	\N
68bcb990-8045-49fc-887e-b05b5eb3e85c	mes:production_record:create	生产记录创建	\N	mes_production_record	create	2026-10-26 14:01:29.435478+08	\N	\N
9634edd3-c3db-44cf-80ab-42e285d61f21	mes:production_record:update	生产记录更新	\N	mes_production_record	update	2026-10-26 14:01:29.435478+08	\N	\N
0b3b1209-4d33-4d56-b806-7492c6bb4707	mes:production_record:delete	生产记录删除	\N	mes_production_record	delete	2026-10-26 14:01:29.435478+08	\N	\N
2c1d27d1-1d54-4489-a780-eb9c56e67c01	mes:work_report:read	工作报告读取	\N	mes_work_report	read	2026-10-26 14:01:29.435478+08	\N	\N
52ae7693-c712-4ce9-95ca-89afbbac2134	mes:work_report:create	工作报告创建	\N	mes_work_report	create	2026-10-26 14:01:29.435478+08	\N	\N
2d8a31a6-9597-4ca5-8b8d-9159f13ecaa4	mes:work_report:update	工作报告更新	\N	mes_work_report	update	2026-10-26 14:01:29.435478+08	\N	\N
d1743946-021d-439a-924a-8574bd4b9988	mes:work_report:delete	工作报告删除	\N	mes_work_report	delete	2026-10-26 14:01:29.435478+08	\N	\N
1f6fc74d-714d-4cbe-85f9-938e660447a6	mes:oee:read	设备OEE读取	\N	mes_oee	read	2026-10-26 14:01:29.435478+08	\N	\N
c30146fa-f946-4f2b-af17-7bc71694e5ea	mes:oee:create	设备OEE创建	\N	mes_oee	create	2026-10-26 14:01:29.435478+08	\N	\N
d23459aa-4792-428c-beb2-16624085980d	mes:oee:update	设备OEE更新	\N	mes_oee	update	2026-10-26 14:01:29.435478+08	\N	\N
432de1f9-6cf4-4de6-9cbc-8abf02ea5cdb	mes:oee:delete	设备OEE删除	\N	mes_oee	delete	2026-10-26 14:01:29.435478+08	\N	\N
60bd83c4-7428-4aab-bb88-fe8c3f2c44c1	mes:energy:read	能耗管理读取	\N	mes_energy	read	2026-10-26 14:01:29.435478+08	\N	\N
4ccdf7e0-ae8a-41ee-a29a-211329cfd778	mes:anomaly:read	异常预警读取	\N	mes_anomaly	read	2026-10-26 14:01:29.435478+08	\N	\N
44f45d52-a3dc-4bd2-8751-896f42240291	hrm:read	人力资源模块访问	\N	hrm	read	2026-10-26 14:01:29.435478+08	\N	\N
eeda10f2-69d8-46b8-b826-d8e0171bde29	hrm:dashboard:read	人力资源仪表盘	\N	hrm_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
d0282329-30ee-4b36-b22e-339f2389511a	hrm:employee:read	employee读取	\N	hrm_employee	read	2026-10-26 14:01:29.435478+08	\N	\N
1c883f18-7d3a-4cd8-916a-0c79c594280e	hrm:employee:create	employee创建	\N	hrm_employee	create	2026-10-26 14:01:29.435478+08	\N	\N
57ff869b-2160-4a3b-a3eb-8e060eb0d324	hrm:employee:update	employee更新	\N	hrm_employee	update	2026-10-26 14:01:29.435478+08	\N	\N
86626cfa-5620-4f52-a530-41efc55ef896	hrm:employee:delete	employee删除	\N	hrm_employee	delete	2026-10-26 14:01:29.435478+08	\N	\N
86234189-20bf-4208-bcab-69fe0e13a155	hrm:department:read	department读取	\N	hrm_department	read	2026-10-26 14:01:29.435478+08	\N	\N
58ed58fc-8ed9-4838-b805-3d444871295f	hrm:department:create	department创建	\N	hrm_department	create	2026-10-26 14:01:29.435478+08	\N	\N
a4136bb7-debb-4a75-9f25-524a3b8a867f	hrm:department:update	department更新	\N	hrm_department	update	2026-10-26 14:01:29.435478+08	\N	\N
8835b668-5fe1-42df-ad09-97a240456194	hrm:department:delete	department删除	\N	hrm_department	delete	2026-10-26 14:01:29.435478+08	\N	\N
bcb676b8-9361-405b-9293-5f63be4e703b	hrm:organization:read	organization读取	\N	hrm_organization	read	2026-10-26 14:01:29.435478+08	\N	\N
16be4633-23e1-4325-9dcb-3e9784302eb2	hrm:organization:create	organization创建	\N	hrm_organization	create	2026-10-26 14:01:29.435478+08	\N	\N
b5226662-612c-4cd0-90a3-09f75dd42754	hrm:organization:update	organization更新	\N	hrm_organization	update	2026-10-26 14:01:29.435478+08	\N	\N
c86e5223-8208-414b-896f-bfb08ff6b6f2	hrm:organization:delete	organization删除	\N	hrm_organization	delete	2026-10-26 14:01:29.435478+08	\N	\N
17b4d5f8-6168-40e9-ae1b-e795f48971ed	hrm:position:read	position读取	\N	hrm_position	read	2026-10-26 14:01:29.435478+08	\N	\N
68d96d30-7275-4f54-917c-3cc0bba0e0b5	hrm:position:create	position创建	\N	hrm_position	create	2026-10-26 14:01:29.435478+08	\N	\N
4e804d73-854f-40d9-97b7-b76d72675a88	hrm:position:update	position更新	\N	hrm_position	update	2026-10-26 14:01:29.435478+08	\N	\N
f528110a-0afb-411e-a327-ba222408c203	hrm:position:delete	position删除	\N	hrm_position	delete	2026-10-26 14:01:29.435478+08	\N	\N
76782c91-0742-42da-9034-59f81deef065	hrm:contract:read	contract读取	\N	hrm_contract	read	2026-10-26 14:01:29.435478+08	\N	\N
0646f558-b946-49db-b885-2e51eeedd825	hrm:contract:create	contract创建	\N	hrm_contract	create	2026-10-26 14:01:29.435478+08	\N	\N
1b9fa8b9-cff4-4077-9bb3-49a355646df6	hrm:contract:update	contract更新	\N	hrm_contract	update	2026-10-26 14:01:29.435478+08	\N	\N
54e1c2f9-cc6f-43b0-96d9-8ca4d41453b6	hrm:contract:delete	contract删除	\N	hrm_contract	delete	2026-10-26 14:01:29.435478+08	\N	\N
b36cab3f-ae9b-441e-8cdf-d6e7b85bec7c	hrm:company:read	company读取	\N	hrm_company	read	2026-10-26 14:01:29.435478+08	\N	\N
80311410-6609-4329-911f-f6e9f0acaf23	hrm:company:create	company创建	\N	hrm_company	create	2026-10-26 14:01:29.435478+08	\N	\N
21c7c4a2-4a09-4c3c-893a-9b1859caf588	hrm:company:update	company更新	\N	hrm_company	update	2026-10-26 14:01:29.435478+08	\N	\N
504736d0-3c4a-42d9-b326-69d5bf2997fc	hrm:company:delete	company删除	\N	hrm_company	delete	2026-10-26 14:01:29.435478+08	\N	\N
c3902070-0a29-429c-a0da-c7289f6aa24e	hrm:attendance:read	attendance读取	\N	hrm_attendance	read	2026-10-26 14:01:29.435478+08	\N	\N
a70adb6b-9b8b-427f-bc0a-298ce53671f2	hrm:leave:read	leave读取	\N	hrm_leave	read	2026-10-26 14:01:29.435478+08	\N	\N
1ebe3270-8fb1-4d44-bfc4-f028c53550e1	hrm:leave:create	leave创建	\N	hrm_leave	create	2026-10-26 14:01:29.435478+08	\N	\N
c60449b5-1573-4724-a73c-9c9dcffe4c79	hrm:leave:update	leave更新	\N	hrm_leave	update	2026-10-26 14:01:29.435478+08	\N	\N
8b2a739f-f9c5-42ae-82a0-7e790f25cc77	hrm:leave:delete	leave删除	\N	hrm_leave	delete	2026-10-26 14:01:29.435478+08	\N	\N
35398804-0d24-4496-9a55-87bea11db0d5	hrm:payroll:read	payroll读取	\N	hrm_payroll	read	2026-10-26 14:01:29.435478+08	\N	\N
076d6603-658f-4e97-9899-adc20cbe704e	hrm:payroll:create	payroll创建	\N	hrm_payroll	create	2026-10-26 14:01:29.435478+08	\N	\N
55da5d18-aa58-4e11-b336-03af4f66e028	hrm:payroll:update	payroll更新	\N	hrm_payroll	update	2026-10-26 14:01:29.435478+08	\N	\N
ece029fe-6262-40ac-80ca-39ce1b745acc	hrm:payroll:delete	payroll删除	\N	hrm_payroll	delete	2026-10-26 14:01:29.435478+08	\N	\N
c04d939d-58f1-49e5-80f0-3221da1db59a	hrm:salary_adjustment:read	salary adjustment读取	\N	hrm_salary_adjustment	read	2026-10-26 14:01:29.435478+08	\N	\N
839da72a-756e-4202-906b-6d1dc4a263fe	hrm:salary_adjustment:create	salary adjustment创建	\N	hrm_salary_adjustment	create	2026-10-26 14:01:29.435478+08	\N	\N
b48b4996-b47f-4b1a-bd5e-a2cc8fab92b0	hrm:salary_adjustment:update	salary adjustment更新	\N	hrm_salary_adjustment	update	2026-10-26 14:01:29.435478+08	\N	\N
7ecb7277-6d10-423c-a286-1e891cd1a2b6	hrm:salary_adjustment:delete	salary adjustment删除	\N	hrm_salary_adjustment	delete	2026-10-26 14:01:29.435478+08	\N	\N
45f06fb5-4437-43b0-b38a-3dc367949390	hrm:recruitment:read	recruitment读取	\N	hrm_recruitment	read	2026-10-26 14:01:29.435478+08	\N	\N
98960006-df7c-4e56-a451-ad51b5af29ae	hrm:recruitment:create	recruitment创建	\N	hrm_recruitment	create	2026-10-26 14:01:29.435478+08	\N	\N
35b8ea5f-f3f3-406d-b97a-af26d7e843bc	hrm:recruitment:update	recruitment更新	\N	hrm_recruitment	update	2026-10-26 14:01:29.435478+08	\N	\N
6eafa6e8-3097-422d-a96e-c6ba2957b3e9	hrm:recruitment:delete	recruitment删除	\N	hrm_recruitment	delete	2026-10-26 14:01:29.435478+08	\N	\N
6cba1cf2-368e-468b-96a9-d53372291683	hrm:training:read	training读取	\N	hrm_training	read	2026-10-26 14:01:29.435478+08	\N	\N
2cdc28f0-a2a3-4003-9c71-3e73b1f595cc	hrm:training:create	training创建	\N	hrm_training	create	2026-10-26 14:01:29.435478+08	\N	\N
889484a7-bcb1-4910-b9cc-28a83433a468	hrm:training:update	training更新	\N	hrm_training	update	2026-10-26 14:01:29.435478+08	\N	\N
e650288e-a22c-4d2e-9f3c-e183beeb6d1a	hrm:training:delete	training删除	\N	hrm_training	delete	2026-10-26 14:01:29.435478+08	\N	\N
630e341e-2360-403a-9acc-062e6929e1aa	hrm:performance:read	performance读取	\N	hrm_performance	read	2026-10-26 14:01:29.435478+08	\N	\N
c3d16092-389d-4893-9c0c-ef642d93b91b	hrm:performance:create	performance创建	\N	hrm_performance	create	2026-10-26 14:01:29.435478+08	\N	\N
b8b5ce2e-2430-426f-8cc2-36e873f66539	hrm:performance:update	performance更新	\N	hrm_performance	update	2026-10-26 14:01:29.435478+08	\N	\N
6fb2e2f6-36a8-4971-a66d-352ffe5b5f22	hrm:performance:delete	performance删除	\N	hrm_performance	delete	2026-10-26 14:01:29.435478+08	\N	\N
da44e650-cf58-432f-bb29-2672f67d7cf9	hrm:report:read	report读取	\N	hrm_report	read	2026-10-26 14:01:29.435478+08	\N	\N
843e31a4-9be0-42ec-a07d-4dacc00400b7	pdm:read	产品数据模块访问	\N	pdm	read	2026-10-26 14:01:29.435478+08	\N	\N
70c2fff2-f8bc-45ff-898b-2e6723f83b20	pdm:dashboard:read	产品数据仪表盘	\N	pdm_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
12379aee-82c9-4147-ace0-6645f3e75cb8	pdm:product:read	product读取	\N	pdm_product	read	2026-10-26 14:01:29.435478+08	\N	\N
b6b500e7-9353-4331-94bc-6eb6db3175ca	pdm:product:create	product创建	\N	pdm_product	create	2026-10-26 14:01:29.435478+08	\N	\N
90a17eb0-6242-46b4-9b55-960791d1d9c9	pdm:product:update	product更新	\N	pdm_product	update	2026-10-26 14:01:29.435478+08	\N	\N
8bc28040-f8c7-4110-a5ae-0fe4d983cef5	pdm:product:delete	product删除	\N	pdm_product	delete	2026-10-26 14:01:29.435478+08	\N	\N
47550e3b-a7ec-4234-8df5-f7faf2ef7bb9	pdm:material:read	material读取	\N	pdm_material	read	2026-10-26 14:01:29.435478+08	\N	\N
4491822c-0dfc-4d8b-9264-155b6b5c4d5e	pdm:material:create	material创建	\N	pdm_material	create	2026-10-26 14:01:29.435478+08	\N	\N
964b7732-3757-4701-be61-f2a8fa64095b	pdm:material:update	material更新	\N	pdm_material	update	2026-10-26 14:01:29.435478+08	\N	\N
3770a867-0f44-4873-a418-62139e5393a9	pdm:material:delete	material删除	\N	pdm_material	delete	2026-10-26 14:01:29.435478+08	\N	\N
817144b2-2c06-4541-917e-954b081ae85a	pdm:bom:read	bom读取	\N	pdm_bom	read	2026-10-26 14:01:29.435478+08	\N	\N
2c0f6c33-00f2-4879-bedd-10f35ee1d71b	pdm:bom:create	bom创建	\N	pdm_bom	create	2026-10-26 14:01:29.435478+08	\N	\N
ec81dca5-052b-4b58-9851-6667a27f3c97	pdm:bom:update	bom更新	\N	pdm_bom	update	2026-10-26 14:01:29.435478+08	\N	\N
67d90528-2e5c-4da9-b89a-cc87400b29a6	pdm:bom:delete	bom删除	\N	pdm_bom	delete	2026-10-26 14:01:29.435478+08	\N	\N
36ce793f-53bb-4756-93e3-b46fd906942d	pdm:document:read	document读取	\N	pdm_document	read	2026-10-26 14:01:29.435478+08	\N	\N
53c99369-cad6-43db-8b02-6f7813dc589d	pdm:document:create	document创建	\N	pdm_document	create	2026-10-26 14:01:29.435478+08	\N	\N
eeec0ea5-873c-4374-a415-3c1d86b58c30	pdm:document:update	document更新	\N	pdm_document	update	2026-10-26 14:01:29.435478+08	\N	\N
294f5260-6c73-4415-9196-d95f005790bb	pdm:document:delete	document删除	\N	pdm_document	delete	2026-10-26 14:01:29.435478+08	\N	\N
2a9040b6-0dba-4c99-9a13-bc959b53cfe5	pdm:version:read	version读取	\N	pdm_version	read	2026-10-26 14:01:29.435478+08	\N	\N
c31ecd18-bfc5-4621-a780-3bf5b288d816	pdm:version:create	version创建	\N	pdm_version	create	2026-10-26 14:01:29.435478+08	\N	\N
68d4d863-607b-45f2-bcc5-aca4e4516dba	pdm:version:update	version更新	\N	pdm_version	update	2026-10-26 14:01:29.435478+08	\N	\N
4acec583-dede-400f-ae67-8f6a99c4135c	pdm:version:delete	version删除	\N	pdm_version	delete	2026-10-26 14:01:29.435478+08	\N	\N
be7d0c87-c89e-41bc-bce3-6a29f8c36749	pdm:change:read	change读取	\N	pdm_change	read	2026-10-26 14:01:29.435478+08	\N	\N
d504c18e-b605-4527-b9ae-08df1d8c998f	pdm:change:create	change创建	\N	pdm_change	create	2026-10-26 14:01:29.435478+08	\N	\N
58d47305-af48-4101-863e-e0c6340e111e	pdm:change:update	change更新	\N	pdm_change	update	2026-10-26 14:01:29.435478+08	\N	\N
47b50520-05db-4c39-8b89-72cad268b55e	pdm:change:delete	change删除	\N	pdm_change	delete	2026-10-26 14:01:29.435478+08	\N	\N
983a05eb-f14c-42ae-a3be-c6d2e34ad1d0	pdm:project:read	project读取	\N	pdm_project	read	2026-10-26 14:01:29.435478+08	\N	\N
f5547113-8057-4ce1-ae98-572d9004b4fb	pdm:project:create	project创建	\N	pdm_project	create	2026-10-26 14:01:29.435478+08	\N	\N
dab34c1c-9858-457c-883e-696dc1d953f9	pdm:project:update	project更新	\N	pdm_project	update	2026-10-26 14:01:29.435478+08	\N	\N
cc174785-b39a-4796-9565-1ce7fe4696b9	pdm:project:delete	project删除	\N	pdm_project	delete	2026-10-26 14:01:29.435478+08	\N	\N
8d6e736f-13de-477d-8d35-6274ae221c2b	pdm:formula:read	formula读取	\N	pdm_formula	read	2026-10-26 14:01:29.435478+08	\N	\N
0bcad886-044b-4a10-9d41-d6b7632d9df1	pdm:formula:create	formula创建	\N	pdm_formula	create	2026-10-26 14:01:29.435478+08	\N	\N
d943d45b-849d-4756-a0f4-e90eddefe514	pdm:formula:update	formula更新	\N	pdm_formula	update	2026-10-26 14:01:29.435478+08	\N	\N
67831c39-8c38-4cd9-adfa-a9cbec794e2c	pdm:formula:delete	formula删除	\N	pdm_formula	delete	2026-10-26 14:01:29.435478+08	\N	\N
4fe66c9e-36e2-49b0-955a-17cf9d138779	pdm:process:read	process读取	\N	pdm_process	read	2026-10-26 14:01:29.435478+08	\N	\N
bc3dfb81-dc42-4112-92f5-cd71e9a05eff	pdm:process:create	process创建	\N	pdm_process	create	2026-10-26 14:01:29.435478+08	\N	\N
aa911249-08c3-4ef5-a375-65018744828a	pdm:process:update	process更新	\N	pdm_process	update	2026-10-26 14:01:29.435478+08	\N	\N
5a67854b-b76d-40da-848d-c609d428dba4	pdm:process:delete	process删除	\N	pdm_process	delete	2026-10-26 14:01:29.435478+08	\N	\N
ca78cc46-4dac-4ea4-866d-5eee21afe13d	pdm:batch:read	batch读取	\N	pdm_batch	read	2026-10-26 14:01:29.435478+08	\N	\N
475ea8a1-15a2-4119-876b-662cef417d80	pdm:batch:create	batch创建	\N	pdm_batch	create	2026-10-26 14:01:29.435478+08	\N	\N
58e208a0-d672-4c93-805f-d2ca15802e03	pdm:batch:update	batch更新	\N	pdm_batch	update	2026-10-26 14:01:29.435478+08	\N	\N
df3da25a-405d-4a20-bf27-ffcb5c6c7775	pdm:batch:delete	batch删除	\N	pdm_batch	delete	2026-10-26 14:01:29.435478+08	\N	\N
bfe35292-20ff-427a-a6c8-c9fe91fb85b3	pdm:step:read	step读取	\N	pdm_step	read	2026-10-26 14:01:29.435478+08	\N	\N
ff36ec23-af8d-45b4-9a37-efcd0dd4b923	pdm:step:create	step创建	\N	pdm_step	create	2026-10-26 14:01:29.435478+08	\N	\N
c49d284d-a327-4c73-854b-3a74d181105a	pdm:step:update	step更新	\N	pdm_step	update	2026-10-26 14:01:29.435478+08	\N	\N
c502d8d1-2565-4ceb-81e4-3fcfe8df0e49	pdm:step:delete	step删除	\N	pdm_step	delete	2026-10-26 14:01:29.435478+08	\N	\N
4a3900d4-0018-4fa5-aa07-14664fc15457	pdm:stats:read	stats读取	\N	pdm_stats	read	2026-10-26 14:01:29.435478+08	\N	\N
d5fbb4e3-26e0-49c4-b428-bb44eeeb41a2	pdm:product_category:read	product category读取	\N	pdm_product_category	read	2026-10-26 14:01:29.435478+08	\N	\N
580b1527-90fa-48a7-98d2-f60a2aec37da	pdm:product_category:create	product category创建	\N	pdm_product_category	create	2026-10-26 14:01:29.435478+08	\N	\N
b047800d-1cf7-4c3c-9942-0a1842b3dd08	pdm:product_category:update	product category更新	\N	pdm_product_category	update	2026-10-26 14:01:29.435478+08	\N	\N
953f9441-6c50-459a-ad7a-80ca20fc0e8e	pdm:product_category:delete	product category删除	\N	pdm_product_category	delete	2026-10-26 14:01:29.435478+08	\N	\N
d522e713-a169-4b07-953a-15fac87a516a	wms:read	仓储管理模块访问	\N	wms	read	2026-10-26 14:01:29.435478+08	\N	\N
e4865f32-f0c6-45db-9cc0-a69ad8c23900	wms:dashboard:read	仓储管理仪表盘	\N	wms_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
68b9eb3a-80c1-48e8-9933-7252c8985688	wms:warehouse:read	warehouse读取	\N	wms_warehouse	read	2026-10-26 14:01:29.435478+08	\N	\N
6ec53f4b-8f6f-43dc-ac4c-094353ca2e91	wms:warehouse:create	warehouse创建	\N	wms_warehouse	create	2026-10-26 14:01:29.435478+08	\N	\N
c84ff030-06b6-40bf-868b-83d05eedca2e	wms:warehouse:update	warehouse更新	\N	wms_warehouse	update	2026-10-26 14:01:29.435478+08	\N	\N
71674950-7ef1-4281-8976-529892e61f26	wms:warehouse:delete	warehouse删除	\N	wms_warehouse	delete	2026-10-26 14:01:29.435478+08	\N	\N
309dcb60-cde5-4d03-84cc-6f6c11b8d836	wms:location:read	location读取	\N	wms_location	read	2026-10-26 14:01:29.435478+08	\N	\N
3eeda450-f14e-460b-aa1e-7e880db3b9a1	wms:location:create	location创建	\N	wms_location	create	2026-10-26 14:01:29.435478+08	\N	\N
5653bd54-d986-484f-aacd-6b00baebfdcc	wms:location:update	location更新	\N	wms_location	update	2026-10-26 14:01:29.435478+08	\N	\N
e70982f0-0001-4900-8bd8-0bd41abc85c5	wms:location:delete	location删除	\N	wms_location	delete	2026-10-26 14:01:29.435478+08	\N	\N
65e18ea1-190d-4f51-a8a5-6aeaf5e74b27	wms:batch:read	batch读取	\N	wms_batch	read	2026-10-26 14:01:29.435478+08	\N	\N
78fbc412-c95e-4e42-a17a-5773d73774e1	wms:batch:create	batch创建	\N	wms_batch	create	2026-10-26 14:01:29.435478+08	\N	\N
172e7fd2-273d-4a38-8edc-1bb039c7c03e	wms:batch:update	batch更新	\N	wms_batch	update	2026-10-26 14:01:29.435478+08	\N	\N
5376af21-342a-4e75-a591-1776a8b1c706	wms:batch:delete	batch删除	\N	wms_batch	delete	2026-10-26 14:01:29.435478+08	\N	\N
016d98a5-b27f-4ac8-828b-26343572d93d	wms:serial_number:read	serial number读取	\N	wms_serial_number	read	2026-10-26 14:01:29.435478+08	\N	\N
67d632dc-d8d0-406b-beef-472d3f9164cd	wms:serial_number:create	serial number创建	\N	wms_serial_number	create	2026-10-26 14:01:29.435478+08	\N	\N
9e236ffe-149b-4f50-9a87-4e9814244bbe	wms:serial_number:update	serial number更新	\N	wms_serial_number	update	2026-10-26 14:01:29.435478+08	\N	\N
cd047b78-93b8-477a-8027-eae22e0f49f3	wms:serial_number:delete	serial number删除	\N	wms_serial_number	delete	2026-10-26 14:01:29.435478+08	\N	\N
35119d75-1d39-474e-99bd-35e2ba2f8aa9	wms:inbound:read	inbound读取	\N	wms_inbound	read	2026-10-26 14:01:29.435478+08	\N	\N
2575ddde-6b55-474d-a5a4-9c4e4047511f	wms:inbound:create	inbound创建	\N	wms_inbound	create	2026-10-26 14:01:29.435478+08	\N	\N
51022719-092c-4fac-b670-49ac8ab83a77	wms:inbound:update	inbound更新	\N	wms_inbound	update	2026-10-26 14:01:29.435478+08	\N	\N
f834bc54-300b-4d0b-8302-8a1f6d2688fd	wms:inbound:delete	inbound删除	\N	wms_inbound	delete	2026-10-26 14:01:29.435478+08	\N	\N
983eced3-366c-4b7f-a2ba-bf7b8de9e9f3	wms:outbound:read	outbound读取	\N	wms_outbound	read	2026-10-26 14:01:29.435478+08	\N	\N
f6ff0668-762f-41f7-bd37-fff13fc51d80	wms:outbound:create	outbound创建	\N	wms_outbound	create	2026-10-26 14:01:29.435478+08	\N	\N
bc86cc45-56c8-4915-bc36-110f30eab9aa	wms:outbound:update	outbound更新	\N	wms_outbound	update	2026-10-26 14:01:29.435478+08	\N	\N
b9651b0b-b17c-4d29-87b5-028e4359567f	wms:outbound:delete	outbound删除	\N	wms_outbound	delete	2026-10-26 14:01:29.435478+08	\N	\N
a26c861d-0483-4a81-bbee-0f51554a92b9	wms:transfer:read	transfer读取	\N	wms_transfer	read	2026-10-26 14:01:29.435478+08	\N	\N
503680ee-aa27-4c8f-930c-0b179163309f	wms:transfer:create	transfer创建	\N	wms_transfer	create	2026-10-26 14:01:29.435478+08	\N	\N
ce3b5fb1-1ef9-4859-b805-9196c1df7fc0	wms:transfer:update	transfer更新	\N	wms_transfer	update	2026-10-26 14:01:29.435478+08	\N	\N
5da3928a-ed7f-4365-a8a8-3fd384658a70	wms:transfer:delete	transfer删除	\N	wms_transfer	delete	2026-10-26 14:01:29.435478+08	\N	\N
8380fdb9-60cf-4b26-8698-e2e41787d085	wms:inventory_check:read	inventory check读取	\N	wms_inventory_check	read	2026-10-26 14:01:29.435478+08	\N	\N
a872b924-9ec3-483b-b750-2db2e38153b1	wms:replenishment:read	replenishment读取	\N	wms_replenishment	read	2026-10-26 14:01:29.435478+08	\N	\N
25521bcd-f491-4996-bf43-70c39f3d3d57	wms:replenishment:create	replenishment创建	\N	wms_replenishment	create	2026-10-26 14:01:29.435478+08	\N	\N
5bff4f92-a826-4d08-afe4-75fdb9614647	wms:replenishment:update	replenishment更新	\N	wms_replenishment	update	2026-10-26 14:01:29.435478+08	\N	\N
2b68bb17-df65-4725-a160-5a44119ec492	wms:replenishment:delete	replenishment删除	\N	wms_replenishment	delete	2026-10-26 14:01:29.435478+08	\N	\N
a9938736-93a7-49bf-942b-e180fce93253	wms:inventory:read	inventory读取	\N	wms_inventory	read	2026-10-26 14:01:29.435478+08	\N	\N
c79c205a-84c1-4296-b8dc-f722ac6e4be7	wms:inventory:create	inventory创建	\N	wms_inventory	create	2026-10-26 14:01:29.435478+08	\N	\N
e4940665-621a-4cae-bcfc-6eeb6e0cfc6c	wms:inventory:update	inventory更新	\N	wms_inventory	update	2026-10-26 14:01:29.435478+08	\N	\N
42fe0562-b0b1-452d-b948-536ed2d536dd	wms:inventory:delete	inventory删除	\N	wms_inventory	delete	2026-10-26 14:01:29.435478+08	\N	\N
14486b97-172b-4b6d-aaf9-2c955e51da16	wms:report:read	report读取	\N	wms_report	read	2026-10-26 14:01:29.435478+08	\N	\N
7ae9f8cd-c5ca-401f-9bb7-ddc53b96dcc4	wms:supplier:read	supplier读取	\N	wms_supplier	read	2026-10-26 14:01:29.435478+08	\N	\N
39c0774c-1855-45b9-87a8-69ffb3701392	wms:area:read	area读取	\N	wms_area	read	2026-10-26 14:01:29.435478+08	\N	\N
e265ffa2-8278-4d17-a1d2-ece5c4e63f9d	wms:area:create	area创建	\N	wms_area	create	2026-10-26 14:01:29.435478+08	\N	\N
3e61f288-9acc-48b3-b186-ac7185bfe31d	wms:area:update	area更新	\N	wms_area	update	2026-10-26 14:01:29.435478+08	\N	\N
1733fdc3-eb98-49a0-b0b5-c2bbc2ab3772	wms:area:delete	area删除	\N	wms_area	delete	2026-10-26 14:01:29.435478+08	\N	\N
97fd42c9-f9e8-4f55-b7de-c53a1e197e5c	ehs:read	安全环保模块访问	\N	ehs	read	2026-10-26 14:01:29.435478+08	\N	\N
8581a771-d999-4f96-a29b-c9ce95fbafbb	ehs:dashboard:read	安全环保仪表盘	\N	ehs_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
3e340190-e9eb-41a0-9151-a90a9a174a15	ehs:check:read	check读取	\N	ehs_check	read	2026-10-26 14:01:29.435478+08	\N	\N
32df47d7-4bdf-4cb2-acb4-78ff37802e28	ehs:check:create	check创建	\N	ehs_check	create	2026-10-26 14:01:29.435478+08	\N	\N
5380f69b-72ce-418f-ab76-d4c6252a92b0	ehs:check:update	check更新	\N	ehs_check	update	2026-10-26 14:01:29.435478+08	\N	\N
da10422e-6327-48c4-995b-e6106a1ad030	ehs:check:delete	check删除	\N	ehs_check	delete	2026-10-26 14:01:29.435478+08	\N	\N
dfd84fe3-f42d-4af6-b45d-8d6f24fc6691	ehs:hazard:read	hazard读取	\N	ehs_hazard	read	2026-10-26 14:01:29.435478+08	\N	\N
7c7c913d-2347-46e0-9129-5c8c7963fe47	ehs:hazard:create	hazard创建	\N	ehs_hazard	create	2026-10-26 14:01:29.435478+08	\N	\N
58c402e8-0edc-440f-b449-72f554a4f09d	ehs:hazard:update	hazard更新	\N	ehs_hazard	update	2026-10-26 14:01:29.435478+08	\N	\N
8e2f0cd6-e10f-44a1-ac66-c2372ff9aba7	ehs:hazard:delete	hazard删除	\N	ehs_hazard	delete	2026-10-26 14:01:29.435478+08	\N	\N
15ef228a-4ce4-4914-86d4-8743320f3c45	ehs:accident:read	accident读取	\N	ehs_accident	read	2026-10-26 14:01:29.435478+08	\N	\N
17764847-06a3-481b-b84c-fc64ce0ef960	ehs:accident:create	accident创建	\N	ehs_accident	create	2026-10-26 14:01:29.435478+08	\N	\N
d21829fb-a0fc-4cfe-8850-8b329dd00409	ehs:accident:update	accident更新	\N	ehs_accident	update	2026-10-26 14:01:29.435478+08	\N	\N
15fc7f5e-8b0d-4e4b-805e-fc08787fb446	ehs:accident:delete	accident删除	\N	ehs_accident	delete	2026-10-26 14:01:29.435478+08	\N	\N
fac82fcf-b132-4678-9882-5fe21ee0a9b5	ehs:plan:read	plan读取	\N	ehs_plan	read	2026-10-26 14:01:29.435478+08	\N	\N
3f1e4adb-0095-49f3-a87a-b917419410d7	ehs:plan:create	plan创建	\N	ehs_plan	create	2026-10-26 14:01:29.435478+08	\N	\N
3435f0a9-c63f-47fd-914a-0157b0af83be	ehs:plan:update	plan更新	\N	ehs_plan	update	2026-10-26 14:01:29.435478+08	\N	\N
318bc331-919b-460c-a42a-9294b5147872	ehs:plan:delete	plan删除	\N	ehs_plan	delete	2026-10-26 14:01:29.435478+08	\N	\N
aa3a5070-12ae-4a0f-9d18-f57aad030a37	ehs:compliance:read	compliance读取	\N	ehs_compliance	read	2026-10-26 14:01:29.435478+08	\N	\N
a50acd9f-fb68-4812-9136-fa6bd5afee86	ehs:compliance:create	compliance创建	\N	ehs_compliance	create	2026-10-26 14:01:29.435478+08	\N	\N
ec2d7f67-c805-4be2-81d4-108cdf7c9310	ehs:compliance:update	compliance更新	\N	ehs_compliance	update	2026-10-26 14:01:29.435478+08	\N	\N
a5a62714-4c98-4dd2-b023-7d50bd156166	ehs:compliance:delete	compliance删除	\N	ehs_compliance	delete	2026-10-26 14:01:29.435478+08	\N	\N
6040a799-1c4f-4ec1-8953-645540980bc1	ehs:environment:read	environment读取	\N	ehs_environment	read	2026-10-26 14:01:29.435478+08	\N	\N
ce88b7df-8249-47be-83ac-cac286a47624	ehs:environment:create	environment创建	\N	ehs_environment	create	2026-10-26 14:01:29.435478+08	\N	\N
367957e3-36e5-42a1-8830-ff1068bcd649	ehs:environment:update	environment更新	\N	ehs_environment	update	2026-10-26 14:01:29.435478+08	\N	\N
aeb94a79-3c08-4948-87e9-a404056ec540	ehs:environment:delete	environment删除	\N	ehs_environment	delete	2026-10-26 14:01:29.435478+08	\N	\N
cc1b9db7-b1bb-4294-baf8-72de4c2b4ea0	ehs:training:read	training读取	\N	ehs_training	read	2026-10-26 14:01:29.435478+08	\N	\N
0ad56aa2-270a-447a-bb55-5c3e5b740862	ehs:training:create	training创建	\N	ehs_training	create	2026-10-26 14:01:29.435478+08	\N	\N
363100c6-ff27-45cf-83c0-05109bd668cf	ehs:training:update	training更新	\N	ehs_training	update	2026-10-26 14:01:29.435478+08	\N	\N
457373e7-b6f6-40da-aa8e-520c0018a26d	ehs:training:delete	training删除	\N	ehs_training	delete	2026-10-26 14:01:29.435478+08	\N	\N
ff80ed49-ddfa-4b93-8acc-34a9bf186da2	ehs:occupational_disease:read	occupational disease读取	\N	ehs_occupational_disease	read	2026-10-26 14:01:29.435478+08	\N	\N
d014f331-6483-4671-bc41-6236b06ba37b	ehs:occupational_disease:create	occupational disease创建	\N	ehs_occupational_disease	create	2026-10-26 14:01:29.435478+08	\N	\N
5fad1a87-658c-4894-9772-72a1b0731d45	ehs:occupational_disease:update	occupational disease更新	\N	ehs_occupational_disease	update	2026-10-26 14:01:29.435478+08	\N	\N
0eb279fa-b6c6-4e2d-b050-82ea0631c1d9	ehs:occupational_disease:delete	occupational disease删除	\N	ehs_occupational_disease	delete	2026-10-26 14:01:29.435478+08	\N	\N
4798d33d-62c5-4150-8235-63bc6389f7c8	ehs:health:read	health读取	\N	ehs_health	read	2026-10-26 14:01:29.435478+08	\N	\N
6ac3d874-41b9-469d-a60a-b4bf8512a7df	ehs:health:create	health创建	\N	ehs_health	create	2026-10-26 14:01:29.435478+08	\N	\N
fff2deec-1d88-4469-a790-ece3eb6a29a8	ehs:health:update	health更新	\N	ehs_health	update	2026-10-26 14:01:29.435478+08	\N	\N
9d3d0448-8f66-4dc7-b0ce-6adf9c45bf45	ehs:health:delete	health删除	\N	ehs_health	delete	2026-10-26 14:01:29.435478+08	\N	\N
c3ab3508-f352-4528-b837-d5bbf978d697	ehs:hazardous_material:read	hazardous material读取	\N	ehs_hazardous_material	read	2026-10-26 14:01:29.435478+08	\N	\N
1e38a460-8504-4fe6-b19f-ac4155bb42bd	ehs:hazardous_material:create	hazardous material创建	\N	ehs_hazardous_material	create	2026-10-26 14:01:29.435478+08	\N	\N
aafd9e68-1a98-4a6e-8174-652e4f296ace	ehs:hazardous_material:update	hazardous material更新	\N	ehs_hazardous_material	update	2026-10-26 14:01:29.435478+08	\N	\N
d2bc12c6-ad64-4a54-b9e0-f7aa59ecf58d	ehs:hazardous_material:delete	hazardous material删除	\N	ehs_hazardous_material	delete	2026-10-26 14:01:29.435478+08	\N	\N
5dd50086-a083-44e9-a7ac-78e011241957	ehs:emergency:read	emergency读取	\N	ehs_emergency	read	2026-10-26 14:01:29.435478+08	\N	\N
19dd599d-6e4f-47ce-a045-d6df8b2a663e	ehs:drill:read	drill读取	\N	ehs_drill	read	2026-10-26 14:01:29.435478+08	\N	\N
a9b0dae7-d770-4ed2-bd96-52b643051248	ehs:drill:create	drill创建	\N	ehs_drill	create	2026-10-26 14:01:29.435478+08	\N	\N
b7dd8d6c-518c-41df-9dd5-4a36fe4bc217	ehs:drill:update	drill更新	\N	ehs_drill	update	2026-10-26 14:01:29.435478+08	\N	\N
43233d63-bf7b-4920-9c63-d3dca088742b	ehs:incident:read	incident读取	\N	ehs_incident	read	2026-10-26 14:01:29.435478+08	\N	\N
32f4462f-b2e2-4436-880a-b5aeebe6dbcb	ehs:incident:create	incident创建	\N	ehs_incident	create	2026-10-26 14:01:29.435478+08	\N	\N
c9bff55f-fad7-4e8d-8141-7761f0291798	ehs:incident:update	incident更新	\N	ehs_incident	update	2026-10-26 14:01:29.435478+08	\N	\N
a7a34dc8-f4d8-4329-83ef-fb0382eb7950	ehs:incident:delete	incident删除	\N	ehs_incident	delete	2026-10-26 14:01:29.435478+08	\N	\N
2e2c8722-c8fe-49c8-8959-4df4239c9044	lims:read	实验室管理模块访问	\N	lims	read	2026-10-26 14:01:29.435478+08	\N	\N
2bc8a1f7-ccf4-4937-bb7f-6200e07cb8f3	lims:dashboard:read	实验室管理仪表盘	\N	lims_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
98339e25-73b0-4143-bd7d-be833f6011e0	lims:sample:read	sample读取	\N	lims_sample	read	2026-10-26 14:01:29.435478+08	\N	\N
a91e3a12-46a8-4119-ab8a-63a67b5f7d23	lims:sample:create	sample创建	\N	lims_sample	create	2026-10-26 14:01:29.435478+08	\N	\N
2cfba3c9-692a-4b93-8aef-fef6c03c333a	lims:sample:update	sample更新	\N	lims_sample	update	2026-10-26 14:01:29.435478+08	\N	\N
e38e4a7b-a918-48d2-af8c-4b12851b65cb	lims:sample:delete	sample删除	\N	lims_sample	delete	2026-10-26 14:01:29.435478+08	\N	\N
fbb8a65a-83ec-4eb8-a937-378ec1139263	lims:task:read	task读取	\N	lims_task	read	2026-10-26 14:01:29.435478+08	\N	\N
c9f30bdc-2c5b-4713-b2df-5a889d5a5380	lims:task:create	task创建	\N	lims_task	create	2026-10-26 14:01:29.435478+08	\N	\N
2edd77a5-3126-43b1-ad18-64ac1bb8ee70	lims:task:update	task更新	\N	lims_task	update	2026-10-26 14:01:29.435478+08	\N	\N
5c00d601-fd62-409f-882c-8ffa89aafc4f	lims:task:delete	task删除	\N	lims_task	delete	2026-10-26 14:01:29.435478+08	\N	\N
3da0b417-e73d-48c0-bf5a-4d3dcae4bebd	lims:process:read	process读取	\N	lims_process	read	2026-10-26 14:01:29.435478+08	\N	\N
1a27be22-9a1f-4054-ab65-7779d57381f3	lims:process:create	process创建	\N	lims_process	create	2026-10-26 14:01:29.435478+08	\N	\N
9e9a26e7-d2b1-4fd0-bdd6-9361ffaf8ef0	lims:process:update	process更新	\N	lims_process	update	2026-10-26 14:01:29.435478+08	\N	\N
6adcaa08-fe6a-4b5a-8c7b-d44c94557fd0	lims:process:delete	process删除	\N	lims_process	delete	2026-10-26 14:01:29.435478+08	\N	\N
55ceca93-d6a6-4f84-8786-953df31dc4a6	lims:instrument:read	instrument读取	\N	lims_instrument	read	2026-10-26 14:01:29.435478+08	\N	\N
5c69b68a-0953-4860-842c-88164ea83776	lims:instrument:create	instrument创建	\N	lims_instrument	create	2026-10-26 14:01:29.435478+08	\N	\N
b5957552-9b9a-4682-8e7c-08dc078cb3cc	lims:instrument:update	instrument更新	\N	lims_instrument	update	2026-10-26 14:01:29.435478+08	\N	\N
8bc2a8d0-28e5-4e0e-b893-865456e159f9	lims:instrument:delete	instrument删除	\N	lims_instrument	delete	2026-10-26 14:01:29.435478+08	\N	\N
17b9e9d6-8ea2-45b3-bcef-c5b9ebe9a6c0	lims:reagent:read	reagent读取	\N	lims_reagent	read	2026-10-26 14:01:29.435478+08	\N	\N
3c8ae7d8-f5d7-4dbd-bbcb-e9399400e62b	lims:reagent:create	reagent创建	\N	lims_reagent	create	2026-10-26 14:01:29.435478+08	\N	\N
a141f05f-088a-458c-90dc-7cf15f4b9feb	lims:reagent:update	reagent更新	\N	lims_reagent	update	2026-10-26 14:01:29.435478+08	\N	\N
f939c582-9bb4-4641-bf88-72a01411c863	lims:reagent:delete	reagent删除	\N	lims_reagent	delete	2026-10-26 14:01:29.435478+08	\N	\N
659ee807-6bb1-40f7-a957-8ab515a48f94	lims:test_method:read	test method读取	\N	lims_test_method	read	2026-10-26 14:01:29.435478+08	\N	\N
25709809-5abb-4ac8-9d35-c60a26c4be23	lims:test_method:create	test method创建	\N	lims_test_method	create	2026-10-26 14:01:29.435478+08	\N	\N
eb46ecc2-c83a-4dc3-a2c5-28dc68132cc3	lims:test_method:update	test method更新	\N	lims_test_method	update	2026-10-26 14:01:29.435478+08	\N	\N
958a344b-8b88-425d-b5cd-f73810680d6d	lims:test_method:delete	test method删除	\N	lims_test_method	delete	2026-10-26 14:01:29.435478+08	\N	\N
461ffd40-0094-4112-bd63-c6dca34085d3	lims:barcode:read	barcode读取	\N	lims_barcode	read	2026-10-26 14:01:29.435478+08	\N	\N
c4a88d7e-87df-4141-8f25-d74773a2ddd2	lims:barcode:create	barcode创建	\N	lims_barcode	create	2026-10-26 14:01:29.435478+08	\N	\N
14942e67-ae28-4bf2-a9fa-f67cd8f4767b	lims:barcode:update	barcode更新	\N	lims_barcode	update	2026-10-26 14:01:29.435478+08	\N	\N
94690540-217c-4346-bcc2-c1f6c694662e	lims:barcode:delete	barcode删除	\N	lims_barcode	delete	2026-10-26 14:01:29.435478+08	\N	\N
6844c638-1130-4954-b776-32a5ed83bb23	lims:uncertainty:read	uncertainty读取	\N	lims_uncertainty	read	2026-10-26 14:01:29.435478+08	\N	\N
350c7790-b0fd-412a-86ee-e2defd30bcd7	lims:uncertainty:create	uncertainty创建	\N	lims_uncertainty	create	2026-10-26 14:01:29.435478+08	\N	\N
569b856c-d12c-4b6e-aa8b-651f569de24f	lims:uncertainty:update	uncertainty更新	\N	lims_uncertainty	update	2026-10-26 14:01:29.435478+08	\N	\N
16b0291b-1539-4f24-ae8a-c45414c36510	lims:uncertainty:delete	uncertainty删除	\N	lims_uncertainty	delete	2026-10-26 14:01:29.435478+08	\N	\N
01de6495-85a2-4eec-be1a-a69efcdf99ea	lims:result:read	result读取	\N	lims_result	read	2026-10-26 14:01:29.435478+08	\N	\N
469185a8-8a14-4cd2-ba82-d1ab5241bd57	lims:proficiency:read	proficiency读取	\N	lims_proficiency	read	2026-10-26 14:01:29.435478+08	\N	\N
013eb45f-c4b5-4aca-b0ff-e5914bf89ee9	lims:proficiency:create	proficiency创建	\N	lims_proficiency	create	2026-10-26 14:01:29.435478+08	\N	\N
a40e54ed-3d99-4dbf-a2e7-12ca5b9fec7b	lims:proficiency:update	proficiency更新	\N	lims_proficiency	update	2026-10-26 14:01:29.435478+08	\N	\N
11083df3-e024-49c2-a9b7-812aef55a882	lims:proficiency:delete	proficiency删除	\N	lims_proficiency	delete	2026-10-26 14:01:29.435478+08	\N	\N
5eca91e0-af50-4999-9a05-2fd8d696300e	crm:read	客户关系模块访问	\N	crm	read	2026-10-26 14:01:29.435478+08	\N	\N
9924038f-fa8e-4be5-bff6-9073368a5471	crm:dashboard:read	客户关系仪表盘	\N	crm_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
3fbf4e67-5d50-41d9-bb14-61ab66b74fd1	crm:customer:read	customer读取	\N	crm_customer	read	2026-10-26 14:01:29.435478+08	\N	\N
e388daca-c0e3-4396-b400-5e06cfa67472	crm:customer:create	customer创建	\N	crm_customer	create	2026-10-26 14:01:29.435478+08	\N	\N
c633a0b8-53af-4170-b568-a8657b2a5c04	crm:customer:update	customer更新	\N	crm_customer	update	2026-10-26 14:01:29.435478+08	\N	\N
9a8df57b-ae58-4af7-a554-747b426f071f	crm:customer:delete	customer删除	\N	crm_customer	delete	2026-10-26 14:01:29.435478+08	\N	\N
1fc6e8a0-b3bf-447d-869f-e61400ca395f	crm:contact:read	contact读取	\N	crm_contact	read	2026-10-26 14:01:29.435478+08	\N	\N
c8f7528a-b746-468d-998a-69d9fb77f8eb	crm:contact:create	contact创建	\N	crm_contact	create	2026-10-26 14:01:29.435478+08	\N	\N
11f35f26-18f0-4a87-ad53-a19e182f301f	crm:contact:update	contact更新	\N	crm_contact	update	2026-10-26 14:01:29.435478+08	\N	\N
d4b29c75-7642-4342-8e5b-6b7e0c50ef3c	crm:contact:delete	contact删除	\N	crm_contact	delete	2026-10-26 14:01:29.435478+08	\N	\N
7d2623e2-e4e7-439e-bdfc-6440b5bb9c56	crm:opportunity:read	opportunity读取	\N	crm_opportunity	read	2026-10-26 14:01:29.435478+08	\N	\N
de3e8777-42ac-44c8-9a56-68f8e6b22f76	crm:interaction:read	interaction读取	\N	crm_interaction	read	2026-10-26 14:01:29.435478+08	\N	\N
ae8b9bbc-9874-4909-a16c-0aa51675766d	crm:interaction:create	interaction创建	\N	crm_interaction	create	2026-10-26 14:01:29.435478+08	\N	\N
09275bd7-6be8-4953-8df1-9b3ed697a4de	crm:interaction:update	interaction更新	\N	crm_interaction	update	2026-10-26 14:01:29.435478+08	\N	\N
392073c6-cc2d-45c7-8020-881460c0d9df	crm:interaction:delete	interaction删除	\N	crm_interaction	delete	2026-10-26 14:01:29.435478+08	\N	\N
2fe35431-9313-4008-89a1-14c2dca09f89	crm:billing:read	billing读取	\N	crm_billing	read	2026-10-26 14:01:29.435478+08	\N	\N
ab9624e5-b9f6-45b8-af1b-009ede398d86	crm:billing:create	billing创建	\N	crm_billing	create	2026-10-26 14:01:29.435478+08	\N	\N
5a4e7fc0-6fab-499c-9a08-e852a78de7c9	crm:billing:update	billing更新	\N	crm_billing	update	2026-10-26 14:01:29.435478+08	\N	\N
78de2802-d14c-438c-a5c9-f39a20ed8bc8	crm:billing:delete	billing删除	\N	crm_billing	delete	2026-10-26 14:01:29.435478+08	\N	\N
f7110152-0258-4661-9227-70eab5916f73	crm:sales_funnel:read	sales funnel读取	\N	crm_sales_funnel	read	2026-10-26 14:01:29.435478+08	\N	\N
8894b09f-abe4-4418-8a75-567c2d127099	crm:customer_scoring:read	customer scoring读取	\N	crm_customer_scoring	read	2026-10-26 14:01:29.435478+08	\N	\N
8d62857b-9efd-4d30-ba34-02e17f821fa5	crm:customer_scoring:create	customer scoring创建	\N	crm_customer_scoring	create	2026-10-26 14:01:29.435478+08	\N	\N
2ca05c4a-9100-4313-a735-d4f3c5e75924	crm:customer_scoring:update	customer scoring更新	\N	crm_customer_scoring	update	2026-10-26 14:01:29.435478+08	\N	\N
19b54313-877c-4b9f-ad0b-5343a9966292	crm:customer_scoring:delete	customer scoring删除	\N	crm_customer_scoring	delete	2026-10-26 14:01:29.435478+08	\N	\N
3ae80f7a-9350-44c3-bcfc-164be9cbadbd	crm:sales_forecast:read	sales forecast读取	\N	crm_sales_forecast	read	2026-10-26 14:01:29.435478+08	\N	\N
2907d0c5-27f4-4ce4-b6fe-334626688c45	crm:customer_segmentation:read	customer segmentation读取	\N	crm_customer_segmentation	read	2026-10-26 14:01:29.435478+08	\N	\N
97297d4b-9179-4391-bfa0-9d6671729e78	crm:customer_segmentation:create	customer segmentation创建	\N	crm_customer_segmentation	create	2026-10-26 14:01:29.435478+08	\N	\N
7b64ace7-aaa3-4b7e-b0b1-f3d6ae9db4b4	crm:customer_segmentation:update	customer segmentation更新	\N	crm_customer_segmentation	update	2026-10-26 14:01:29.435478+08	\N	\N
b9708b1f-0b9c-41b3-a699-5d101458ee70	crm:customer_segmentation:delete	customer segmentation删除	\N	crm_customer_segmentation	delete	2026-10-26 14:01:29.435478+08	\N	\N
1deeadb4-e989-4e07-9d6c-b033e2989538	crm:recommendation:read	recommendation读取	\N	crm_recommendation	read	2026-10-26 14:01:29.435478+08	\N	\N
7ff89f7b-af75-49bd-a509-95c599b177e7	crm:recommendation:create	recommendation创建	\N	crm_recommendation	create	2026-10-26 14:01:29.435478+08	\N	\N
131d6ee2-495c-4852-9a3a-42b57690ee27	crm:recommendation:update	recommendation更新	\N	crm_recommendation	update	2026-10-26 14:01:29.435478+08	\N	\N
bd763c66-dcd5-4dd2-89a0-9aac5980c719	crm:recommendation:delete	recommendation删除	\N	crm_recommendation	delete	2026-10-26 14:01:29.435478+08	\N	\N
ec97e8b2-337e-4211-a6fa-c991f8f27326	crm:return:read	return读取	\N	crm_return	read	2026-10-26 14:01:29.435478+08	\N	\N
68b087bd-6501-440a-be6e-33d99a78203b	crm:return:create	return创建	\N	crm_return	create	2026-10-26 14:01:29.435478+08	\N	\N
06b5af3a-8568-46af-9ba9-8a4c2872ff86	crm:return:update	return更新	\N	crm_return	update	2026-10-26 14:01:29.435478+08	\N	\N
0ba75724-da4d-4646-a6d4-e0131f922587	crm:return:delete	return删除	\N	crm_return	delete	2026-10-26 14:01:29.435478+08	\N	\N
02549094-9064-43b4-9b14-4cdd00202012	qms:read	质量管理模块访问	\N	qms	read	2026-10-26 14:01:29.435478+08	\N	\N
5bb222e0-7245-40fe-8b23-0c1cf908eb79	qms:dashboard:read	质量管理仪表盘	\N	qms_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
ba312a07-1dd6-475a-bb8c-b922d4188a94	qms:inspection:read	inspection读取	\N	qms_inspection	read	2026-10-26 14:01:29.435478+08	\N	\N
2253dc7f-c302-4a74-af27-b5fdb26f6722	qms:quality_control:read	quality control读取	\N	qms_quality_control	read	2026-10-26 14:01:29.435478+08	\N	\N
5c8c0ef5-33bd-4141-ab4c-1314cef089c0	qms:nonconformance:read	nonconformance读取	\N	qms_nonconformance	read	2026-10-26 14:01:29.435478+08	\N	\N
d2bd2922-2739-40d7-b7b9-f9399cf4eb5b	qms:audit:read	audit读取	\N	qms_audit	read	2026-10-26 14:01:29.435478+08	\N	\N
fb14a52b-6f41-4333-a3f0-ef935bc6adb8	qms:audit:create	audit创建	\N	qms_audit	create	2026-10-26 14:01:29.435478+08	\N	\N
079581ab-d7d3-4719-837d-33ce4bd4ddd0	qms:audit:update	audit更新	\N	qms_audit	update	2026-10-26 14:01:29.435478+08	\N	\N
ee2f55e4-b0d4-4e23-a64d-296cd87825c0	qms:audit:delete	audit删除	\N	qms_audit	delete	2026-10-26 14:01:29.435478+08	\N	\N
eb77fbf8-089f-402c-b935-bd4a911fcd3a	qms:standard:read	standard读取	\N	qms_standard	read	2026-10-26 14:01:29.435478+08	\N	\N
404e380b-5e2a-4b81-a362-c18e4059b0fe	qms:standard:create	standard创建	\N	qms_standard	create	2026-10-26 14:01:29.435478+08	\N	\N
d9502659-74a5-4b31-9e5e-f05bf09bc61e	qms:standard:update	standard更新	\N	qms_standard	update	2026-10-26 14:01:29.435478+08	\N	\N
3c2283da-8b6e-4f71-8174-e527becff9cb	qms:standard:delete	standard删除	\N	qms_standard	delete	2026-10-26 14:01:29.435478+08	\N	\N
7a579dc8-7d46-4ac5-a209-b3cce98718e6	qms:apqp:read	apqp读取	\N	qms_apqp	read	2026-10-26 14:01:29.435478+08	\N	\N
af0d82c8-c095-4d86-914f-b86216b9d8b7	qms:apqp:create	apqp创建	\N	qms_apqp	create	2026-10-26 14:01:29.435478+08	\N	\N
37197ac0-1809-40b4-af13-a58b5cbdc795	qms:apqp:update	apqp更新	\N	qms_apqp	update	2026-10-26 14:01:29.435478+08	\N	\N
a9b5bd16-c459-4e1b-b8cd-b75499c0212a	qms:apqp:delete	apqp删除	\N	qms_apqp	delete	2026-10-26 14:01:29.435478+08	\N	\N
fe7160d4-8588-4408-923d-c75e27c32d66	qms:fmea:read	fmea读取	\N	qms_fmea	read	2026-10-26 14:01:29.435478+08	\N	\N
c59c8a73-c1b7-4872-be60-0053197e9b72	qms:fmea:create	fmea创建	\N	qms_fmea	create	2026-10-26 14:01:29.435478+08	\N	\N
234f4124-6147-495d-8c73-343b542cdf98	qms:fmea:update	fmea更新	\N	qms_fmea	update	2026-10-26 14:01:29.435478+08	\N	\N
9e73093d-8c11-4a8f-a20f-354b0fea42ea	qms:fmea:delete	fmea删除	\N	qms_fmea	delete	2026-10-26 14:01:29.435478+08	\N	\N
13421cff-3527-41a0-a28c-b70f1a3585a0	qms:spc:read	spc读取	\N	qms_spc	read	2026-10-26 14:01:29.435478+08	\N	\N
96ed4ac9-5cc4-44a8-ad49-86372a73425d	qms:spc:create	spc创建	\N	qms_spc	create	2026-10-26 14:01:29.435478+08	\N	\N
e72535d1-26f5-412a-ad4c-44e22dd37aa7	qms:spc:update	spc更新	\N	qms_spc	update	2026-10-26 14:01:29.435478+08	\N	\N
e5bd49ff-31a1-4af8-a96f-e559f6ab56e5	qms:spc:delete	spc删除	\N	qms_spc	delete	2026-10-26 14:01:29.435478+08	\N	\N
6c903dd3-55be-4942-b8d7-6acf379830f2	qms:eightd:read	eightd读取	\N	qms_eightd	read	2026-10-26 14:01:29.435478+08	\N	\N
e7ead4bc-4a61-4bba-a2ac-ed3c2a127f53	qms:eightd:create	eightd创建	\N	qms_eightd	create	2026-10-26 14:01:29.435478+08	\N	\N
a5ede0df-cf02-42ea-ab96-99595da8f88a	qms:eightd:update	eightd更新	\N	qms_eightd	update	2026-10-26 14:01:29.435478+08	\N	\N
8aa7d8ec-fc90-4515-9bb0-fa5c9b01c59c	qms:eightd:delete	eightd删除	\N	qms_eightd	delete	2026-10-26 14:01:29.435478+08	\N	\N
2c9b3eca-e592-4e7b-8325-fb0e858ab64e	qms:quality_cost:read	quality cost读取	\N	qms_quality_cost	read	2026-10-26 14:01:29.435478+08	\N	\N
53b99751-94b8-4812-bb66-a9a6184afb24	qms:quality_cost:create	quality cost创建	\N	qms_quality_cost	create	2026-10-26 14:01:29.435478+08	\N	\N
87420d52-ba91-4e2f-ac58-943add2a94b2	qms:quality_cost:update	quality cost更新	\N	qms_quality_cost	update	2026-10-26 14:01:29.435478+08	\N	\N
2ddb6ac6-ffc2-495a-8ad2-cde85e51805f	qms:quality_cost:delete	quality cost删除	\N	qms_quality_cost	delete	2026-10-26 14:01:29.435478+08	\N	\N
9b8ef6b9-fa20-478c-9c07-70d5ef7b77f4	scm:read	供应链管理模块访问	\N	scm	read	2026-10-26 14:01:29.435478+08	\N	\N
d0e130c7-e561-4c51-804e-174c1c214acf	scm:dashboard:read	供应链管理仪表盘	\N	scm_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
0219820f-acc8-42e8-9cfc-076678845d8d	scm:purchase_order:read	purchase order读取	\N	scm_purchase_order	read	2026-10-26 14:01:29.435478+08	\N	\N
e3d3c5c9-ffb5-49f6-b5e1-28a6fd63d729	scm:purchase_order:create	purchase order创建	\N	scm_purchase_order	create	2026-10-26 14:01:29.435478+08	\N	\N
062db79a-115b-43e0-809b-c61cbc101d08	scm:purchase_order:update	purchase order更新	\N	scm_purchase_order	update	2026-10-26 14:01:29.435478+08	\N	\N
acc141d9-8527-4302-b086-286cc8b4e26d	scm:purchase_order:delete	purchase order删除	\N	scm_purchase_order	delete	2026-10-26 14:01:29.435478+08	\N	\N
e1f9389a-5b46-48d6-8f4d-b6acda13224c	scm:purchase_requisition:read	purchase requisition读取	\N	scm_purchase_requisition	read	2026-10-26 14:01:29.435478+08	\N	\N
bef50f16-48fe-43ee-b602-ce0648d60bec	scm:purchase_requisition:create	purchase requisition创建	\N	scm_purchase_requisition	create	2026-10-26 14:01:29.435478+08	\N	\N
a2235068-27aa-4cdb-8186-8dc5f34b9906	scm:purchase_requisition:update	purchase requisition更新	\N	scm_purchase_requisition	update	2026-10-26 14:01:29.435478+08	\N	\N
b21307d2-04bc-47ad-afbc-5f3c63516e69	scm:purchase_requisition:delete	purchase requisition删除	\N	scm_purchase_requisition	delete	2026-10-26 14:01:29.435478+08	\N	\N
0131194a-d752-45f5-98df-aa7d4b966495	scm:purchase_item:read	purchase item读取	\N	scm_purchase_item	read	2026-10-26 14:01:29.435478+08	\N	\N
f3feddd3-d875-41b3-88dc-45b530338100	scm:purchase_item:create	purchase item创建	\N	scm_purchase_item	create	2026-10-26 14:01:29.435478+08	\N	\N
2511b976-6160-43e0-8fb7-f481aa7a942a	scm:purchase_item:update	purchase item更新	\N	scm_purchase_item	update	2026-10-26 14:01:29.435478+08	\N	\N
b6a8bca9-2601-48f2-a84e-6c429ad28b57	scm:purchase_item:delete	purchase item删除	\N	scm_purchase_item	delete	2026-10-26 14:01:29.435478+08	\N	\N
32931da2-7f1b-45f3-b8b6-693c85a78214	scm:supplier:read	supplier读取	\N	scm_supplier	read	2026-10-26 14:01:29.435478+08	\N	\N
c5f852c6-3ce8-4733-906d-0b3219038030	scm:supplier:create	supplier创建	\N	scm_supplier	create	2026-10-26 14:01:29.435478+08	\N	\N
64af5f26-55bf-4344-b773-ed05b9343ddb	scm:supplier:update	supplier更新	\N	scm_supplier	update	2026-10-26 14:01:29.435478+08	\N	\N
fcd2b07f-1bc1-40a6-980b-38e7c50271b1	scm:supplier:delete	supplier删除	\N	scm_supplier	delete	2026-10-26 14:01:29.435478+08	\N	\N
3599d649-04de-456c-aff1-918b055821f2	scm:supplier_admission:read	supplier admission读取	\N	scm_supplier_admission	read	2026-10-26 14:01:29.435478+08	\N	\N
2895206b-f2a0-46e4-9591-6496e86ee998	scm:supplier_admission:create	supplier admission创建	\N	scm_supplier_admission	create	2026-10-26 14:01:29.435478+08	\N	\N
21734117-630c-41e0-9254-f6f0c413a60a	scm:supplier_admission:update	supplier admission更新	\N	scm_supplier_admission	update	2026-10-26 14:01:29.435478+08	\N	\N
a5d09c5c-fcae-4ac0-a12d-cb25599807ee	scm:supplier_admission:delete	supplier admission删除	\N	scm_supplier_admission	delete	2026-10-26 14:01:29.435478+08	\N	\N
b9e62243-f9b8-4fdd-b1bb-505a40ea5af1	scm:supplier_evaluation:read	supplier evaluation读取	\N	scm_supplier_evaluation	read	2026-10-26 14:01:29.435478+08	\N	\N
91ba6a97-484a-4a82-adf7-75311a7e1a1c	scm:supplier_evaluation:create	supplier evaluation创建	\N	scm_supplier_evaluation	create	2026-10-26 14:01:29.435478+08	\N	\N
0266701c-10e1-47d2-a950-556be5d801df	scm:supplier_evaluation:update	supplier evaluation更新	\N	scm_supplier_evaluation	update	2026-10-26 14:01:29.435478+08	\N	\N
7ea4ad92-2ff1-40b8-b71e-a22a01ce162b	scm:supplier_evaluation:delete	supplier evaluation删除	\N	scm_supplier_evaluation	delete	2026-10-26 14:01:29.435478+08	\N	\N
d5974ebc-b20a-4380-ab81-6bd5ece9eb69	scm:contract:read	contract读取	\N	scm_contract	read	2026-10-26 14:01:29.435478+08	\N	\N
6fe0fa7b-f293-46a7-af89-76586fb43a88	scm:contract:create	contract创建	\N	scm_contract	create	2026-10-26 14:01:29.435478+08	\N	\N
5a117c91-85bc-4953-9c6a-e8796aa088eb	scm:contract:update	contract更新	\N	scm_contract	update	2026-10-26 14:01:29.435478+08	\N	\N
df097ebe-254d-4429-89b7-abc8021be8b0	scm:contract:delete	contract删除	\N	scm_contract	delete	2026-10-26 14:01:29.435478+08	\N	\N
9c0cbd06-1385-43ff-9ab9-693e26af462c	scm:delivery_appointment:read	delivery appointment读取	\N	scm_delivery_appointment	read	2026-10-26 14:01:29.435478+08	\N	\N
dc3b3534-41b4-45e5-9e98-0fa92cc64014	scm:delivery_appointment:create	delivery appointment创建	\N	scm_delivery_appointment	create	2026-10-26 14:01:29.435478+08	\N	\N
414ef850-468d-4775-8f69-9d6b445515f6	scm:delivery_appointment:update	delivery appointment更新	\N	scm_delivery_appointment	update	2026-10-26 14:01:29.435478+08	\N	\N
66ba4a48-7630-4ff4-8074-b22f3cd667a5	scm:delivery_appointment:delete	delivery appointment删除	\N	scm_delivery_appointment	delete	2026-10-26 14:01:29.435478+08	\N	\N
f0bbf9aa-9a56-42dc-8211-8092a0c2c4e0	scm:mrp_plan:read	mrp plan读取	\N	scm_mrp_plan	read	2026-10-26 14:01:29.435478+08	\N	\N
76f15e54-cbdd-435b-9674-a382aecf952d	scm:mrp_plan:create	mrp plan创建	\N	scm_mrp_plan	create	2026-10-26 14:01:29.435478+08	\N	\N
37359d83-d5f8-4bd3-9472-0f2faf5f04a1	scm:mrp_plan:update	mrp plan更新	\N	scm_mrp_plan	update	2026-10-26 14:01:29.435478+08	\N	\N
55ea4b4e-06b1-4c6a-bffe-62f11d3b8f37	scm:mrp_plan:delete	mrp plan删除	\N	scm_mrp_plan	delete	2026-10-26 14:01:29.435478+08	\N	\N
6f027480-1c78-4d9e-9968-2b25ed52d404	scm:mrp_suggestion:read	mrp suggestion读取	\N	scm_mrp_suggestion	read	2026-10-26 14:01:29.435478+08	\N	\N
c8f60ebc-38df-414b-83d8-01e551347e90	scm:mrp_suggestion:create	mrp suggestion创建	\N	scm_mrp_suggestion	create	2026-10-26 14:01:29.435478+08	\N	\N
3b80ae6b-0c62-486d-9466-d47f9f9aa61e	scm:mrp_suggestion:update	mrp suggestion更新	\N	scm_mrp_suggestion	update	2026-10-26 14:01:29.435478+08	\N	\N
bcf0e340-cecf-4cdd-9931-6a530d48f6cf	scm:mrp_suggestion:delete	mrp suggestion删除	\N	scm_mrp_suggestion	delete	2026-10-26 14:01:29.435478+08	\N	\N
817f3abf-8b60-4e41-ad3f-116b3491cc2f	scm:inventory_turnover:read	inventory turnover读取	\N	scm_inventory_turnover	read	2026-10-26 14:01:29.435478+08	\N	\N
afabc962-6aec-41dd-b62f-15d35f06fb21	scm:inventory_turnover:create	inventory turnover创建	\N	scm_inventory_turnover	create	2026-10-26 14:01:29.435478+08	\N	\N
893a3899-6db1-439c-b6e6-b348a0ce750f	scm:inventory_turnover:update	inventory turnover更新	\N	scm_inventory_turnover	update	2026-10-26 14:01:29.435478+08	\N	\N
c1f84f46-fb11-4f6e-b482-8d79602426a0	scm:inventory_turnover:delete	inventory turnover删除	\N	scm_inventory_turnover	delete	2026-10-26 14:01:29.435478+08	\N	\N
b3c44503-8d14-4940-b8ff-92e12f0330d3	scm:price_comparison:read	price comparison读取	\N	scm_price_comparison	read	2026-10-26 14:01:29.435478+08	\N	\N
613aa7b0-bff6-4274-8fb0-d055835f5b67	scm:price_comparison:create	price comparison创建	\N	scm_price_comparison	create	2026-10-26 14:01:29.435478+08	\N	\N
e608a054-194d-4b03-bbe8-b136d4e563ff	scm:price_comparison:update	price comparison更新	\N	scm_price_comparison	update	2026-10-26 14:01:29.435478+08	\N	\N
7599c635-56eb-4596-843d-8bb7f9e90030	scm:price_comparison:delete	price comparison删除	\N	scm_price_comparison	delete	2026-10-26 14:01:29.435478+08	\N	\N
dde1f05d-951b-437f-83dd-ce3488c922aa	srm:read	供应商关系模块访问	\N	srm	read	2026-10-26 14:01:29.435478+08	\N	\N
366229bc-ff89-4a2b-809b-f72dcd98cd64	srm:dashboard:read	供应商关系仪表盘	\N	srm_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
37c957c2-94f3-4a92-a99c-c070a1e3e0d1	srm:supplier:read	supplier读取	\N	srm_supplier	read	2026-10-26 14:01:29.435478+08	\N	\N
1fb8e26f-8700-4ad6-91a5-6d670223264e	srm:supplier:create	supplier创建	\N	srm_supplier	create	2026-10-26 14:01:29.435478+08	\N	\N
7b7c1cd5-c3d0-4e9f-9a16-277e62c997ba	srm:supplier:update	supplier更新	\N	srm_supplier	update	2026-10-26 14:01:29.435478+08	\N	\N
49eb6481-e64c-4569-9118-78c24d76409b	srm:supplier:delete	supplier删除	\N	srm_supplier	delete	2026-10-26 14:01:29.435478+08	\N	\N
29ffc53c-b93d-4268-ad7c-d43449f79622	srm:category:read	category读取	\N	srm_category	read	2026-10-26 14:01:29.435478+08	\N	\N
e8187b78-17b3-4db9-bded-6969db485bb7	srm:category:create	category创建	\N	srm_category	create	2026-10-26 14:01:29.435478+08	\N	\N
02abd9e0-faf0-4ad0-9a6b-b11402fcdaec	srm:category:update	category更新	\N	srm_category	update	2026-10-26 14:01:29.435478+08	\N	\N
e12ac640-497e-4877-8911-dc8b8429499c	srm:category:delete	category删除	\N	srm_category	delete	2026-10-26 14:01:29.435478+08	\N	\N
0fc2eeff-f6cf-4b1e-83f6-87e5590fb996	srm:product:read	product读取	\N	srm_product	read	2026-10-26 14:01:29.435478+08	\N	\N
5951879f-237e-4d16-aaf8-f7b2f91f760f	srm:product:create	product创建	\N	srm_product	create	2026-10-26 14:01:29.435478+08	\N	\N
83d6a617-bae4-46f5-9d29-c91172b29eb2	srm:product:update	product更新	\N	srm_product	update	2026-10-26 14:01:29.435478+08	\N	\N
9370dc2b-11a8-40a7-b7c9-ca3c512b9969	srm:product:delete	product删除	\N	srm_product	delete	2026-10-26 14:01:29.435478+08	\N	\N
f1eef12a-224f-4bfc-b4c0-78f0f4365717	srm:contract:read	contract读取	\N	srm_contract	read	2026-10-26 14:01:29.435478+08	\N	\N
7284c60f-61b8-4358-bfff-1ad0a28766cf	srm:contract:create	contract创建	\N	srm_contract	create	2026-10-26 14:01:29.435478+08	\N	\N
7f10e653-23be-48b0-a3cb-a06e0898151b	srm:contract:update	contract更新	\N	srm_contract	update	2026-10-26 14:01:29.435478+08	\N	\N
4f11c6ed-7a00-41bf-8224-46e13b5d9bad	srm:contract:delete	contract删除	\N	srm_contract	delete	2026-10-26 14:01:29.435478+08	\N	\N
d84664ce-ae82-49f5-8a53-05c9a4d7cba5	srm:order:read	order读取	\N	srm_order	read	2026-10-26 14:01:29.435478+08	\N	\N
23c50969-a410-49a0-96a5-1817ece1ba47	srm:order:create	order创建	\N	srm_order	create	2026-10-26 14:01:29.435478+08	\N	\N
cde49d8a-9c6e-4c97-9582-9b2f9af19916	srm:order:update	order更新	\N	srm_order	update	2026-10-26 14:01:29.435478+08	\N	\N
ec945b09-9169-4bd6-84b6-bf413e8df431	srm:order:delete	order删除	\N	srm_order	delete	2026-10-26 14:01:29.435478+08	\N	\N
08a7eafd-46a2-47d1-a482-28f7a6d1d6ee	srm:evaluation:read	evaluation读取	\N	srm_evaluation	read	2026-10-26 14:01:29.435478+08	\N	\N
1d6ce285-d577-43c6-9c72-b9fdb34ad41e	srm:evaluation:create	evaluation创建	\N	srm_evaluation	create	2026-10-26 14:01:29.435478+08	\N	\N
2a2274c4-9add-4720-a052-440bbf48ba4e	srm:evaluation:update	evaluation更新	\N	srm_evaluation	update	2026-10-26 14:01:29.435478+08	\N	\N
d5b39d10-bdfa-4982-b45c-1bbf17d55eed	srm:evaluation:delete	evaluation删除	\N	srm_evaluation	delete	2026-10-26 14:01:29.435478+08	\N	\N
9be516cb-913e-4823-b57f-3b641577bd45	srm:performance:read	performance读取	\N	srm_performance	read	2026-10-26 14:01:29.435478+08	\N	\N
86bce5a8-1d56-4650-89b4-650ece7b4c2a	srm:performance:create	performance创建	\N	srm_performance	create	2026-10-26 14:01:29.435478+08	\N	\N
7cc0f634-61d1-4ab1-843b-841399c92dbd	srm:performance:update	performance更新	\N	srm_performance	update	2026-10-26 14:01:29.435478+08	\N	\N
cec60167-5fd1-4f27-9897-b722fb54534e	srm:performance:delete	performance删除	\N	srm_performance	delete	2026-10-26 14:01:29.435478+08	\N	\N
2583dd2f-8591-4c95-b602-372feb3e8477	srm:inquiry:read	inquiry读取	\N	srm_inquiry	read	2026-10-26 14:01:29.435478+08	\N	\N
59202f74-f468-4ec3-8819-b1c1e2739762	srm:inquiry:create	inquiry创建	\N	srm_inquiry	create	2026-10-26 14:01:29.435478+08	\N	\N
e0e6b4a3-5856-40d4-a34d-4d77e3506b4d	srm:inquiry:update	inquiry更新	\N	srm_inquiry	update	2026-10-26 14:01:29.435478+08	\N	\N
c640d369-53ab-4b61-a818-95b60a1b58a9	srm:inquiry:delete	inquiry删除	\N	srm_inquiry	delete	2026-10-26 14:01:29.435478+08	\N	\N
b322c847-46f8-4169-ae78-162b4d5f944d	srm:bidding:read	bidding读取	\N	srm_bidding	read	2026-10-26 14:01:29.435478+08	\N	\N
970fbbab-5287-4b95-96cc-6e703f3fc988	srm:bidding:create	bidding创建	\N	srm_bidding	create	2026-10-26 14:01:29.435478+08	\N	\N
8918e044-f0c6-4981-8112-de8427367969	srm:bidding:update	bidding更新	\N	srm_bidding	update	2026-10-26 14:01:29.435478+08	\N	\N
f4e6500b-b196-4ab8-97c6-316000f71f2b	srm:bidding:delete	bidding删除	\N	srm_bidding	delete	2026-10-26 14:01:29.435478+08	\N	\N
8378ac17-4000-477b-9a81-cb34ace6c9ba	srm:finance:read	finance读取	\N	srm_finance	read	2026-10-26 14:01:29.435478+08	\N	\N
4853e6e1-0c01-4cd1-8321-9c769e12735d	srm:finance:create	finance创建	\N	srm_finance	create	2026-10-26 14:01:29.435478+08	\N	\N
00080d63-f28b-493c-8e8e-f0f929f46329	srm:finance:update	finance更新	\N	srm_finance	update	2026-10-26 14:01:29.435478+08	\N	\N
a6aeb533-db2e-4a7f-9fa6-cdd0bed5cb07	srm:finance:delete	finance删除	\N	srm_finance	delete	2026-10-26 14:01:29.435478+08	\N	\N
6d214a03-6461-4b89-a2bb-5429ea0a56e7	srm:portal:read	portal读取	\N	srm_portal	read	2026-10-26 14:01:29.435478+08	\N	\N
49cd8606-84d2-4b74-96e8-71c6a27cdade	srm:quotation:read	quotation读取	\N	srm_quotation	read	2026-10-26 14:01:29.435478+08	\N	\N
88e6c1bb-025d-4320-8939-2616f71dcd07	srm:quotation:create	quotation创建	\N	srm_quotation	create	2026-10-26 14:01:29.435478+08	\N	\N
ec557fbd-dd4b-426f-9802-08f17e53de5b	srm:quotation:update	quotation更新	\N	srm_quotation	update	2026-10-26 14:01:29.435478+08	\N	\N
7859bae3-2f07-49bb-9a0b-95c2f3d44fc1	srm:quotation:delete	quotation删除	\N	srm_quotation	delete	2026-10-26 14:01:29.435478+08	\N	\N
2bc4a409-d6fa-4711-8ba4-d42ae723a6fc	report:read	报表中心模块访问	\N	report	read	2026-10-26 14:01:29.435478+08	\N	\N
00db48de-8483-4b5f-8e00-e2c53a57a33a	report:dashboard:read	报表中心仪表盘	\N	report_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
9738a126-0112-4e48-a33e-c03f1212713c	report:schedule:read	schedule读取	\N	report_schedule	read	2026-10-26 14:01:29.435478+08	\N	\N
b7c7443f-19c2-448d-9acb-82a4770f626e	report:subscription:read	subscription读取	\N	report_subscription	read	2026-10-26 14:01:29.435478+08	\N	\N
30938453-4723-4d6f-967f-4eb7366bf31f	report:subscription:create	subscription创建	\N	report_subscription	create	2026-10-26 14:01:29.435478+08	\N	\N
eb0379d6-cf5e-4138-8296-1d3d26797ce7	report:subscription:update	subscription更新	\N	report_subscription	update	2026-10-26 14:01:29.435478+08	\N	\N
abb57291-1b9e-4528-8aa8-ce1173490c6a	report:subscription:delete	subscription删除	\N	report_subscription	delete	2026-10-26 14:01:29.435478+08	\N	\N
a69ff633-b1d9-4eef-b75c-7d4a19e53275	report:template:read	template读取	\N	report_template	read	2026-10-26 14:01:29.435478+08	\N	\N
1948ee1c-63f3-4172-91b7-4e3b6565f872	pm:read	项目管理模块访问	\N	pm	read	2026-10-26 14:01:29.435478+08	\N	\N
1ed32704-aa8f-40cb-9575-06190a597154	pm:dashboard:read	项目管理仪表盘	\N	pm_dashboard	read	2026-10-26 14:01:29.435478+08	\N	\N
44be4839-b13d-4441-8fce-f63d7c1134d4	pm:project:read	project读取	\N	pm_project	read	2026-10-26 14:01:29.435478+08	\N	\N
81bb7faa-3dcb-4e54-83bf-4ce7849f995e	pm:project:create	project创建	\N	pm_project	create	2026-10-26 14:01:29.435478+08	\N	\N
c562c184-e015-4546-a582-0c7fffed8947	pm:project:update	project更新	\N	pm_project	update	2026-10-26 14:01:29.435478+08	\N	\N
44c473b2-e325-4f8d-8c1c-93837945a6af	pm:project:delete	project删除	\N	pm_project	delete	2026-10-26 14:01:29.435478+08	\N	\N
75ac5cce-e9c5-4544-8d5b-72c1fc3622d6	pm:contract:read	contract读取	\N	pm_contract	read	2026-10-26 14:01:29.435478+08	\N	\N
24759246-4008-4e6a-84e1-b2abf02cbde3	pm:contract:create	contract创建	\N	pm_contract	create	2026-10-26 14:01:29.435478+08	\N	\N
d5d17649-01e6-4d2b-b7ee-2c2275226520	pm:contract:update	contract更新	\N	pm_contract	update	2026-10-26 14:01:29.435478+08	\N	\N
d1885cc3-f822-4c3a-ade5-bea5c3116d2e	pm:contract:delete	contract删除	\N	pm_contract	delete	2026-10-26 14:01:29.435478+08	\N	\N
d19ae1a8-c61f-41d4-a91f-91647b934f13	pm:resource:read	resource读取	\N	pm_resource	read	2026-10-26 14:01:29.435478+08	\N	\N
bf2b5ab6-6669-4c69-b4ab-4ec6d2f1ec98	pm:resource:create	resource创建	\N	pm_resource	create	2026-10-26 14:01:29.435478+08	\N	\N
80457de9-b5ff-4126-8b96-71f54746fd40	pm:resource:update	resource更新	\N	pm_resource	update	2026-10-26 14:01:29.435478+08	\N	\N
bc09003b-7994-4375-8ded-88cd26594627	pm:resource:delete	resource删除	\N	pm_resource	delete	2026-10-26 14:01:29.435478+08	\N	\N
d84d44a6-19ca-4bca-93e8-8ac6c47efe95	pm:template:read	template读取	\N	pm_template	read	2026-10-26 14:01:29.435478+08	\N	\N
a2ffd5d8-bb3f-4208-935c-119ed2595800	pm:report:read	report读取	\N	pm_report	read	2026-10-26 14:01:29.435478+08	\N	\N
d7383cfa-0340-4b30-9deb-821749cb6652	pm:task:read	task读取	\N	pm_task	read	2026-10-26 14:01:29.435478+08	\N	\N
cbec48fa-6412-40df-b582-2406d2827682	admin:account:read	admin:account:read	Auto-registered from frontend usage: admin/config	admin:account	read	2026-10-26 14:01:30.248488+08	\N	1
fa27c4d5-7075-4690-add0-f7342e77347c	admin:audit:read	admin:audit:read	Auto-registered from frontend usage: admin/config	admin:audit	read	2026-10-26 14:01:30.248488+08	\N	1
ac0ffea6-a0b5-486d-866a-6ba34337d202	admin:bank:read	admin:bank:read	Auto-registered from frontend usage: admin/config	admin:bank	read	2026-10-26 14:01:30.248488+08	\N	1
2df54da6-ee63-4bd2-8124-d1de88d8d59a	admin:dashboard:read	admin:dashboard:read	Auto-registered from frontend usage: admin/config	admin:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
58084aa1-ad0b-44b4-9625-8bfbcd706c85	admin:database:read	admin:database:read	Auto-registered from frontend usage: admin/config	admin:database	read	2026-10-26 14:01:30.248488+08	\N	1
4fd2b28a-5c0e-4391-a046-ea90b14b78f0	admin:debug:read	admin:debug:read	Auto-registered from frontend usage: admin/config	admin:debug	read	2026-10-26 14:01:30.248488+08	\N	1
1514fad6-240a-44ee-b5ee-632e3b23eaee	admin:dictionary:read	admin:dictionary:read	Auto-registered from frontend usage: admin/config	admin:dictionary	read	2026-10-26 14:01:30.248488+08	\N	1
afb3fa83-3a66-4c5a-9e2f-f0cd7d813749	admin:migration:read	admin:migration:read	Auto-registered from frontend usage: admin/config	admin:migration	read	2026-10-26 14:01:30.248488+08	\N	1
b4d2fa99-a7cd-4fee-aa77-1737c239e907	admin:monitor:read	admin:monitor:read	Auto-registered from frontend usage: admin/config	admin:monitor	read	2026-10-26 14:01:30.248488+08	\N	1
b2801f5d-d1a1-416c-9b22-71722d0991f3	admin:plugin:read	admin:plugin:read	Auto-registered from frontend usage: admin/config	admin:plugin	read	2026-10-26 14:01:30.248488+08	\N	1
b171631b-7efb-4c03-82a4-469fb499044b	admin:plugin:write	admin:plugin:write	Auto-registered from frontend usage: plugin/config	admin:plugin	write	2026-10-26 14:01:30.248488+08	\N	1
73f56787-1414-4a11-921b-c4957e8edf5f	admin:system:read	admin:system:read	Auto-registered from frontend usage: admin/config	admin:system	read	2026-10-26 14:01:30.248488+08	\N	1
3edf125e-7794-49b0-9564-3ae59a0abe0d	admin:system:write	admin:system:write	Auto-registered from frontend usage: admin/config	admin:system	write	2026-10-26 14:01:30.248488+08	\N	1
540931f1-e88a-4387-8109-ebdd0fe87c25	admin:tenant:read	admin:tenant:read	Auto-registered from frontend usage: admin/config	admin:tenant	read	2026-10-26 14:01:30.248488+08	\N	1
e91e6a6f-50c1-47b1-a847-7f3c23cae68a	ai:chat:read	ai:chat:read	Auto-registered from frontend usage: ai/config	ai:chat	read	2026-10-26 14:01:30.248488+08	\N	1
101fdf4c-274d-4940-bca5-d9c946a88f35	ai:code:read	ai:code:read	Auto-registered from frontend usage: ai/config	ai:code	read	2026-10-26 14:01:30.248488+08	\N	1
45a8787d-c4fb-41b7-a638-ce30e1acaca5	ai:dashboard:admin	ai:dashboard:admin	Auto-registered from frontend usage: ai/config	ai:dashboard	admin	2026-10-26 14:01:30.248488+08	\N	1
dc50d5ec-e123-4df1-bdc2-e057bbad5a3a	ai:dashboard:read	ai:dashboard:read	Auto-registered from frontend usage: ai/config	ai:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
58b3df4f-fb0b-49cb-b63a-00a89a9d5b9a	ai:document:read	ai:document:read	Auto-registered from frontend usage: ai/config	ai:document	read	2026-10-26 14:01:30.248488+08	\N	1
9cb62667-ee23-4912-ba8d-ad2d934ab0d9	ai:governance:read	ai:governance:read	Auto-registered from frontend usage: ai/config	ai:governance	read	2026-10-26 14:01:30.248488+08	\N	1
fb4498b2-0a0a-45ea-8a03-86e88b97ab87	ai:knowledge:read	ai:knowledge:read	Auto-registered from frontend usage: ai/config	ai:knowledge	read	2026-10-26 14:01:30.248488+08	\N	1
1a20d9ac-13f4-40b5-b67f-ba076f50d938	ai:prompt:read	ai:prompt:read	Auto-registered from frontend usage: ai/config	ai:prompt	read	2026-10-26 14:01:30.248488+08	\N	1
3f46003b-7a9e-4a87-b9f7-c02dd07d733a	aps:capacity:read	aps:capacity:read	Auto-registered from frontend usage: aps/config	aps:capacity	read	2026-10-26 14:01:30.248488+08	\N	1
69048971-72b8-4338-9e25-5b0ddfa88a12	aps:dashboard:read	aps:dashboard:read	Auto-registered from frontend usage: aps/config	aps:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
1087e748-6534-4806-8ddb-bd68027d9b85	aps:forecast:read	aps:forecast:read	Auto-registered from frontend usage: aps/config	aps:forecast	read	2026-10-26 14:01:30.248488+08	\N	1
43c438a3-4897-4dc1-87da-2d8a2c03834f	aps:material_plan:read	aps:material_plan:read	Auto-registered from frontend usage: aps/config	aps:material_plan	read	2026-10-26 14:01:30.248488+08	\N	1
1b8eb69e-c20e-4dbb-b573-0df704fd632a	aps:module:read	aps:module:read	Auto-registered from frontend usage: aps/config	aps:module	read	2026-10-26 14:01:30.248488+08	\N	1
94cb55f4-5d0f-429a-96d5-0e68d24f92aa	aps:production_plan:read	aps:production_plan:read	Auto-registered from frontend usage: aps/config	aps:production_plan	read	2026-10-26 14:01:30.248488+08	\N	1
44799ef4-b664-4b1a-95ea-98d49d02f8be	aps:schedule:read	aps:schedule:read	Auto-registered from frontend usage: aps/config	aps:schedule	read	2026-10-26 14:01:30.248488+08	\N	1
06dde5b6-4093-4058-a0d7-5867cfa26a94	asset:category:read	asset:category:read	Auto-registered from frontend usage: asset/config	asset:category	read	2026-10-26 14:01:30.248488+08	\N	1
7c8e444d-6dd4-42e0-b6ae-6f8e3cf554ab	asset:dashboard:read	asset:dashboard:read	Auto-registered from frontend usage: asset/config	asset:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
232afb75-423d-445b-ae5c-5f12238c0be2	asset:depreciation:read	asset:depreciation:read	Auto-registered from frontend usage: asset/config	asset:depreciation	read	2026-10-26 14:01:30.248488+08	\N	1
3b02fa01-e1ab-4875-b96f-19216052d179	asset:list:read	asset:list:read	Auto-registered from frontend usage: asset/config	asset:list	read	2026-10-26 14:01:30.248488+08	\N	1
658eb2ce-8a38-4c61-8706-95a1e0674067	asset:transfer:read	asset:transfer:read	Auto-registered from frontend usage: asset/config	asset:transfer	read	2026-10-26 14:01:30.248488+08	\N	1
b372ac5c-b9e0-4bad-a3cd-9e7d879a6ef1	automation:dashboard:read	automation:dashboard:read	Auto-registered from frontend usage: automation/config	automation:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
8e2ccfcf-fe5c-4b18-b512-47956b16926f	automation:rule:read	automation:rule:read	Auto-registered from frontend usage: automation/config	automation:rule	read	2026-10-26 14:01:30.248488+08	\N	1
75eea67f-240f-429f-a401-84750e3756f2	automation:rule:write	automation:rule:write	Auto-registered from frontend usage: automation/config	automation:rule	write	2026-10-26 14:01:30.248488+08	\N	1
278dc783-e8b4-4a50-8f15-1c04780e6a71	automation:run:read	automation:run:read	Auto-registered from frontend usage: automation/config	automation:run	read	2026-10-26 14:01:30.248488+08	\N	1
febf33da-dd87-4c39-9676-71bc9e78e58d	automation:variable:read	automation:variable:read	Auto-registered from frontend usage: automation/config	automation:variable	read	2026-10-26 14:01:30.248488+08	\N	1
fcfe77a6-5349-48ce-b3c7-8093730393a7	bi:analytics:read	bi:analytics:read	Auto-registered from frontend usage: bi/config	bi:analytics	read	2026-10-26 14:01:30.248488+08	\N	1
40bc4a3c-ff77-44fa-8c5d-6ce4307a18f2	bi:comparison:read	bi:comparison:read	Auto-registered from frontend usage: bi/config	bi:comparison	read	2026-10-26 14:01:30.248488+08	\N	1
d20125ba-910a-4bfb-a3ff-5f9028f2dcd4	bi:dashboard:admin	bi:dashboard:admin	Auto-registered from frontend usage: bi/config	bi:dashboard	admin	2026-10-26 14:01:30.248488+08	\N	1
5f9c0a91-658f-41f0-9523-9ab2b3c58929	bi:dashboard:read	bi:dashboard:read	Auto-registered from frontend usage: bi/config	bi:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
15d576f8-a39c-4ec7-bf37-f3245f1fb3dc	bi:data_source:read	bi:data_source:read	Auto-registered from frontend usage: bi/config	bi:data_source	read	2026-10-26 14:01:30.248488+08	\N	1
c84c3478-cba6-40d0-a077-759805f7fc26	bi:dataset:read	bi:dataset:read	Auto-registered from frontend usage: bi/config	bi:dataset	read	2026-10-26 14:01:30.248488+08	\N	1
4e0310c4-82c9-493d-a714-f1b67716510b	bi:gis:read	bi:gis:read	Auto-registered from frontend usage: bi/config	bi:gis	read	2026-10-26 14:01:30.248488+08	\N	1
de92105e-2042-4e48-ad3d-c8429e70e950	bi:index:read	bi:index:read	Auto-registered from frontend usage: bi/config	bi:index	read	2026-10-26 14:01:30.248488+08	\N	1
a418147a-18ea-40e4-bf1d-aa9a02ad20ec	bi:report:read	bi:report:read	Auto-registered from frontend usage: bi/config	bi:report	read	2026-10-26 14:01:30.248488+08	\N	1
fafc560a-66f8-4dcb-9b34-81ec34e7485c	bi:report:write	bi:report:write	Auto-registered from frontend usage: bi/config	bi:report	write	2026-10-26 14:01:30.248488+08	\N	1
f1b2e6bb-e6f5-4178-9796-564cac064aeb	bi:visualization:read	bi:visualization:read	Auto-registered from frontend usage: bi/config	bi:visualization	read	2026-10-26 14:01:30.248488+08	\N	1
6c0e8343-5b19-498c-b10d-6369a1653919	crm:forecast:read	crm:forecast:read	Auto-registered from frontend usage: crm/config	crm:forecast	read	2026-10-26 14:01:30.248488+08	\N	1
f9114ecd-4fec-4dbb-84fc-076055dc106a	crm:rfm:read	crm:rfm:read	Auto-registered from frontend usage: crm/config	crm:rfm	read	2026-10-26 14:01:30.248488+08	\N	1
7d8f033a-b8dc-4234-a758-5c401c1b69fc	doc:center:read	doc:center:read	Auto-registered from frontend usage: doc/config	doc:center	read	2026-10-26 14:01:30.248488+08	\N	1
43413d05-33f5-4196-8fe8-fbeead68cc4e	doc:dashboard:read	doc:dashboard:read	Auto-registered from frontend usage: doc/config	doc:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
88e4530a-d048-4770-aee2-88b210e836d4	doc:document:read	doc:document:read	Auto-registered from frontend usage: doc/config	doc:document	read	2026-10-26 14:01:30.248488+08	\N	1
168a10ee-0cd4-4bf6-8050-e4e011d40762	erp:accounting_subject:read	erp:accounting_subject:read	Auto-registered from frontend usage: erp/config	erp:accounting_subject	read	2026-10-26 14:01:30.248488+08	\N	1
9b458eb1-3887-4d09-aacf-0c4056f191a4	erp:announcement:read	erp:announcement:read	Auto-registered from frontend usage: erp/config	erp:announcement	read	2026-10-26 14:01:30.248488+08	\N	1
c7777459-3b55-470c-b4ba-2a923c687a38	erp:asset:read	erp:asset:read	Auto-registered from frontend usage: erp/config	erp:asset	read	2026-10-26 14:01:30.248488+08	\N	1
ed24d521-dc32-430a-babb-3b972d27ca5f	erp:audit:read	erp:audit:read	Auto-registered from frontend usage: erp/config	erp:audit	read	2026-10-26 14:01:30.248488+08	\N	1
394cc5b5-9357-4162-8fbf-18e50b88d473	erp:bank_account:read	erp:bank_account:read	Auto-registered from frontend usage: erp/config	erp:bank_account	read	2026-10-26 14:01:30.248488+08	\N	1
48fc858b-c74d-4efc-a305-e347e53cce48	erp:budget:read	erp:budget:read	Auto-registered from frontend usage: erp/config	erp:budget	read	2026-10-26 14:01:30.248488+08	\N	1
a93574bc-243f-4919-a136-3c5451b3099b	erp:customer:read	erp:customer:read	Auto-registered from frontend usage: erp/config	erp:customer	read	2026-10-26 14:01:30.248488+08	\N	1
593c95f0-77e3-403b-87fb-400e608c273e	erp:dashboard:read	erp:dashboard:read	Auto-registered from frontend usage: erp/config	erp:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
856e33cd-3581-41cb-8d9c-44cf0528ab0b	erp:database:read	erp:database:read	Auto-registered from frontend usage: erp/config	erp:database	read	2026-10-26 14:01:30.248488+08	\N	1
deb3a50e-c197-4ab9-ba23-611cc8014412	erp:dictionary:read	erp:dictionary:read	Auto-registered from frontend usage: erp/config	erp:dictionary	read	2026-10-26 14:01:30.248488+08	\N	1
9a658dea-e0dc-407e-b239-c322a0df7edc	erp:financial_analysis:read	erp:financial_analysis:read	Auto-registered from frontend usage: erp/config	erp:financial_analysis	read	2026-10-26 14:01:30.248488+08	\N	1
d680d4a1-0deb-4555-b977-40639d3390b0	erp:financial_statement:read	erp:financial_statement:read	Auto-registered from frontend usage: erp/config	erp:financial_statement	read	2026-10-26 14:01:30.248488+08	\N	1
2e5479a1-797c-4d3e-96f0-5b4ac46b9092	erp:general_ledger:read	erp:general_ledger:read	Auto-registered from frontend usage: erp/config	erp:general_ledger	read	2026-10-26 14:01:30.248488+08	\N	1
f1e9a303-fa8b-474b-8ce2-d33f78f79a4e	erp:inventory:read	erp:inventory:read	Auto-registered from frontend usage: erp/config	erp:inventory	read	2026-10-26 14:01:30.248488+08	\N	1
5187300b-a108-4506-b4fc-1a0e36bcc5f5	erp:material:read	erp:material:read	Auto-registered from frontend usage: erp/config	erp:material	read	2026-10-26 14:01:30.248488+08	\N	1
e430dd64-a3bf-4554-9d98-5e110b89d230	erp:meeting_room:read	erp:meeting_room:read	Auto-registered from frontend usage: erp/config	erp:meeting_room	read	2026-10-26 14:01:30.248488+08	\N	1
78bd3daa-4af1-44b8-8eac-0900ff7cb297	erp:office_supply:read	erp:office_supply:read	Auto-registered from frontend usage: erp/config	erp:office_supply	read	2026-10-26 14:01:30.248488+08	\N	1
f1e968e2-4935-43ee-b126-ae55ae053269	erp:purchase_order:read	erp:purchase_order:read	Auto-registered from frontend usage: erp/config	erp:purchase_order	read	2026-10-26 14:01:30.248488+08	\N	1
e0d6837e-b854-49a6-ba15-23e29619e81c	erp:receivable_payable:read	erp:receivable_payable:read	Auto-registered from frontend usage: erp/config	erp:receivable_payable	read	2026-10-26 14:01:30.248488+08	\N	1
1f093cf6-422a-41f4-afb7-0f506087c3b8	erp:sales_order:read	erp:sales_order:read	Auto-registered from frontend usage: erp/config	erp:sales_order	read	2026-10-26 14:01:30.248488+08	\N	1
661aa554-93d9-4580-a089-da3c188403aa	erp:supplier:read	erp:supplier:read	Auto-registered from frontend usage: erp/config	erp:supplier	read	2026-10-26 14:01:30.248488+08	\N	1
777c9417-2f89-43dd-9176-f6e577a8579d	erp:vehicle:read	erp:vehicle:read	Auto-registered from frontend usage: erp/config	erp:vehicle	read	2026-10-26 14:01:30.248488+08	\N	1
37ad2ca7-9188-4af8-9d97-3d459c9b4ec6	erp:vehicle_request:read	erp:vehicle_request:read	Auto-registered from frontend usage: erp/config	erp:vehicle_request	read	2026-10-26 14:01:30.248488+08	\N	1
e39ba050-965c-4cc1-a6d7-7be396bed06f	finance:dashboard:admin	finance:dashboard:admin	Auto-registered from frontend usage: finance/config	finance:dashboard	admin	2026-10-26 14:01:30.248488+08	\N	1
afc7b2a7-fd2d-446a-b3b2-b2869469a55a	finance:dashboard:write	finance:dashboard:write	Auto-registered from frontend usage: finance/route	finance:dashboard	write	2026-10-26 14:01:30.248488+08	\N	1
7b14c334-7fb1-4758-be33-6b9b02e6e5fa	finance:receivable_payable:read	finance:receivable_payable:read	Auto-registered from frontend usage: finance/config	finance:receivable_payable	read	2026-10-26 14:01:30.248488+08	\N	1
4e36af96-4097-445f-bae7-fd61c42e44fc	finance:settlement:approve	finance:settlement:approve	Auto-registered from frontend usage: finance/route	finance:settlement	approve	2026-10-26 14:01:30.248488+08	\N	1
a7f8f58a-d087-42cb-8ea6-61c3e9a07d16	gis:dashboard:read	gis:dashboard:read	Auto-registered from frontend usage: gis/config	gis:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
51b1fb64-a696-4a71-b474-c5fb55fd7d06	gis:fence:read	gis:fence:read	Auto-registered from frontend usage: gis/config	gis:fence	read	2026-10-26 14:01:30.248488+08	\N	1
aa3f9c3c-649a-4056-a5eb-2ddcdfa91d0e	gis:map:read	gis:map:read	Auto-registered from frontend usage: gis/config	gis:map	read	2026-10-26 14:01:30.248488+08	\N	1
c92527de-ae27-46ac-93db-1c8c96a4fb41	gis:tracking:read	gis:tracking:read	Auto-registered from frontend usage: gis/config	gis:tracking	read	2026-10-26 14:01:30.248488+08	\N	1
d5705b38-a0e0-4199-8654-e5e6393f7fa5	hrm:attendance_rule:read	hrm:attendance_rule:read	Auto-registered from frontend usage: hrm/config	hrm:attendance_rule	read	2026-10-26 14:01:30.248488+08	\N	1
0a805f49-09fc-47fa-8cad-aa56c648747f	hrm:module:read	hrm:module:read	Auto-registered from frontend usage: hrm/config	hrm:module	read	2026-10-26 14:01:30.248488+08	\N	1
04e45746-ec9e-4246-8c99-d307b9319a78	hrm:overview:read	hrm:overview:read	Auto-registered from frontend usage: hrm/config	hrm:overview	read	2026-10-26 14:01:30.248488+08	\N	1
f1b652f7-08ed-4f89-ba99-3c175c01f115	hrm:payroll_template:read	hrm:payroll_template:read	Auto-registered from frontend usage: hrm/config	hrm:payroll_template	read	2026-10-26 14:01:30.248488+08	\N	1
0da71896-a82d-4d46-9ba5-48dd04b4f80c	hrm:recruitment_flow:read	hrm:recruitment_flow:read	Auto-registered from frontend usage: hrm/config	hrm:recruitment_flow	read	2026-10-26 14:01:30.248488+08	\N	1
ce453dba-d80e-4771-8d33-59b8341ccd0b	hrm:training_plan:read	hrm:training_plan:read	Auto-registered from frontend usage: hrm/config	hrm:training_plan	read	2026-10-26 14:01:30.248488+08	\N	1
de7b1d04-0479-4b18-bf96-f328a70e3dc3	iam:dashboard:read	iam:dashboard:read	Auto-registered from frontend usage: iam/config	iam:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
46879577-3358-4986-8bfc-114f5574cdb5	iam:permission:read	iam:permission:read	Auto-registered from frontend usage: iam/config	iam:permission	read	2026-10-26 14:01:30.248488+08	\N	1
b8d03281-9a40-4b89-bbe0-d4c4dd6d4b4a	iam:role:read	iam:role:read	Auto-registered from frontend usage: iam/config	iam:role	read	2026-10-26 14:01:30.248488+08	\N	1
7b33f3bd-439a-4c29-bf7c-ef476b666594	iam:structure:read	iam:structure:read	Auto-registered from frontend usage: iam/config	iam:structure	read	2026-10-26 14:01:30.248488+08	\N	1
0b04c86a-f7db-4f0e-bdb2-0d6c7ed6f466	iam:user:read	iam:user:read	Auto-registered from frontend usage: iam/config	iam:user	read	2026-10-26 14:01:30.248488+08	\N	1
ea81d652-434b-48d9-80b0-631d85cf2903	im:dashboard:read	im:dashboard:read	Auto-registered from frontend usage: im/config	im:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
f026f048-5b29-4b4e-b95e-ff6eb7267137	im:mail:read	im:mail:read	Auto-registered from frontend usage: im/config	im:mail	read	2026-10-26 14:01:30.248488+08	\N	1
2f99d846-95d6-46d3-bed0-c7ebb9ab0d92	integration:connection:read	integration:connection:read	Auto-registered from frontend usage: integration/config	integration:connection	read	2026-10-26 14:01:30.248488+08	\N	1
6e924747-5f61-400a-96f2-d39678c53ebe	integration:dashboard:admin	integration:dashboard:admin	Auto-registered from frontend usage: integration/config	integration:dashboard	admin	2026-10-26 14:01:30.248488+08	\N	1
37652085-c739-4340-981d-06672288e823	integration:dashboard:read	integration:dashboard:read	Auto-registered from frontend usage: integration/config	integration:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
b30a10d4-dd01-4e0a-a5ad-a1ce9d5245f7	integration:erp:read	integration:erp:read	Auto-registered from frontend usage: integration/config	integration:erp	read	2026-10-26 14:01:30.248488+08	\N	1
a9798a7a-6374-4a5c-9439-2fb10e1adcbe	integration:event:read	integration:event:read	Auto-registered from frontend usage: integration/config	integration:event	read	2026-10-26 14:01:30.248488+08	\N	1
aca9a9ae-236e-43fe-b5f8-5987d4fcd819	integration:lims:read	integration:lims:read	Auto-registered from frontend usage: integration/config	integration:lims	read	2026-10-26 14:01:30.248488+08	\N	1
b5a0a8da-6a07-4b16-b206-6c502cea7ded	integration:mapping:read	integration:mapping:read	Auto-registered from frontend usage: integration/config	integration:mapping	read	2026-10-26 14:01:30.248488+08	\N	1
b03482a2-6040-4faf-97bc-a3f7644f0835	integration:mes:read	integration:mes:read	Auto-registered from frontend usage: integration/config	integration:mes	read	2026-10-26 14:01:30.248488+08	\N	1
9a84d23e-75e1-4e32-bb7d-41d4e6a0da62	integration:wms:read	integration:wms:read	Auto-registered from frontend usage: integration/config	integration:wms	read	2026-10-26 14:01:30.248488+08	\N	1
c70305b6-2202-43ac-9fef-dfc7a57b5045	lims:dashboard:write	lims:dashboard:write	Auto-registered from frontend usage: lims/route	lims:dashboard	write	2026-10-26 14:01:30.248488+08	\N	1
87532d47-b031-4c33-bd67-219740197598	lims:instrument:write	lims:instrument:write	Auto-registered from frontend usage: lims/config	lims:instrument	write	2026-10-26 14:01:30.248488+08	\N	1
c252a2a8-afc2-4317-8726-edfae372e93c	lims:sample:write	lims:sample:write	Auto-registered from frontend usage: lims/config	lims:sample	write	2026-10-26 14:01:30.248488+08	\N	1
7351a6a3-9e92-4d9c-9a42-0e0b6199c00c	mes:analytics:read	mes:analytics:read	Auto-registered from frontend usage: mes/config	mes:analytics	read	2026-10-26 14:01:30.248488+08	\N	1
c17c0424-eb48-4764-bd45-1c5ca21b0253	mes:anomaly_detection:read	mes:anomaly_detection:read	Auto-registered from frontend usage: mes/config	mes:anomaly_detection	read	2026-10-26 14:01:30.248488+08	\N	1
728fd516-3774-4f71-8990-d8a51606c38b	mes:aps_config:read	mes:aps_config:read	Auto-registered from frontend usage: mes/config	mes:aps_config	read	2026-10-26 14:01:30.248488+08	\N	1
1df026cf-4519-4d1c-b857-dcb6e700254e	mes:bom_version_policy:read	mes:bom_version_policy:read	Auto-registered from frontend usage: mes/config	mes:bom_version_policy	read	2026-10-26 14:01:30.248488+08	\N	1
7e053ee0-763f-4fed-ab98-428845d7c2e2	mes:energy_management:read	mes:energy_management:read	Auto-registered from frontend usage: mes/config	mes:energy_management	read	2026-10-26 14:01:30.248488+08	\N	1
b8b330a4-4b6c-4ee7-a59f-8947c086fe22	mes:equipment_threshold:read	mes:equipment_threshold:read	Auto-registered from frontend usage: mes/config	mes:equipment_threshold	read	2026-10-26 14:01:30.248488+08	\N	1
21adeaeb-4919-4a28-b04b-e661a6618016	mes:module:read	mes:module:read	Auto-registered from frontend usage: mes/config	mes:module	read	2026-10-26 14:01:30.248488+08	\N	1
c3b90803-dd05-492c-8474-905bd25fe7fa	mes:production_cost:read	mes:production_cost:read	Auto-registered from frontend usage: mes/config	mes:production_cost	read	2026-10-26 14:01:30.248488+08	\N	1
3f5a72bc-3e9d-438e-83dd-ed96959deeb8	mes:production_dashboard:read	mes:production_dashboard:read	Auto-registered from frontend usage: mes/config	mes:production_dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
c3f4aa2f-0cea-4705-877a-27e969a2682e	mes:quality_template:read	mes:quality_template:read	Auto-registered from frontend usage: mes/config	mes:quality_template	read	2026-10-26 14:01:30.248488+08	\N	1
af34ee5e-2497-4802-92f5-bdb634ae828b	mobile:approval:read	mobile:approval:read	Auto-registered from frontend usage: mobile/config	mobile:approval	read	2026-10-26 14:01:30.248488+08	\N	1
d219c621-f386-4fa5-b846-cc578167286f	mobile:attendance:read	mobile:attendance:read	Auto-registered from frontend usage: mobile/config	mobile:attendance	read	2026-10-26 14:01:30.248488+08	\N	1
d85e107d-4e6b-4e82-bdd4-873b80d8e10e	mobile:home:admin	mobile:home:admin	Auto-registered from frontend usage: mobile/config	mobile:home	admin	2026-10-26 14:01:30.248488+08	\N	1
d76b309b-70a1-4935-8fc3-5c609012c3e0	mobile:home:read	mobile:home:read	Auto-registered from frontend usage: mobile/config	mobile:home	read	2026-10-26 14:01:30.248488+08	\N	1
e4834c12-4554-4ff4-a8a4-c5a0c27a55c3	mobile:inventory:read	mobile:inventory:read	Auto-registered from frontend usage: mobile/config	mobile:inventory	read	2026-10-26 14:01:30.248488+08	\N	1
34afc0ee-4606-459b-94dc-9c7d379105c0	mobile:notification:read	mobile:notification:read	Auto-registered from frontend usage: mobile/config	mobile:notification	read	2026-10-26 14:01:30.248488+08	\N	1
5723409b-ff89-4020-bb52-da7ef3fdf75f	mobile:production:read	mobile:production:read	Auto-registered from frontend usage: mobile/config	mobile:production	read	2026-10-26 14:01:30.248488+08	\N	1
2812f17a-2a84-4dfd-8ecf-f70ee8cc6494	mobile:quality:read	mobile:quality:read	Auto-registered from frontend usage: mobile/config	mobile:quality	read	2026-10-26 14:01:30.248488+08	\N	1
045d017d-449e-4fff-9d12-f2dd4bbad635	mobile:scan:read	mobile:scan:read	Auto-registered from frontend usage: mobile/config	mobile:scan	read	2026-10-26 14:01:30.248488+08	\N	1
98622c44-196d-49a6-bd4a-4b7e4fd11666	mobile:task:read	mobile:task:read	Auto-registered from frontend usage: mobile/config	mobile:task	read	2026-10-26 14:01:30.248488+08	\N	1
e3d806db-5e8d-4127-a2b0-1615ff910e38	monitor:alert:read	monitor:alert:read	Auto-registered from frontend usage: monitor/config	monitor:alert	read	2026-10-26 14:01:30.248488+08	\N	1
58eff06e-93f7-46d3-8377-5367652a0008	monitor:dashboard:admin	monitor:dashboard:admin	Auto-registered from frontend usage: monitor/config	monitor:dashboard	admin	2026-10-26 14:01:30.248488+08	\N	1
2657cddf-c478-4725-a857-ef7908e8ddf7	monitor:dashboard:read	monitor:dashboard:read	Auto-registered from frontend usage: monitor/config	monitor:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
9738fddf-e331-47bc-a5d6-2f352731990f	monitor:log:read	monitor:log:read	Auto-registered from frontend usage: monitor/config	monitor:log	read	2026-10-26 14:01:30.248488+08	\N	1
956bd7e3-a78c-44cb-88f8-76be26c6b9e8	monitor:metric:read	monitor:metric:read	Auto-registered from frontend usage: monitor/config	monitor:metric	read	2026-10-26 14:01:30.248488+08	\N	1
8a8900fb-31ac-4cd9-9e93-eb8d73c39ebf	monitor:rule:read	monitor:rule:read	Auto-registered from frontend usage: monitor/config	monitor:rule	read	2026-10-26 14:01:30.248488+08	\N	1
6aa15c55-13d7-425b-b62e-b1f99966352a	notification:dashboard:read	notification:dashboard:read	Auto-registered from frontend usage: notification/config	notification:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
ef38764f-b3a6-4e33-9e99-7de82d4a3d69	oa:announcement:read	oa:announcement:read	Auto-registered from frontend usage: oa/config	oa:announcement	read	2026-10-26 14:01:30.248488+08	\N	1
7a57df41-e0ec-4cca-9c94-eba4ca06fe58	oa:dashboard:read	oa:dashboard:read	Auto-registered from frontend usage: oa/config	oa:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
44f3e8a4-1bcf-4be8-9eef-173178527b73	oa:document:read	oa:document:read	Auto-registered from frontend usage: oa/config	oa:document	read	2026-10-26 14:01:30.248488+08	\N	1
4edb86c9-2d44-482e-94ea-7d912fb462e4	oa:documents:read	oa:documents:read	Auto-registered from frontend usage: oa/config	oa:documents	read	2026-10-26 14:01:30.248488+08	\N	1
f5ff4dcc-ae10-4f4c-bd53-67793f8f37a6	oa:meeting:read	oa:meeting:read	Auto-registered from frontend usage: oa/config	oa:meeting	read	2026-10-26 14:01:30.248488+08	\N	1
9e69f6d6-1c4b-4b11-8db8-b2409cf29275	oa:vehicle:read	oa:vehicle:read	Auto-registered from frontend usage: oa/config	oa:vehicle	read	2026-10-26 14:01:30.248488+08	\N	1
6b51d9ea-d6f0-49aa-9815-ba2676e98129	pdm:bom_template:read	pdm:bom_template:read	Auto-registered from frontend usage: pdm/config	pdm:bom_template	read	2026-10-26 14:01:30.248488+08	\N	1
0c5349c3-e059-4134-a7f7-57e18ab03b86	pdm:category_rule:read	pdm:category_rule:read	Auto-registered from frontend usage: pdm/config	pdm:category_rule	read	2026-10-26 14:01:30.248488+08	\N	1
33745e62-1dbc-476d-a0a0-94bb7ad26eb2	pdm:change_template:read	pdm:change_template:read	Auto-registered from frontend usage: pdm/config	pdm:change_template	read	2026-10-26 14:01:30.248488+08	\N	1
966e484b-ed28-4914-813e-a71afc555abf	pdm:doc_approval_flow:read	pdm:doc_approval_flow:read	Auto-registered from frontend usage: pdm/config	pdm:doc_approval_flow	read	2026-10-26 14:01:30.248488+08	\N	1
01b86ba9-4d13-4f27-9dfa-eca19055186b	pdm:module:read	pdm:module:read	Auto-registered from frontend usage: pdm/config	pdm:module	read	2026-10-26 14:01:30.248488+08	\N	1
689a0f23-9ec2-4358-800b-72301791a8fb	plugin:dashboard:read	plugin:dashboard:read	Auto-registered from frontend usage: plugin/config	plugin:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
a40248d3-6777-43a0-9169-fec2d8c294fb	qms:analytics:read	qms:analytics:read	Auto-registered from frontend usage: qms/config	qms:analytics	read	2026-10-26 14:01:30.248488+08	\N	1
513baea3-28e8-4a36-a4e7-beb5c01b2961	rd:bug:read	rd:bug:read	Auto-registered from frontend usage: rd/config	rd:bug	read	2026-10-26 14:01:30.248488+08	\N	1
05b369b2-d6b1-438b-8b08-c937508faeaa	rd:build:read	rd:build:read	Auto-registered from frontend usage: rd/config	rd:build	read	2026-10-26 14:01:30.248488+08	\N	1
fa30e46d-ad83-41d7-8475-3e4d3408879e	rd:code:read	rd:code:read	Auto-registered from frontend usage: rd/config	rd:code	read	2026-10-26 14:01:30.248488+08	\N	1
7e3da5e3-4a15-4293-9666-17089f7221aa	rd:dashboard:read	rd:dashboard:read	Auto-registered from frontend usage: rd/config	rd:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
6a3efc4c-a6fe-4fb3-9ca1-c5b2cac3251e	rd:deploy:read	rd:deploy:read	Auto-registered from frontend usage: rd/config	rd:deploy	read	2026-10-26 14:01:30.248488+08	\N	1
c0bce82d-61ea-4d23-bf01-e315cf76e808	rd:doc:read	rd:doc:read	Auto-registered from frontend usage: rd/config	rd:doc	read	2026-10-26 14:01:30.248488+08	\N	1
d52b9fcc-2d1d-4284-8871-227ebdca2187	rd:experiment:read	rd:experiment:read	Auto-registered from frontend usage: rd/config	rd:experiment	read	2026-10-26 14:01:30.248488+08	\N	1
474cfbbb-563a-45c8-ac15-7d312796ab85	rd:formula:read	rd:formula:read	Auto-registered from frontend usage: rd/config	rd:formula	read	2026-10-26 14:01:30.248488+08	\N	1
e02eb922-9b43-4c78-9c95-23670fabb2db	rd:material:read	rd:material:read	Auto-registered from frontend usage: rd/config	rd:material	read	2026-10-26 14:01:30.248488+08	\N	1
72624182-b481-4779-a41e-b80fa310eb84	rd:milestone:read	rd:milestone:read	Auto-registered from frontend usage: rd/config	rd:milestone	read	2026-10-26 14:01:30.248488+08	\N	1
de37755f-72dd-412d-b342-3e1f3c46e62c	rd:overview:read	rd:overview:read	Auto-registered from frontend usage: rd/config	rd:overview	read	2026-10-26 14:01:30.248488+08	\N	1
9a090c49-615e-4189-81b7-c68f70588a9a	rd:project:read	rd:project:read	Auto-registered from frontend usage: rd/config	rd:project	read	2026-10-26 14:01:30.248488+08	\N	1
c3d67379-0ead-42e1-9357-f7bd07869a9e	rd:release:read	rd:release:read	Auto-registered from frontend usage: rd/config	rd:release	read	2026-10-26 14:01:30.248488+08	\N	1
6def9c3f-c2ac-47e6-be24-270767260bf1	rd:report:read	rd:report:read	Auto-registered from frontend usage: rd/config	rd:report	read	2026-10-26 14:01:30.248488+08	\N	1
2f8f36f4-6755-47ce-8139-f82e5bf6ab1c	rd:review:read	rd:review:read	Auto-registered from frontend usage: rd/config	rd:review	read	2026-10-26 14:01:30.248488+08	\N	1
97ed19db-ed13-4a4f-8d35-205f3d5f1930	rd:settings:read	rd:settings:read	Auto-registered from frontend usage: rd/config	rd:settings	read	2026-10-26 14:01:30.248488+08	\N	1
7d5c46e7-f828-474f-8c29-7253136d9871	rd:test:read	rd:test:read	Auto-registered from frontend usage: rd/config	rd:test	read	2026-10-26 14:01:30.248488+08	\N	1
7d5ab67c-98b5-42c0-8d14-9e7bf4451014	report:builder:write	report:builder:write	Auto-registered from frontend usage: report/config	report:builder	write	2026-10-26 14:01:30.248488+08	\N	1
4e074869-df5c-4e30-a7cc-dfb680eff1fa	report:design:write	report:design:write	Auto-registered from frontend usage: report/config	report:design	write	2026-10-26 14:01:30.248488+08	\N	1
271b281b-57c5-4631-b187-4a46a85bea6f	scm:module:read	scm:module:read	Auto-registered from frontend usage: scm/config	scm:module	read	2026-10-26 14:01:30.248488+08	\N	1
49c143fd-ba12-4367-99e9-fb9b93d16eeb	scm:overview:read	scm:overview:read	Auto-registered from frontend usage: scm/config	scm:overview	read	2026-10-26 14:01:30.248488+08	\N	1
df22e30d-4ed2-452f-99bc-cbcdb74e9b82	scm:purchase_threshold:read	scm:purchase_threshold:read	Auto-registered from frontend usage: scm/config	scm:purchase_threshold	read	2026-10-26 14:01:30.248488+08	\N	1
ffac61a9-9ac7-4611-b41b-e90cdee8d0db	scm:quota_template:read	scm:quota_template:read	Auto-registered from frontend usage: scm/config	scm:quota_template	read	2026-10-26 14:01:30.248488+08	\N	1
a549fb54-39e3-453c-a2b8-be2bf032d196	scm:sourcing_strategy:read	scm:sourcing_strategy:read	Auto-registered from frontend usage: scm/config	scm:sourcing_strategy	read	2026-10-26 14:01:30.248488+08	\N	1
45818393-8aa1-4b91-911a-1afe36d94aa2	scm:supplier_tier:read	scm:supplier_tier:read	Auto-registered from frontend usage: scm/config	scm:supplier_tier	read	2026-10-26 14:01:30.248488+08	\N	1
24523602-d294-4ee4-9682-b4b7033e2dbb	system:center:read	system:center:read	Auto-registered from frontend usage: ticket/config	system:center	read	2026-10-26 14:01:30.248488+08	\N	1
da04ad6f-b312-4c12-8157-d5a88925c692	system:read	system:read	Auto-registered from frontend usage: admin/config	system	read	2026-10-26 14:01:30.248488+08	\N	1
dbcfb335-82a9-4afa-859c-71ba034cd839	ticket:dashboard:read	ticket:dashboard:read	Auto-registered from frontend usage: ticket/config	ticket:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
fe78983e-74c6-4ebe-86a3-00711dc74175	tms:analytics:read	tms:analytics:read	Auto-registered from frontend usage: tms/config	tms:analytics	read	2026-10-26 14:01:30.248488+08	\N	1
84e88b19-7ea3-4c83-9ae4-b595f42642dc	tms:carrier:read	tms:carrier:read	Auto-registered from frontend usage: tms/config	tms:carrier	read	2026-10-26 14:01:30.248488+08	\N	1
a859a422-34b9-4702-a7a4-7d06900efaa8	tms:dashboard:read	tms:dashboard:read	Auto-registered from frontend usage: tms/config	tms:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
69d56e64-d6ce-4cf5-b5a8-b5168cc94d74	tms:driver:read	tms:driver:read	Auto-registered from frontend usage: tms/config	tms:driver	read	2026-10-26 14:01:30.248488+08	\N	1
e74d0bed-1796-45ec-b90b-139bfe02c93a	tms:module:read	tms:module:read	Auto-registered from frontend usage: tms/config	tms:module	read	2026-10-26 14:01:30.248488+08	\N	1
a5f015f2-7036-4da0-94f6-a54894f3806f	tms:route:read	tms:route:read	Auto-registered from frontend usage: tms/config	tms:route	read	2026-10-26 14:01:30.248488+08	\N	1
13383d43-a6de-4bce-845f-1d53202c5bc1	tms:shipment:read	tms:shipment:read	Auto-registered from frontend usage: tms/config	tms:shipment	read	2026-10-26 14:01:30.248488+08	\N	1
3e3d4592-c126-4c82-a08e-d792d44cb6c5	tms:vehicle:read	tms:vehicle:read	Auto-registered from frontend usage: tms/config	tms:vehicle	read	2026-10-26 14:01:30.248488+08	\N	1
abb116ab-5ae5-4b95-a76d-69f84ef60531	wms:abc:read	wms:abc:read	Auto-registered from frontend usage: wms/config	wms:abc	read	2026-10-26 14:01:30.248488+08	\N	1
b3dada46-c85a-4345-9057-569872c36b76	wms:fifo_policy:read	wms:fifo_policy:read	Auto-registered from frontend usage: wms/config	wms:fifo_policy	read	2026-10-26 14:01:30.248488+08	\N	1
6e9ef4e4-091a-49f5-ae34-4516d56fa2d1	wms:flow:read	wms:flow:read	Auto-registered from frontend usage: wms/config	wms:flow	read	2026-10-26 14:01:30.248488+08	\N	1
faf3128f-d3c6-406e-9dc3-416d8479a9b5	wms:fulfillment:read	wms:fulfillment:read	Auto-registered from frontend usage: wms/config	wms:fulfillment	read	2026-10-26 14:01:30.248488+08	\N	1
e84e5bc7-1c4c-4d85-9361-fc23da95ceef	wms:inventory_cycle:read	wms:inventory_cycle:read	Auto-registered from frontend usage: wms/config	wms:inventory_cycle	read	2026-10-26 14:01:30.248488+08	\N	1
2be70162-7bb7-4d80-a364-b0b21811f6c8	wms:inventory_threshold:read	wms:inventory_threshold:read	Auto-registered from frontend usage: wms/config	wms:inventory_threshold	read	2026-10-26 14:01:30.248488+08	\N	1
3b9dd14c-fb41-4491-9fc8-2d8576a5c67c	wms:location_rule:read	wms:location_rule:read	Auto-registered from frontend usage: wms/config	wms:location_rule	read	2026-10-26 14:01:30.248488+08	\N	1
7bf2906e-3608-4419-ba2d-9260dccff270	wms:locutil:read	wms:locutil:read	Auto-registered from frontend usage: wms/config	wms:locutil	read	2026-10-26 14:01:30.248488+08	\N	1
34cc6d5a-d1c6-469c-bde7-6258b4a4c5da	wms:module:read	wms:module:read	Auto-registered from frontend usage: wms/config	wms:module	read	2026-10-26 14:01:30.248488+08	\N	1
4eca7254-449f-4597-9df7-57ffec2c690e	wms:pareto:read	wms:pareto:read	Auto-registered from frontend usage: wms/config	wms:pareto	read	2026-10-26 14:01:30.248488+08	\N	1
cde99b41-2a0d-4f1d-9c45-975637fdae58	wms:turnover:read	wms:turnover:read	Auto-registered from frontend usage: wms/config	wms:turnover	read	2026-10-26 14:01:30.248488+08	\N	1
f9856349-66de-44e4-a348-5726f6ad4677	workflow:approval:read	workflow:approval:read	Auto-registered from frontend usage: workflow/config	workflow:approval	read	2026-10-26 14:01:30.248488+08	\N	1
d9dab3aa-56f9-4842-b667-8d7b5c9d3e02	workflow:dashboard:admin	workflow:dashboard:admin	Auto-registered from frontend usage: workflow/config	workflow:dashboard	admin	2026-10-26 14:01:30.248488+08	\N	1
3b5154ff-87a4-4e59-9c15-d25e04d341a1	workflow:dashboard:read	workflow:dashboard:read	Auto-registered from frontend usage: workflow/config	workflow:dashboard	read	2026-10-26 14:01:30.248488+08	\N	1
208b623d-85b5-4324-91e4-03b4417b7f26	workflow:definition:read	workflow:definition:read	Auto-registered from frontend usage: workflow/config	workflow:definition	read	2026-10-26 14:01:30.248488+08	\N	1
029132a4-e1dc-4e69-8b6c-b0a4455a00e4	workflow:definition:write	workflow:definition:write	Auto-registered from frontend usage: workflow/config	workflow:definition	write	2026-10-26 14:01:30.248488+08	\N	1
7e292473-2e5d-4234-acf5-b8683e7ff051	workflow:instance:read	workflow:instance:read	Auto-registered from frontend usage: workflow/config	workflow:instance	read	2026-10-26 14:01:30.248488+08	\N	1
b95075d7-960e-4ab8-adf1-d51900deecc5	workflow:monitor:read	workflow:monitor:read	Auto-registered from frontend usage: workflow/config	workflow:monitor	read	2026-10-26 14:01:30.248488+08	\N	1
7be81cc9-8dd7-4ae5-a8e7-5e094c69b4c6	workflow:notification:read	workflow:notification:read	Auto-registered from frontend usage: workflow/config	workflow:notification	read	2026-10-26 14:01:30.248488+08	\N	1
bedb1e39-a308-490a-ba73-c1507ea219c2	workflow:statistics:read	workflow:statistics:read	Auto-registered from frontend usage: workflow/config	workflow:statistics	read	2026-10-26 14:01:30.248488+08	\N	1
ac116969-5777-401b-a20b-35cd1fe1926c	workflow:template:read	workflow:template:read	Auto-registered from frontend usage: workflow/config	workflow:template	read	2026-10-26 14:01:30.248488+08	\N	1
48491ed0-e0d3-40dc-b7d9-8534da3dee34	analytics:admin	数据分析-管理	P0-4 补缺：analytics 服务 require_permission 挂载的模块级管理伞码	analytics	admin	2026-10-26 14:03:20.508666+08	\N	\N
f09cf8d8-23da-4e62-ae56-61b34820de41	communication:admin	通信通知-管理	P0-4 补缺：communication 服务 require_permission 挂载的模块级管理伞码	communication	admin	2026-10-26 14:03:20.508666+08	\N	\N
cef380ce-868f-4537-bc5f-73b390a16702	lims:admin	实验室管理-管理	P0-4 补缺：lims 服务 require_permission 挂载的模块级管理伞码	lims	admin	2026-10-26 14:03:20.508666+08	\N	\N
33cfc4df-dd51-4c7b-8b1a-7c15cbb4f7d2	master-data:admin	主数据-管理	P0-4 补缺：master-data 服务 require_permission 挂载的模块级管理伞码	master-data	admin	2026-10-26 14:03:20.508666+08	\N	\N
88263dff-3e83-4a75-9d01-e692c0404a3d	mobile:admin	移动端-管理	P0-4 补缺：mobile 服务 require_permission 挂载的模块级管理伞码	mobile	admin	2026-10-26 14:03:20.508666+08	\N	\N
174bffd6-fb89-463f-b9d4-8db402c2b49e	monitor:admin	监控-管理	P0-4 补缺：monitor 服务 require_permission 挂载的模块级管理伞码	monitor	admin	2026-10-26 14:03:20.508666+08	\N	\N
ca683d73-c1d0-4e45-b118-f52a71957d1b	pdm:admin	产品数据-管理	P0-4 补缺：pdm 服务 require_permission 挂载的模块级管理伞码	pdm	admin	2026-10-26 14:03:20.508666+08	\N	\N
73e091f3-f678-4548-b7d5-370e4b486655	portal:admin	门户-管理	P0-4 补缺：portal 服务 require_permission 挂载的模块级管理伞码	portal	admin	2026-10-26 14:03:20.508666+08	\N	\N
ba586539-40b3-413d-9660-7ded48037558	rd:admin	研发-管理	P0-4 补缺：rd 服务 require_permission 挂载的模块级管理伞码	rd	admin	2026-10-26 14:03:20.508666+08	\N	\N
79f587ea-df95-4b8a-9831-b0de393ce226	search:admin	搜索-管理	P0-4 补缺：search 服务 require_permission 挂载的模块级管理伞码	search	admin	2026-10-26 14:03:20.508666+08	\N	\N
8a29f576-8679-4d49-ad38-f49468049c59	srm:admin	供应商关系-管理	P0-4 补缺：srm 服务 require_permission 挂载的模块级管理伞码	srm	admin	2026-10-26 14:03:20.508666+08	\N	\N
f052a97d-8f42-4ef2-bd0a-8c1647fcd040	ticket:admin	工单-管理	P0-4 补缺：ticket 服务 require_permission 挂载的模块级管理伞码	ticket	admin	2026-10-26 14:03:20.508666+08	\N	\N
303229b7-b86f-4df8-a02d-d197b4cf0484	tms:admin	运输管理-管理	P0-4 补缺：tms 服务 require_permission 挂载的模块级管理伞码	tms	admin	2026-10-26 14:03:20.508666+08	\N	\N
d88b01a1-09dc-42ad-93c7-3fa95604d0ea	subscription:admin	订阅-管理	P0-4 补缺：subscription 模块 require_permission 挂载的管理伞码	subscription	admin	2026-10-26 14:03:20.508666+08	\N	\N
2525c5c8-f8ef-4704-95de-d8cdffeec983	subscription:read	订阅-只读	P0-4 补缺：subscription 模块 GET /current require_permission 挂载的只读码	subscription	read	2026-10-26 14:03:20.508666+08	\N	\N
7bed07ca-f474-45bd-a838-f7d17efbd062	system:write	系统设置-写入	P0-4 补缺：system 配置/特性开关/DLQ 回放 require_permission("system:write")	system	write	2026-10-26 14:03:20.508666+08	\N	\N
111b391a-e8a2-40f7-bac8-c28831bd5aca	admin:iam:write	身份管理-写入	P0-4 补缺：routes/iam.rs 写路由组 require_permission("admin:iam:write")	admin:iam	write	2026-10-26 14:03:20.508666+08	\N	\N
7fac1587-989e-4b31-b155-40e4e28b907f	admin:iam:delete	身份管理-删除	P0-4 补缺：routes/iam.rs 删除路由组 require_permission("admin:iam:delete")	admin:iam	delete	2026-10-26 14:03:20.508666+08	\N	\N
6c4d2ee1-e121-42d8-b891-8d47b78fdcab	admin:iam:tenant:write	租户管理-写入	P0-4 补缺：routes/master.rs require_permission("admin:iam:tenant:write")	admin:iam:tenant	write	2026-10-26 14:03:20.508666+08	\N	\N
cad31fa1-e7a0-41c6-9324-5ea00aa5dd21	iam:tenant:read	租户-只读	P0-4 补缺：routes/master.rs require_permission("iam:tenant:read")	iam:tenant	read	2026-10-26 14:03:20.508666+08	\N	\N
f354b4ef-f930-425c-9f35-8bcef8ba8d4d	ai:dashboard:write	AI 仪表盘-写入	P0-4 补缺：ai_knowledge require_permission("ai:dashboard:write")（read/admin 已存在）	ai:dashboard	write	2026-10-26 14:03:20.508666+08	\N	\N
82af438f-777f-4c00-bdf1-53b2aeb289e7	finance:settlement:read	结算中心-只读	P0-4 补缺：settlement_center require_permission("finance:settlement:read")	finance:settlement	read	2026-10-26 14:03:20.508666+08	\N	\N
81d3c9b2-9279-4528-a61b-e4c39522c5c4	finance:settlement:write	结算中心-写入	P0-4 补缺：settlement_center require_permission("finance:settlement:write")（approve 已存在）	finance:settlement	write	2026-10-26 14:03:20.508666+08	\N	\N
ca97156c-f828-42cb-a36c-a83bd2147360	erp:read	企业管理-读取	ERP 模块读取总码（§4 权限体系 v1.91）	erp	read	2026-10-26 14:03:20.555078+08	\N	\N
219e704e-8616-401b-aabd-dd48d3b13a6b	erp:write	企业管理-写入	ERP 模块写入总码（§4 权限体系 v1.91）	erp	write	2026-10-26 14:03:20.555078+08	\N	\N
bdd7cae3-e309-480d-ba9b-1602e16dac04	scm:write	供应链-写入	SCM 模块写入总码（§4 权限体系 v1.91）	scm	write	2026-10-26 14:03:20.555078+08	\N	\N
fd02f665-2a01-4829-ba04-ca3e7c9de378	wms:write	仓储管理-写入	WMS 模块写入总码（§4 权限体系 v1.91）	wms	write	2026-10-26 14:03:20.555078+08	\N	\N
533497ec-ea83-4f69-b0c7-fba74522f8a7	qms:write	质量管理-写入	QMS 模块写入总码（§4 权限体系 v1.91）	qms	write	2026-10-26 14:03:20.555078+08	\N	\N
4f264a35-cfb0-4c52-889a-44590b9b8b8d	master-data:read	主数据-读取	主数据模块读取总码（§4 五环节 v1.97）	master-data	read	2026-10-26 14:03:20.558662+08	\N	\N
369009df-a3d0-4990-b50d-f0b02af5efd8	master-data:write	主数据-写入	主数据模块写入总码（§4 五环节 v1.97）	master-data	write	2026-10-26 14:03:20.558662+08	\N	\N
cd89f3d7-6ec0-45e7-871f-e62097d491ea	ai:admin	AI助手-管理	AI 模块管理伞码；Copilot FAQ 知识库管理（core.ai_faqs admin CRUD：list/create/update/delete，迁移 20261024000015）	ai	admin	2026-10-26 14:03:20.593971+08	\N	\N
6e1bf8bc-ccbe-42d5-b42f-7e6adb53c9c8	iam:read	身份管理-只读	身份管理	iam	read	2026-10-26 14:19:13.789347+08	\N	\N
5a956f8b-aba8-4fe0-b9be-d45f3ba78d5b	iam:write	身份管理-写入	身份管理	iam	write	2026-10-26 14:19:13.789778+08	\N	\N
f681e57a-aadf-4711-9985-f3b90ad82a4a	iam:delete	身份管理-删除	身份管理	iam	delete	2026-10-26 14:19:13.7903+08	\N	\N
b7b53077-3762-4f75-ba3e-687aabacb536	iam:admin	身份管理-管理	身份管理	iam	admin	2026-10-26 14:19:13.790463+08	\N	\N
74b1a124-6b6f-4890-8e6f-b3a082a6780e	hrm:write	人力资源-写入	人力资源	hrm	write	2026-10-26 14:19:13.79072+08	\N	\N
8ca422bd-ed92-41be-aa9d-16476426670c	hrm:delete	人力资源-删除	人力资源	hrm	delete	2026-10-26 14:19:13.790865+08	\N	\N
303bc82d-6530-4fdb-bcf1-37ae7c1fea83	hrm:admin	人力资源-管理	人力资源	hrm	admin	2026-10-26 14:19:13.791165+08	\N	\N
411369a8-67dd-4438-88d9-d41a9c4dc5a6	erp:delete	企业资源-删除	企业资源	erp	delete	2026-10-26 14:19:13.791521+08	\N	\N
c58700ee-14a5-476c-9a26-7a2e66421ce1	erp:admin	企业资源-管理	企业资源	erp	admin	2026-10-26 14:19:13.791668+08	\N	\N
1130f587-8c1d-4f85-822c-119811a2aa61	pm:write	项目管理-写入	项目管理	pm	write	2026-10-26 14:19:13.791923+08	\N	\N
f66cc7ec-ecc9-43a7-8f65-6008e4aedb9c	pm:delete	项目管理-删除	项目管理	pm	delete	2026-10-26 14:19:13.79206+08	\N	\N
ed034c2b-a527-450e-9268-7d4288a83a50	pm:admin	项目管理-管理	项目管理	pm	admin	2026-10-26 14:19:13.792197+08	\N	\N
50e08104-c1ee-4229-8429-5101c39b6d79	rs:read	研发管理-只读	研发管理	rs	read	2026-10-26 14:19:13.792319+08	\N	\N
8a011a76-e565-459f-ad16-d1e1b261828b	rs:write	研发管理-写入	研发管理	rs	write	2026-10-26 14:19:13.79245+08	\N	\N
a78504eb-35d5-4358-b063-384b5167979b	rs:delete	研发管理-删除	研发管理	rs	delete	2026-10-26 14:19:13.792765+08	\N	\N
c9ca55ff-7006-4bb7-9b7c-c16d1de70405	rs:admin	研发管理-管理	研发管理	rs	admin	2026-10-26 14:19:13.792904+08	\N	\N
267b9164-aab8-41cf-945f-62354f22bd10	scm:delete	供应链-删除	供应链	scm	delete	2026-10-26 14:19:13.793237+08	\N	\N
fc7d6711-4c02-4d31-bb23-196ee3ece6cd	scm:admin	供应链-管理	供应链	scm	admin	2026-10-26 14:19:13.793372+08	\N	\N
a3e49191-3e1a-4d06-bfa8-eb947a17df9b	crm:write	客户关系-写入	客户关系	crm	write	2026-10-26 14:19:13.793585+08	\N	\N
1a27610c-e0c6-4fee-9d25-892bb6f4fe10	crm:delete	客户关系-删除	客户关系	crm	delete	2026-10-26 14:19:13.793959+08	\N	\N
2f229a24-baf5-451f-931d-17429fdbcf10	crm:admin	客户关系-管理	客户关系	crm	admin	2026-10-26 14:19:13.794199+08	\N	\N
519985a7-4bd4-42f6-8035-c89821184328	ai:read	AI助手-只读	AI助手	ai	read	2026-10-26 14:19:13.794357+08	\N	\N
120c66ee-5a1a-45a0-ae9b-0b6616f2b600	ai:write	AI助手-写入	AI助手	ai	write	2026-10-26 14:19:13.794607+08	\N	\N
65376494-25fb-4a72-b02f-0ee381a9988f	ai:delete	AI助手-删除	AI助手	ai	delete	2026-10-26 14:19:13.794753+08	\N	\N
cef7d121-7d38-4acd-90f7-596f2eef92f7	gis:read	地理信息-只读	地理信息	gis	read	2026-10-26 14:19:13.794994+08	\N	\N
8417286d-3d11-452e-a91f-d5fad61b3b16	gis:write	地理信息-写入	地理信息	gis	write	2026-10-26 14:19:13.795129+08	\N	\N
5984b868-a5eb-4bba-b6c7-37782c657feb	gis:delete	地理信息-删除	地理信息	gis	delete	2026-10-26 14:19:13.795254+08	\N	\N
dc29e592-994c-411c-b42b-b186a5191a17	gis:admin	地理信息-管理	地理信息	gis	admin	2026-10-26 14:19:13.795425+08	\N	\N
57e887ca-e62a-4666-9395-1af50fc20e33	qms:delete	质量管理-删除	质量管理	qms	delete	2026-10-26 14:19:13.795736+08	\N	\N
dc14fba4-c712-4136-8e76-89b7d7cf9018	qms:admin	质量管理-管理	质量管理	qms	admin	2026-10-26 14:19:13.795899+08	\N	\N
43f9c115-2ea5-4023-9c8b-46a0e414afb0	ehs:write	环境健康安全-写入	环境健康安全	ehs	write	2026-10-26 14:19:13.796126+08	\N	\N
4bbb1f4d-3ab1-4f59-a1d7-a41e613e4433	ehs:delete	环境健康安全-删除	环境健康安全	ehs	delete	2026-10-26 14:19:13.796253+08	\N	\N
fd807b2f-5696-4918-a37c-1f8b279f8539	ehs:admin	环境健康安全-管理	环境健康安全	ehs	admin	2026-10-26 14:19:13.796371+08	\N	\N
13effc0b-81d0-48b4-9c9a-ed2995bd9130	mes:write	制造执行-写入	制造执行	mes	write	2026-10-26 14:19:13.796588+08	\N	\N
21dee80e-d8dc-4409-9372-c60dc1e71cd8	mes:delete	制造执行-删除	制造执行	mes	delete	2026-10-26 14:19:13.796722+08	\N	\N
8143ea35-c604-499b-b7a0-a8b8f2e8fd28	mes:admin	制造执行-管理	制造执行	mes	admin	2026-10-26 14:19:13.796855+08	\N	\N
6623accd-dab6-4e3b-a046-d6d94043c3a1	wms:delete	仓储管理-删除	仓储管理	wms	delete	2026-10-26 14:19:13.797163+08	\N	\N
13658522-b5dc-48f2-8f2a-d7e0debfb19e	wms:admin	仓储管理-管理	仓储管理	wms	admin	2026-10-26 14:19:13.797452+08	\N	\N
a051effe-6568-4ffb-8d80-fa27f462fa19	workflow:read	工作流-只读	工作流	workflow	read	2026-10-26 14:19:13.797609+08	\N	\N
8d4dff04-6c17-4796-a7ad-ca556089b374	workflow:write	工作流-写入	工作流	workflow	write	2026-10-26 14:19:13.797723+08	\N	\N
9e1e67ee-c0bf-4709-853f-b4c202d4ae01	workflow:delete	工作流-删除	工作流	workflow	delete	2026-10-26 14:19:13.797866+08	\N	\N
a9fcb6aa-3ce8-48ab-a0ea-4c2dd49ffb17	workflow:approve	工作流-审批	工作流	workflow	approve	2026-10-26 14:19:13.79798+08	\N	\N
8469a43b-4c95-44aa-b423-f2c21ea7ac63	workflow:admin	工作流-管理	工作流	workflow	admin	2026-10-26 14:19:13.798094+08	\N	\N
4a8e0cee-b789-4605-8078-f7f833f62e93	doc:read	文档管理-只读	文档管理	doc	read	2026-10-26 14:19:13.798222+08	\N	\N
c4c06366-0137-4e4d-bbc4-9c36159df749	doc:write	文档管理-写入	文档管理	doc	write	2026-10-26 14:19:13.798359+08	\N	\N
2f2e9393-e4d5-4036-9552-403e66a084c3	doc:delete	文档管理-删除	文档管理	doc	delete	2026-10-26 14:19:13.798486+08	\N	\N
aaa2e854-33fd-4132-80d9-11c2e17b5d66	file:read	文件服务-只读	文件服务	file	read	2026-10-26 14:19:13.798958+08	\N	\N
1a04ca8f-5d4b-48d0-892e-2f4434a2d723	file:delete	文件服务-删除	文件服务	file	delete	2026-10-26 14:19:13.799373+08	\N	\N
656641f6-f723-48ff-b4b0-0d72cac5e1fc	notification:read	通知服务-只读	通知服务	notification	read	2026-10-26 14:19:13.799922+08	\N	\N
d9ed67f8-d69e-441c-840f-752a6b40bd26	notification:delete	通知服务-删除	通知服务	notification	delete	2026-10-26 14:19:13.800259+08	\N	\N
685bb93d-1594-4d64-8df3-9ab74108b1dc	im:read	即时通讯-只读	即时通讯	im	read	2026-10-26 14:19:13.800558+08	\N	\N
d49d9373-ed87-4bbe-8379-fbf55d658832	im:delete	即时通讯-删除	即时通讯	im	delete	2026-10-26 14:19:13.800812+08	\N	\N
ddae4668-cc94-4612-b91d-f91c2060a0bb	integration:read	系统集成-只读	系统集成	integration	read	2026-10-26 14:19:13.801079+08	\N	\N
24490971-d0b7-492c-a1c5-942be9b7449b	integration:delete	系统集成-删除	系统集成	integration	delete	2026-10-26 14:19:13.801328+08	\N	\N
677c220d-4713-432b-bf46-a97babadd713	system:settings	系统设置	系统设置	system	settings	2026-10-26 14:19:13.801593+08	\N	\N
bb620e33-0136-465b-afdc-37448d768113	system:audit	审计日志	系统设置	system	audit	2026-10-26 14:19:13.801866+08	\N	\N
580b846c-b358-4288-9b61-b6519fff624e	system:plugin	插件管理	系统设置	system	plugin	2026-10-26 14:19:13.80214+08	\N	\N
addc323d-1303-4ac8-8708-e0b0264a7469	doc:admin	文档管理-管理	文档管理	doc	admin	2026-10-26 14:19:13.798785+08	\N	\N
016536cd-2144-48fb-a420-18802aff14a4	file:write	文件服务-写入	文件服务	file	write	2026-10-26 14:19:13.7991+08	\N	\N
df9c7ab0-a0fa-4cf1-b8bd-f46f19121074	file:admin	文件服务-管理	文件服务	file	admin	2026-10-26 14:19:13.799709+08	\N	\N
bf5c9fd8-7a08-4e1a-8838-bc69ea3271d9	notification:write	通知服务-写入	通知服务	notification	write	2026-10-26 14:19:13.8001+08	\N	\N
67003d99-42ed-4b8c-8999-d85802d0e285	notification:admin	通知服务-管理	通知服务	notification	admin	2026-10-26 14:19:13.800404+08	\N	\N
794fb74b-0a23-40de-b6f7-13d88c33f55d	im:write	即时通讯-写入	即时通讯	im	write	2026-10-26 14:19:13.800689+08	\N	\N
62f418c6-0e01-4f6c-995e-a97da16c11a1	im:admin	即时通讯-管理	即时通讯	im	admin	2026-10-26 14:19:13.80094+08	\N	\N
2b19edd6-4c3a-4921-bbc3-24ef8204d606	integration:write	系统集成-写入	系统集成	integration	write	2026-10-26 14:19:13.801204+08	\N	\N
03ec1cea-a4f6-4c00-bb0b-17adaaed14fa	integration:admin	系统集成-管理	系统集成	integration	admin	2026-10-26 14:19:13.801455+08	\N	\N
6b8b687a-b96a-4b8b-b9b9-4df42e0d7b84	system:monitor	系统监控	系统设置	system	monitor	2026-10-26 14:19:13.801733+08	\N	\N
a0994733-323a-4b99-8cb7-32666d016bac	system:dictionary	字典管理	系统设置	system	dictionary	2026-10-26 14:19:13.802004+08	\N	\N
683fce65-e197-4d10-aee6-b01fb1d3a013	system:migration	数据迁移	系统设置	system	migration	2026-10-26 14:19:13.802405+08	\N	\N
bef93b63-4a75-4f51-bcc8-a8d343e25fb7	wms:wavepick:read	wms:wavepick:read	Auto-registered from frontend usage: batch4 perm unification	wms:wavepick	read	2026-11-02 12:26:59.803314+08	\N	1
6e961f90-c999-4b5e-93cc-2755f2023f10	lims:test-method:read	lims:test-method:read	Auto-registered from frontend usage: batch4 perm unification	lims:test-method	read	2026-11-02 12:26:59.803314+08	\N	1
a6d65792-cb28-468b-b386-f507bfa6bc8e	qms:action:read	qms:action:read	Auto-registered from frontend usage: batch4 perm unification	qms:action	read	2026-11-02 12:26:59.803314+08	\N	1
f07328f9-3da8-4478-b74b-70837fdf5abc	bi:dashboard:write	bi:dashboard:write	Auto-registered from frontend usage: batch4 perm unification	bi:dashboard	write	2026-11-02 12:26:59.803314+08	\N	1
b684edce-c6f8-426a-a929-b5d367d7e8d7	master-data:ai_governance:read	master-data:ai_governance:read	Auto-registered from frontend usage: batch4 perm unification	master-data:ai_governance	read	2026-11-02 12:26:59.803314+08	\N	1
773bdd1d-9a8f-4a83-affb-3c692d6540bd	crm:contract:read	crm:contract:read	Auto-registered from frontend usage: batch4 perm unification	crm:contract	read	2026-11-02 12:26:59.803314+08	\N	1
4c96467d-f886-443a-a248-affa29a7ae19	wms:stocktake:read	wms:stocktake:read	Auto-registered from frontend usage: batch4 perm unification	wms:stocktake	read	2026-11-02 12:26:59.803314+08	\N	1
69001fe1-feb3-4341-b0d9-a268b6da6904	master-data:disaster:read	master-data:disaster:read	Auto-registered from frontend usage: batch4 perm unification	master-data:disaster	read	2026-11-02 12:26:59.803314+08	\N	1
ccbd664f-eb54-4a49-8ded-e7448645ea03	admin:iam:dashboard:approve	admin:iam:dashboard:approve	Auto-registered from frontend usage: batch4 perm unification	admin:iam	dashboard	2026-11-02 12:26:59.803314+08	\N	1
44e82e3b-4314-406a-b3e1-cc47742da6ee	rd:experiment:write	rd:experiment:write	Auto-registered from frontend usage: batch4 perm unification	rd:experiment	write	2026-11-02 12:26:59.803314+08	\N	1
3bf67112-270f-493b-b325-fff48a5a9229	master-data:quality:read	master-data:quality:read	Auto-registered from frontend usage: batch4 perm unification	master-data:quality	read	2026-11-02 12:26:59.803314+08	\N	1
ba3440b7-756f-4128-8968-5dbc298d3a2a	pm:dashboard:write	pm:dashboard:write	Auto-registered from frontend usage: batch4 perm unification	pm:dashboard	write	2026-11-02 12:26:59.803314+08	\N	1
9ba3cac0-e113-43d1-8197-bc6e62c006a5	admin:dashboard:write	admin:dashboard:write	Auto-registered from frontend usage: batch4 perm unification	admin:dashboard	write	2026-11-02 12:26:59.803314+08	\N	1
392abfe3-e8ce-44f9-ba6d-41000d49e3bb	master-data:lineage:read	master-data:lineage:read	Auto-registered from frontend usage: batch4 perm unification	master-data:lineage	read	2026-11-02 12:26:59.803314+08	\N	1
9dc03863-f1bb-4302-b822-a3c8f831b46a	master-data:data-asset:read	master-data:data-asset:read	Auto-registered from frontend usage: batch4 perm unification	master-data:data-asset	read	2026-11-02 12:26:59.803314+08	\N	1
1c4d487a-c653-4b38-9434-1d1d8db8d74c	rd:project:write	rd:project:write	Auto-registered from frontend usage: batch4 perm unification	rd:project	write	2026-11-02 12:26:59.803314+08	\N	1
a39ae325-13b9-4f48-bc54-fd126d4712bd	finance:period:read	finance:period:read	Auto-registered from frontend usage: batch4 perm unification	finance:period	read	2026-11-02 12:26:59.803314+08	\N	1
6bf564bd-2b91-49d6-9365-9b2045af8e8f	rd:dashboard:write	rd:dashboard:write	Auto-registered from frontend usage: batch4 perm unification	rd:dashboard	write	2026-11-02 12:26:59.803314+08	\N	1
addafe6b-3ed0-4203-a3d1-f49786234367	crm:dashboard:write	crm:dashboard:write	Auto-registered from frontend usage: batch4 perm unification	crm:dashboard	write	2026-11-02 12:26:59.803314+08	\N	1
c64d3bae-9693-48f3-bb39-1ac8cb1f3fdd	master-data:governance:read	master-data:governance:read	Auto-registered from frontend usage: batch4 perm unification	master-data:governance	read	2026-11-02 12:26:59.803314+08	\N	1
44be5995-4db6-4193-baee-dec6a9b50e91	finance:currency:read	finance:currency:read	Auto-registered from frontend usage: batch4 perm unification	finance:currency	read	2026-11-02 12:26:59.803314+08	\N	1
e4ace075-d690-42e8-8430-01a8fa9e13ae	master-data:schema:read	master-data:schema:read	Auto-registered from frontend usage: batch4 perm unification	master-data:schema	read	2026-11-02 12:26:59.803314+08	\N	1
94d7636a-6ba0-4498-8dc1-59aebc2010b5	master-data:versioning:read	master-data:versioning:read	Auto-registered from frontend usage: batch4 perm unification	master-data:versioning	read	2026-11-02 12:26:59.803314+08	\N	1
54006b5a-2ac1-4ab7-95c5-36f43d5d6d7c	workflow:dashboard:write	workflow:dashboard:write	Auto-registered from frontend usage: batch4 perm unification	workflow:dashboard	write	2026-11-02 12:26:59.803314+08	\N	1
66981a07-954c-4511-83d2-bd6a3e377c39	crm:dashboard:update	crm:dashboard:update	Auto-registered from frontend usage: batch4 perm unification	crm:dashboard	update	2026-11-02 12:26:59.803314+08	\N	1
92e9fbf3-c400-4030-b9a4-34c29ebb67dd	wms:movement:read	wms:movement:read	Auto-registered from frontend usage: batch4 perm unification	wms:movement	read	2026-11-02 12:26:59.803314+08	\N	1
7fa6c91c-708d-434a-b58a-2579eaaa6856	mes:workshop:read	mes:workshop:read	Auto-registered from frontend usage: batch4 perm unification	mes:workshop	read	2026-11-02 12:26:59.803314+08	\N	1
91af3b5b-d16e-4054-9b31-6b278102778b	rd:formula:write	rd:formula:write	Auto-registered from frontend usage: batch4 perm unification	rd:formula	write	2026-11-02 12:26:59.803314+08	\N	1
0b4ab5d7-8212-45a3-8659-c1c868e2a8df	master-data:knowledge:read	master-data:knowledge:read	Auto-registered from frontend usage: batch4 perm unification	master-data:knowledge	read	2026-11-02 12:26:59.803314+08	\N	1
e78e5683-e3db-4078-b32c-b6982f436bac	pdm:drawing:read	pdm:drawing:read	Auto-registered from frontend usage: batch4 perm unification	pdm:drawing	read	2026-11-02 12:26:59.803314+08	\N	1
20885dd4-e791-40ea-9f9b-4571dd959b83	master-data:commercial:read	master-data:commercial:read	Auto-registered from frontend usage: batch4 perm unification	master-data:commercial	read	2026-11-02 12:26:59.803314+08	\N	1
cab775e1-2108-4a21-84f6-c37c4e25c4b5	erp:sales:read	erp:sales:read	Auto-registered from frontend usage: batch4 perm unification	erp:sales	read	2026-11-02 12:26:59.803314+08	\N	1
cf1f7b7e-1ea7-4b2b-bfa3-9c26945c42ba	report:dashboard:write	report:dashboard:write	Auto-registered from frontend usage: batch4 perm unification	report:dashboard	write	2026-11-02 12:26:59.803314+08	\N	1
6946f7c8-a78c-415f-9bde-fe58f20aae42	master-data:semantic:read	master-data:semantic:read	Auto-registered from frontend usage: batch4 perm unification	master-data:semantic	read	2026-11-02 12:26:59.803314+08	\N	1
24c83555-0fac-4aa3-b263-263da1a66725	admin:tenant:write	admin:tenant:write	Auto-registered from frontend usage: batch4 perm unification	admin:tenant	write	2026-11-02 12:26:59.803314+08	\N	1
9033c0cf-765e-47fc-9be4-aefa68be48e3	plugin:marketplace:read	plugin:marketplace:read	Auto-registered from frontend usage: batch4 perm unification	plugin:marketplace	read	2026-11-02 12:26:59.803314+08	\N	1
e31feacc-4a30-490f-b173-375ead7b2fb3	erp:vehicle:update	vehicle编辑	[batch16] ERP - vehicle编辑	erp:vehicle	update	2026-11-06 20:35:21.825245+08	\N	1
ae101460-ef29-4327-8c77-18b4bd109320	rd:bug:create	bug新增	[batch16] RD 研发 - bug新增	rd:bug	create	2026-11-06 20:35:21.825245+08	\N	1
6b9f15b6-1c00-429f-9c54-e192facd59e6	tms:driver:delete	driver删除	[batch16] TMS 运输 - driver删除	tms:driver	delete	2026-11-06 20:35:21.825245+08	\N	1
573ad993-551d-443d-954a-20e44767d5cf	rd:doc:create	doc新增	[batch16] RD 研发 - doc新增	rd:doc	create	2026-11-06 20:35:21.825245+08	\N	1
bbc4dcd7-99c0-4148-8915-e06fc6cbc833	erp:announcement:create	announcement新增	[batch16] ERP - announcement新增	erp:announcement	create	2026-11-06 20:35:21.825245+08	\N	1
eabbf099-1303-4434-9bca-17652fa22ca1	erp:budget:update	budget编辑	[batch16] ERP - budget编辑	erp:budget	update	2026-11-06 20:35:21.825245+08	\N	1
d3d4b9d3-2140-4d76-bb32-bce236bd4f0c	tms:vehicle:update	vehicle编辑	[batch16] TMS 运输 - vehicle编辑	tms:vehicle	update	2026-11-06 20:35:21.825245+08	\N	1
23c6f3bd-dd65-42b3-b57a-c485c70558c2	rd:formula:delete	formula删除	[batch16] RD 研发 - formula删除	rd:formula	delete	2026-11-06 20:35:21.825245+08	\N	1
6f79971c-b230-4a92-ba13-69188108309c	rd:project:update	project编辑	[batch16] RD 研发 - project编辑	rd:project	update	2026-11-06 20:35:21.825245+08	\N	1
47923145-e4be-4350-ac74-8cfe890533b2	rd:experiment:create	experiment新增	[batch16] RD 研发 - experiment新增	rd:experiment	create	2026-11-06 20:35:21.825245+08	\N	1
24632f0f-ce01-4386-bb3e-2eccb5bcc920	aps:capacity:create	capacity新增	[batch16] APS 高级计划排程 - capacity新增	aps:capacity	create	2026-11-06 20:35:21.825245+08	\N	1
67dfc397-b2c5-49cd-b7da-8d8bbc5122eb	erp:inventory:delete	inventory删除	[batch16] ERP - inventory删除	erp:inventory	delete	2026-11-06 20:35:21.825245+08	\N	1
1f322e19-0ff3-483a-81dd-304c23282b27	monitor:log:delete	log删除	[batch16] 监控 - log删除	monitor:log	delete	2026-11-06 20:35:21.825245+08	\N	1
15390d64-f3c0-4127-b008-ea0f1a2bf690	rd:bug:update	bug编辑	[batch16] RD 研发 - bug编辑	rd:bug	update	2026-11-06 20:35:21.825245+08	\N	1
c41cfb69-6e61-41da-8650-81d3dc4e1fa8	doc:document:delete	document删除	[batch16] 文档 - document删除	doc:document	delete	2026-11-06 20:35:21.825245+08	\N	1
223105d7-e76b-43ae-9524-0e02ac5a1ac3	erp:vehicle:delete	vehicle删除	[batch16] ERP - vehicle删除	erp:vehicle	delete	2026-11-06 20:35:21.825245+08	\N	1
6d7a4023-6492-45a1-a8b4-9682b52126d8	tms:route:delete	route删除	[batch16] TMS 运输 - route删除	tms:route	delete	2026-11-06 20:35:21.825245+08	\N	1
9c8c8b63-6f88-461a-a172-dee0ac14cc51	erp:material:delete	material删除	[batch16] ERP - material删除	erp:material	delete	2026-11-06 20:35:21.825245+08	\N	1
8d98bc0f-fa2a-40c9-9116-a41b7b08c66c	rd:doc:delete	doc删除	[batch16] RD 研发 - doc删除	rd:doc	delete	2026-11-06 20:35:21.825245+08	\N	1
88c6b68f-0c2b-4a68-8a48-8672efe0a013	workflow:instance:update	instance编辑	[batch16] 工作流 - instance编辑	workflow:instance	update	2026-11-06 20:35:21.825245+08	\N	1
1cc56556-0648-462c-9730-5686c0264e66	rd:formula:update	formula编辑	[batch16] RD 研发 - formula编辑	rd:formula	update	2026-11-06 20:35:21.825245+08	\N	1
3ecb2792-67fa-4734-977d-c3b40ad5d05a	integration:event:create	event新增	[batch16] 集成 - event新增	integration:event	create	2026-11-06 20:35:21.825245+08	\N	1
64dafa81-85df-4596-9061-9557146b7382	tms:carrier:create	carrier新增	[batch16] TMS 运输 - carrier新增	tms:carrier	create	2026-11-06 20:35:21.825245+08	\N	1
86a4d0cc-cfe9-406a-b80c-e1850f264de3	bi:data_source:update	data_source编辑	[batch16] BI 商业智能 - data_source编辑	bi:data_source	update	2026-11-06 20:35:21.825245+08	\N	1
fbd5c768-6d9f-434c-9ff4-d98bb80277ab	workflow:instance:create	instance新增	[batch16] 工作流 - instance新增	workflow:instance	create	2026-11-06 20:35:21.825245+08	\N	1
a7e632e5-fe29-48f8-aea5-67fbb2ef7369	rd:test:create	test新增	[batch16] RD 研发 - test新增	rd:test	create	2026-11-06 20:35:21.825245+08	\N	1
8a68c851-2105-4a36-bf67-0eab421b8582	erp:supplier:update	supplier编辑	[batch16] ERP - supplier编辑	erp:supplier	update	2026-11-06 20:35:21.825245+08	\N	1
fd2560b3-6d67-4522-a0c9-4f5edd895df5	integration:event:delete	event删除	[batch16] 集成 - event删除	integration:event	delete	2026-11-06 20:35:21.825245+08	\N	1
39f25038-14d2-4123-824e-fc20fe6b22f4	aps:forecast:delete	forecast删除	[batch16] APS 高级计划排程 - forecast删除	aps:forecast	delete	2026-11-06 20:35:21.825245+08	\N	1
5b118c55-e72b-4dbb-9aba-8e716e08a6f7	integration:connection:create	connection新增	[batch16] 集成 - connection新增	integration:connection	create	2026-11-06 20:35:21.825245+08	\N	1
4f18c700-e7a0-4547-9232-a280ed8c2df4	erp:budget:delete	budget删除	[batch16] ERP - budget删除	erp:budget	delete	2026-11-06 20:35:21.825245+08	\N	1
647b6492-8b28-4989-85bb-df7223821bcc	erp:meeting_room:delete	meeting_room删除	[batch16] ERP - meeting_room删除	erp:meeting_room	delete	2026-11-06 20:35:21.825245+08	\N	1
f3f0981e-26e0-4cf8-b9a7-c7b4d8615cac	iam:permission:create	permission新增	[batch16] IAM 身份权限 - permission新增	iam:permission	create	2026-11-06 20:35:21.825245+08	\N	1
9cafeb0e-5448-4467-a62d-742dad34cedb	rd:material:delete	material删除	[batch16] RD 研发 - material删除	rd:material	delete	2026-11-06 20:35:21.825245+08	\N	1
b370ebcc-ce80-4528-9bfa-2b387bf6ccee	rd:project:delete	project删除	[batch16] RD 研发 - project删除	rd:project	delete	2026-11-06 20:35:21.825245+08	\N	1
bf5c2543-ddf2-4d0f-a7e7-cba992ec3127	rd:test:delete	test删除	[batch16] RD 研发 - test删除	rd:test	delete	2026-11-06 20:35:21.825245+08	\N	1
f3fbad59-003b-4dfa-80d5-f73a0f708650	integration:mapping:create	mapping新增	[batch16] 集成 - mapping新增	integration:mapping	create	2026-11-06 20:35:21.825245+08	\N	1
383db516-cca1-486f-9bd1-7550cea844a7	erp:purchase_order:delete	purchase_order删除	[batch16] ERP - purchase_order删除	erp:purchase_order	delete	2026-11-06 20:35:21.825245+08	\N	1
707b0352-6829-4f0e-8609-66b370c98a17	erp:supplier:create	supplier新增	[batch16] ERP - supplier新增	erp:supplier	create	2026-11-06 20:35:21.825245+08	\N	1
b7d05e03-a561-4d67-8168-90ab4b1cf04a	tms:route:update	route编辑	[batch16] TMS 运输 - route编辑	tms:route	update	2026-11-06 20:35:21.825245+08	\N	1
0d971516-47cf-4ca6-ad37-2a8724a2dfe8	rd:deploy:update	deploy编辑	[batch16] RD 研发 - deploy编辑	rd:deploy	update	2026-11-06 20:35:21.825245+08	\N	1
48a2f41e-3f20-4db9-a75c-2b71971b1f2c	erp:customer:delete	customer删除	[batch16] ERP - customer删除	erp:customer	delete	2026-11-06 20:35:21.825245+08	\N	1
89f6fe83-a512-4c96-b256-f4f956ea0c08	erp:vehicle_request:update	vehicle_request编辑	[batch16] ERP - vehicle_request编辑	erp:vehicle_request	update	2026-11-06 20:35:21.825245+08	\N	1
3dea6223-95dc-4a61-9d64-d2551968590d	bi:data_source:delete	data_source删除	[batch16] BI 商业智能 - data_source删除	bi:data_source	delete	2026-11-06 20:35:21.825245+08	\N	1
30a979bd-a09e-482e-b51d-8bd2763e449a	rd:material:create	material新增	[batch16] RD 研发 - material新增	rd:material	create	2026-11-06 20:35:21.825245+08	\N	1
f0f59552-3199-4dac-8b6d-6df0b32e6a9e	erp:purchase_order:update	purchase_order编辑	[batch16] ERP - purchase_order编辑	erp:purchase_order	update	2026-11-06 20:35:21.825245+08	\N	1
23e5b4e4-352d-4dab-86cf-df4a1ccd8380	monitor:alert:delete	alert删除	[batch16] 监控 - alert删除	monitor:alert	delete	2026-11-06 20:35:21.825245+08	\N	1
7f0ddcea-c48e-4747-af7c-ad08517c247e	doc:document:update	document编辑	[batch16] 文档 - document编辑	doc:document	update	2026-11-06 20:35:21.825245+08	\N	1
0d77d1a7-c5f6-48b1-94dd-e987285c537d	integration:connection:update	connection编辑	[batch16] 集成 - connection编辑	integration:connection	update	2026-11-06 20:35:21.825245+08	\N	1
bbfc592d-499c-4483-81da-a0c5ae958063	erp:meeting_room:create	meeting_room新增	[batch16] ERP - meeting_room新增	erp:meeting_room	create	2026-11-06 20:35:21.825245+08	\N	1
4b583b8b-e9d8-4b4d-ae49-402c1b14e569	erp:office_supply:update	office_supply编辑	[batch16] ERP - office_supply编辑	erp:office_supply	update	2026-11-06 20:35:21.825245+08	\N	1
5fd9bd0b-5d5d-4bc1-a245-6d8f2217215e	aps:schedule:update	schedule编辑	[batch16] APS 高级计划排程 - schedule编辑	aps:schedule	update	2026-11-06 20:35:21.825245+08	\N	1
69505033-3cc0-40db-a954-afe956723692	erp:material:update	material编辑	[batch16] ERP - material编辑	erp:material	update	2026-11-06 20:35:21.825245+08	\N	1
1875af07-a87a-4ddf-907c-de3e12d9b434	erp:bank_account:delete	bank_account删除	[batch16] ERP - bank_account删除	erp:bank_account	delete	2026-11-06 20:35:21.825245+08	\N	1
46763a8a-2429-4510-a825-2f8a0b7c9908	qms:action:update	action编辑	[batch16] QMS 质量 - action编辑	qms:action	update	2026-11-06 20:35:21.825245+08	\N	1
36bd5c40-d171-42b1-affc-0516465d37ee	erp:purchase_order:create	purchase_order新增	[batch16] ERP - purchase_order新增	erp:purchase_order	create	2026-11-06 20:35:21.825245+08	\N	1
b7923c83-4e59-47ea-b96d-3a67d3ac923e	erp:bank_account:create	bank_account新增	[batch16] ERP - bank_account新增	erp:bank_account	create	2026-11-06 20:35:21.825245+08	\N	1
70b849cd-5cc4-419c-b14d-5c256dfe7a7d	erp:vehicle:create	vehicle新增	[batch16] ERP - vehicle新增	erp:vehicle	create	2026-11-06 20:35:21.825245+08	\N	1
7badcf9a-2b27-4b35-9c17-6aaddd9eed8f	rd:experiment:delete	experiment删除	[batch16] RD 研发 - experiment删除	rd:experiment	delete	2026-11-06 20:35:21.825245+08	\N	1
c96f19df-d062-408d-b5fd-05fa72cb465e	bi:report:delete	report删除	[batch16] BI 商业智能 - report删除	bi:report	delete	2026-11-06 20:35:21.825245+08	\N	1
ddeaad4e-f897-4226-8364-46af22178aab	erp:announcement:delete	announcement删除	[batch16] ERP - announcement删除	erp:announcement	delete	2026-11-06 20:35:21.825245+08	\N	1
42010586-8561-4fce-83a4-863e637a6d9c	erp:asset:update	asset编辑	[batch16] ERP - asset编辑	erp:asset	update	2026-11-06 20:35:21.825245+08	\N	1
33952e42-e03d-4b19-91a2-0d953fe6e1ba	rd:build:delete	build删除	[batch16] RD 研发 - build删除	rd:build	delete	2026-11-06 20:35:21.825245+08	\N	1
4f917038-fc9c-4c90-94e1-250df4bda5b2	aps:schedule:create	schedule新增	[batch16] APS 高级计划排程 - schedule新增	aps:schedule	create	2026-11-06 20:35:21.825245+08	\N	1
42391cd3-3470-4978-8e11-1bac98bcd0a8	rd:build:update	build编辑	[batch16] RD 研发 - build编辑	rd:build	update	2026-11-06 20:35:21.825245+08	\N	1
6c391362-1d63-4cc4-94d0-96bfac0849a8	rd:doc:update	doc编辑	[batch16] RD 研发 - doc编辑	rd:doc	update	2026-11-06 20:35:21.825245+08	\N	1
8147ed19-ba6b-4bb1-9d49-160bb1e9e2b3	erp:customer:update	customer编辑	[batch16] ERP - customer编辑	erp:customer	update	2026-11-06 20:35:21.825245+08	\N	1
4b0fcf9f-0416-419a-9861-b20b5c7153e3	rd:formula:create	formula新增	[batch16] RD 研发 - formula新增	rd:formula	create	2026-11-06 20:35:21.825245+08	\N	1
dc7c3a71-fb90-426b-9703-4404f58c01b0	tms:driver:update	driver编辑	[batch16] TMS 运输 - driver编辑	tms:driver	update	2026-11-06 20:35:21.825245+08	\N	1
2acd48cb-6ffa-4391-b1a0-b66876f6505a	monitor:alert:create	alert新增	[batch16] 监控 - alert新增	monitor:alert	create	2026-11-06 20:35:21.825245+08	\N	1
3b664429-cf41-4e2e-9e7a-46c95110c6b4	rd:milestone:update	milestone编辑	[batch16] RD 研发 - milestone编辑	rd:milestone	update	2026-11-06 20:35:21.825245+08	\N	1
279f9b8a-1713-4a00-bda1-34fb4cb27226	qms:action:create	action新增	[batch16] QMS 质量 - action新增	qms:action	create	2026-11-06 20:35:21.825245+08	\N	1
88de0358-05fe-4c33-9bb6-300af3cfd748	rd:build:create	build新增	[batch16] RD 研发 - build新增	rd:build	create	2026-11-06 20:35:21.825245+08	\N	1
c9f6d494-47b2-4f83-940a-5929c78a3401	iam:permission:delete	permission删除	[batch16] IAM 身份权限 - permission删除	iam:permission	delete	2026-11-06 20:35:21.825245+08	\N	1
84313eef-a7a7-4306-8afd-9c95673a1d8f	erp:announcement:update	announcement编辑	[batch16] ERP - announcement编辑	erp:announcement	update	2026-11-06 20:35:21.825245+08	\N	1
4e3e7c14-1079-42cf-ac2d-b66f531cfbed	aps:forecast:update	forecast编辑	[batch16] APS 高级计划排程 - forecast编辑	aps:forecast	update	2026-11-06 20:35:21.825245+08	\N	1
e3f9406e-9950-4ecc-b6a5-fb64b10fc677	mobile:notification:create	notification新增	[batch16] 移动端 - notification新增	mobile:notification	create	2026-11-06 20:35:21.825245+08	\N	1
54a55151-62a6-4c46-bc65-7a863f051b10	mobile:notification:update	notification编辑	[batch16] 移动端 - notification编辑	mobile:notification	update	2026-11-06 20:35:21.825245+08	\N	1
551f3b81-7e55-409a-af7e-4f51816229a8	doc:document:create	document新增	[batch16] 文档 - document新增	doc:document	create	2026-11-06 20:35:21.825245+08	\N	1
9fc43219-edbe-4479-8a2b-8462bb644459	aps:schedule:delete	schedule删除	[batch16] APS 高级计划排程 - schedule删除	aps:schedule	delete	2026-11-06 20:35:21.825245+08	\N	1
611bd0d1-e9ae-471f-bc7e-ffa776ee3fcd	erp:asset:delete	asset删除	[batch16] ERP - asset删除	erp:asset	delete	2026-11-06 20:35:21.825245+08	\N	1
4e77bd6b-8e16-4a7d-9875-4afb75c46c8b	erp:vehicle_request:delete	vehicle_request删除	[batch16] ERP - vehicle_request删除	erp:vehicle_request	delete	2026-11-06 20:35:21.825245+08	\N	1
1eb391c1-df41-4f4e-b8f6-489bf1c65626	rd:deploy:delete	deploy删除	[batch16] RD 研发 - deploy删除	rd:deploy	delete	2026-11-06 20:35:21.825245+08	\N	1
4416b533-7f9b-4c0a-8fa8-daf56d407a90	erp:meeting_room:update	meeting_room编辑	[batch16] ERP - meeting_room编辑	erp:meeting_room	update	2026-11-06 20:35:21.825245+08	\N	1
a870eef4-cb4a-4870-b330-1d78f1956c05	tms:route:create	route新增	[batch16] TMS 运输 - route新增	tms:route	create	2026-11-06 20:35:21.825245+08	\N	1
2c624c3e-59d9-43e2-92a0-994ba529f25a	workflow:monitor:create	monitor新增	[batch16] 工作流 - monitor新增	workflow:monitor	create	2026-11-06 20:35:21.825245+08	\N	1
48c9ec2c-ba09-4f1e-980f-6434bc4bf30a	rd:material:update	material编辑	[batch16] RD 研发 - material编辑	rd:material	update	2026-11-06 20:35:21.825245+08	\N	1
4a5a6390-6630-47ad-b5b1-ae88037dc587	aps:capacity:delete	capacity删除	[batch16] APS 高级计划排程 - capacity删除	aps:capacity	delete	2026-11-06 20:35:21.825245+08	\N	1
3202458d-597a-4eb8-b9a2-29b98aa25b6f	integration:event:update	event编辑	[batch16] 集成 - event编辑	integration:event	update	2026-11-06 20:35:21.825245+08	\N	1
7d8ddd4e-5c73-4ae8-ab3c-215d18a0d4fd	erp:material:create	material新增	[batch16] ERP - material新增	erp:material	create	2026-11-06 20:35:21.825245+08	\N	1
3fcd6460-d9f1-4496-804f-14597ff7620e	rd:milestone:create	milestone新增	[batch16] RD 研发 - milestone新增	rd:milestone	create	2026-11-06 20:35:21.825245+08	\N	1
f20b3f2e-e6cf-4e69-ada7-ecf24915ec1e	rd:milestone:delete	milestone删除	[batch16] RD 研发 - milestone删除	rd:milestone	delete	2026-11-06 20:35:21.825245+08	\N	1
b78d6f35-ee92-4831-8283-3fc3eed905d1	aps:forecast:create	forecast新增	[batch16] APS 高级计划排程 - forecast新增	aps:forecast	create	2026-11-06 20:35:21.825245+08	\N	1
bd24cb01-82c5-4851-9f7c-d1319dd2effd	erp:asset:create	asset新增	[batch16] ERP - asset新增	erp:asset	create	2026-11-06 20:35:21.825245+08	\N	1
379fd337-d4f4-4bb0-ad9a-dbe2268edacb	bi:report:update	report编辑	[batch16] BI 商业智能 - report编辑	bi:report	update	2026-11-06 20:35:21.825245+08	\N	1
f36b5cdc-cca4-4115-9960-a4a8abe5c98d	rd:project:create	project新增	[batch16] RD 研发 - project新增	rd:project	create	2026-11-06 20:35:21.825245+08	\N	1
ea8b4868-7bbf-44ac-9e79-977f9c5fb5b9	erp:inventory:update	inventory编辑	[batch16] ERP - inventory编辑	erp:inventory	update	2026-11-06 20:35:21.825245+08	\N	1
91c54e37-7f62-4822-b194-28ca25f55062	erp:office_supply:create	office_supply新增	[batch16] ERP - office_supply新增	erp:office_supply	create	2026-11-06 20:35:21.825245+08	\N	1
a2a9ea71-0d6d-4452-aa83-aa55f41f20c3	rd:deploy:create	deploy新增	[batch16] RD 研发 - deploy新增	rd:deploy	create	2026-11-06 20:35:21.825245+08	\N	1
8e9531b5-f234-468f-9a25-5a8860701109	workflow:instance:delete	instance删除	[batch16] 工作流 - instance删除	workflow:instance	delete	2026-11-06 20:35:21.825245+08	\N	1
ec93d7ff-3b95-46de-b8a9-512cdd524861	erp:inventory:create	inventory新增	[batch16] ERP - inventory新增	erp:inventory	create	2026-11-06 20:35:21.825245+08	\N	1
04f106e2-2975-42ac-a144-b62a0ae5738d	bi:data_source:create	data_source新增	[batch16] BI 商业智能 - data_source新增	bi:data_source	create	2026-11-06 20:35:21.825245+08	\N	1
aad113ba-a3ae-43cb-adec-2afe23519e7d	erp:office_supply:delete	office_supply删除	[batch16] ERP - office_supply删除	erp:office_supply	delete	2026-11-06 20:35:21.825245+08	\N	1
bd3288fb-2960-4be5-8776-dbc02cb9ccb1	rd:experiment:update	experiment编辑	[batch16] RD 研发 - experiment编辑	rd:experiment	update	2026-11-06 20:35:21.825245+08	\N	1
188474c2-34e8-48ae-87ab-fcab345b9b95	erp:customer:create	customer新增	[batch16] ERP - customer新增	erp:customer	create	2026-11-06 20:35:21.825245+08	\N	1
907d69eb-3590-45be-a28e-b391718c6e56	tms:carrier:update	carrier编辑	[batch16] TMS 运输 - carrier编辑	tms:carrier	update	2026-11-06 20:35:21.825245+08	\N	1
33b6bfb7-6c9f-4e4d-a756-4f1e86587c6d	integration:mapping:delete	mapping删除	[batch16] 集成 - mapping删除	integration:mapping	delete	2026-11-06 20:35:21.825245+08	\N	1
fee722ff-21b6-4f65-87fe-d67e7e9d2576	tms:driver:create	driver新增	[batch16] TMS 运输 - driver新增	tms:driver	create	2026-11-06 20:35:21.825245+08	\N	1
72c5e40b-997c-4c27-a210-7397eef54dd9	integration:mapping:update	mapping编辑	[batch16] 集成 - mapping编辑	integration:mapping	update	2026-11-06 20:35:21.825245+08	\N	1
07f1cbac-a321-4bc0-b6f4-fdf803fd57ae	erp:vehicle_request:create	vehicle_request新增	[batch16] ERP - vehicle_request新增	erp:vehicle_request	create	2026-11-06 20:35:21.825245+08	\N	1
2e94c2e2-6bf2-4c3a-a839-77f4e17e3070	qms:action:delete	action删除	[batch16] QMS 质量 - action删除	qms:action	delete	2026-11-06 20:35:21.825245+08	\N	1
37e6e627-364c-4bd5-af58-6bdca0b8a847	integration:connection:delete	connection删除	[batch16] 集成 - connection删除	integration:connection	delete	2026-11-06 20:35:21.825245+08	\N	1
5d267a0a-ce17-4427-a02e-0356cac077e0	erp:supplier:delete	supplier删除	[batch16] ERP - supplier删除	erp:supplier	delete	2026-11-06 20:35:21.825245+08	\N	1
81286431-6731-45e0-b874-4cf1bc1caf0c	rd:settings:create	settings新增	[batch16] RD 研发 - settings新增	rd:settings	create	2026-11-06 20:35:21.825245+08	\N	1
24eec346-bc4b-4387-ac07-b3f6c7e596ee	workflow:monitor:delete	monitor删除	[batch16] 工作流 - monitor删除	workflow:monitor	delete	2026-11-06 20:35:21.825245+08	\N	1
ceaf56cc-bbbd-459f-9cbb-3a1e77b0bde3	mobile:notification:delete	notification删除	[batch16] 移动端 - notification删除	mobile:notification	delete	2026-11-06 20:35:21.825245+08	\N	1
7ee28d50-4c03-4515-9d91-3eb71d4eba53	rd:bug:delete	bug删除	[batch16] RD 研发 - bug删除	rd:bug	delete	2026-11-06 20:35:21.825245+08	\N	1
ee6c4fa8-797b-4ed0-b6d2-7f78d2fada20	tms:carrier:delete	carrier删除	[batch16] TMS 运输 - carrier删除	tms:carrier	delete	2026-11-06 20:35:21.825245+08	\N	1
fd8abaf6-06db-48a0-bdf6-0fe14b845ad0	iam:permission:update	permission编辑	[batch16] IAM 身份权限 - permission编辑	iam:permission	update	2026-11-06 20:35:21.825245+08	\N	1
a8a2fe5f-7a86-4010-878f-187b93a22442	aps:capacity:update	capacity编辑	[batch16] APS 高级计划排程 - capacity编辑	aps:capacity	update	2026-11-06 20:35:21.825245+08	\N	1
4f349891-bdbf-4941-941d-08b4c40ab301	rd:test:update	test编辑	[batch16] RD 研发 - test编辑	rd:test	update	2026-11-06 20:35:21.825245+08	\N	1
3edb7f96-bb99-464d-a749-7676069ef2c6	tms:vehicle:delete	vehicle删除	[batch16] TMS 运输 - vehicle删除	tms:vehicle	delete	2026-11-06 20:35:21.825245+08	\N	1
e052f81b-07dd-46fd-ac73-f638214ecba1	rd:settings:delete	settings删除	[batch16] RD 研发 - settings删除	rd:settings	delete	2026-11-06 20:35:21.825245+08	\N	1
cffc5f46-3d00-442f-b5ba-4dc70f767179	monitor:alert:update	alert编辑	[batch16] 监控 - alert编辑	monitor:alert	update	2026-11-06 20:35:21.825245+08	\N	1
136000bf-b5c3-426c-80aa-bed1cd06b968	erp:budget:create	budget新增	[batch16] ERP - budget新增	erp:budget	create	2026-11-06 20:35:21.825245+08	\N	1
34c08f35-a24b-4235-813e-67b2c4bdf494	bi:report:create	report新增	[batch16] BI 商业智能 - report新增	bi:report	create	2026-11-06 20:35:21.825245+08	\N	1
32c39d9e-b7fb-4923-b064-c64b41e43276	erp:bank_account:update	bank_account编辑	[batch16] ERP - bank_account编辑	erp:bank_account	update	2026-11-06 20:35:21.825245+08	\N	1
8e4e60b4-66de-4373-87e6-00ebb5ba47fe	rd:settings:update	settings编辑	[batch16] RD 研发 - settings编辑	rd:settings	update	2026-11-06 20:35:21.825245+08	\N	1
0b2ee1a8-0ef7-4361-858a-19d68e5a5a11	monitor:log:create	log新增	[batch16] 监控 - log新增	monitor:log	create	2026-11-06 20:35:21.825245+08	\N	1
64dc19d2-3c93-497f-ae14-38c0d1bcb94b	workflow:monitor:update	monitor编辑	[batch16] 工作流 - monitor编辑	workflow:monitor	update	2026-11-06 20:35:21.825245+08	\N	1
f9a8df86-604a-4080-a489-df804759ebc4	monitor:log:update	log编辑	[batch16] 监控 - log编辑	monitor:log	update	2026-11-06 20:35:21.825245+08	\N	1
0c751837-3a89-4398-8cca-be3ec545f3e7	tms:vehicle:create	vehicle新增	[batch16] TMS 运输 - vehicle新增	tms:vehicle	create	2026-11-06 20:35:21.825245+08	\N	1
f9959e1d-7345-4be4-ac85-4f733dde1041	monitor:rule:create	rule新增	[batch17] 监控 - rule新增	monitor:rule	create	2026-11-06 20:35:22.269854+08	\N	1
f1367393-cb31-4103-8177-7fb79d1d5567	wms:stocktake:create	stocktake新增	[batch17] WMS 仓储 - stocktake新增	wms:stocktake	create	2026-11-06 20:35:22.269854+08	\N	1
e5570395-9bf2-48e3-bdaa-1caa8810b4c2	workflow:definition:update	definition编辑	[batch17] 工作流 - definition编辑	workflow:definition	update	2026-11-06 20:35:22.269854+08	\N	1
bbe66186-90df-4c43-88f8-54ce32dfd20d	mes:material_requirement:create	material_requirement新增	[batch17] MES 制造 - material_requirement新增	mes:material_requirement	create	2026-11-06 20:35:22.269854+08	\N	1
c8402f97-7599-4c34-bc17-144b4518324c	mes:material_issue:create	material_issue新增	[batch17] MES 制造 - material_issue新增	mes:material_issue	create	2026-11-06 20:35:22.269854+08	\N	1
74a37ede-defc-483a-913d-3e0f762cae04	finance:accounting_subject:create	accounting_subject新增	[batch17] 财务 - accounting_subject新增	finance:accounting_subject	create	2026-11-06 20:35:22.269854+08	\N	1
941413ed-8ca1-48b9-84e9-8bb1395cdb1d	workflow:definition:delete	definition删除	[batch17] 工作流 - definition删除	workflow:definition	delete	2026-11-06 20:35:22.269854+08	\N	1
b9e23e2b-ed1f-4834-a7c9-bfa25ff84cfc	wms:stocktake:delete	stocktake删除	[batch17] WMS 仓储 - stocktake删除	wms:stocktake	delete	2026-11-06 20:35:22.269854+08	\N	1
2bfb8102-c606-4931-915f-7e7bbbcffaf3	finance:accounting_subject:delete	accounting_subject删除	[batch17] 财务 - accounting_subject删除	finance:accounting_subject	delete	2026-11-06 20:35:22.269854+08	\N	1
5c73c8c9-23f0-4930-9a01-ba45778b655b	mes:material_issue:delete	material_issue删除	[batch17] MES 制造 - material_issue删除	mes:material_issue	delete	2026-11-06 20:35:22.269854+08	\N	1
b7fb70ce-b504-46e5-9e97-23034498d018	scm:incoming_inspection:create	incoming_inspection新增	[batch17] SCM 供应链 - incoming_inspection新增	scm:incoming_inspection	create	2026-11-06 20:35:22.269854+08	\N	1
d940bc3a-36de-447f-8d42-3ee20e6ec6e9	scm:incoming_inspection:delete	incoming_inspection删除	[batch17] SCM 供应链 - incoming_inspection删除	scm:incoming_inspection	delete	2026-11-06 20:35:22.269854+08	\N	1
7f0e8e33-a778-49ea-9154-41ca1b615438	finance:receivable_payable:delete	receivable_payable删除	[batch17] 财务 - receivable_payable删除	finance:receivable_payable	delete	2026-11-06 20:35:22.269854+08	\N	1
053645fc-9d06-40e3-965c-b709647a52b5	monitor:rule:delete	rule删除	[batch17] 监控 - rule删除	monitor:rule	delete	2026-11-06 20:35:22.269854+08	\N	1
6e2cf085-c106-4cb2-b1a4-50372588f9a0	mes:material_return:delete	material_return删除	[batch17] MES 制造 - material_return删除	mes:material_return	delete	2026-11-06 20:35:22.269854+08	\N	1
99335c7e-5f9b-48c0-83d0-281c7547cbea	scm:incoming_notice:delete	incoming_notice删除	[batch17] SCM 供应链 - incoming_notice删除	scm:incoming_notice	delete	2026-11-06 20:35:22.269854+08	\N	1
faaa9c07-8aa1-4f26-ae01-8c90845911fe	monitor:rule:update	rule编辑	[batch17] 监控 - rule编辑	monitor:rule	update	2026-11-06 20:35:22.269854+08	\N	1
00fdeef7-9fbc-48dc-9821-77c1939b82a2	finance:receivable_payable:update	receivable_payable编辑	[batch17] 财务 - receivable_payable编辑	finance:receivable_payable	update	2026-11-06 20:35:22.269854+08	\N	1
7da73fc8-601a-442b-93c7-5821ab844ff7	mes:material_requirement:update	material_requirement编辑	[batch17] MES 制造 - material_requirement编辑	mes:material_requirement	update	2026-11-06 20:35:22.269854+08	\N	1
c832dbf0-2d98-4259-8f4d-f560222e26bc	finance:accounting_subject:update	accounting_subject编辑	[batch17] 财务 - accounting_subject编辑	finance:accounting_subject	update	2026-11-06 20:35:22.269854+08	\N	1
2742d55e-6096-4249-b354-9c6b34c7f7b9	scm:incoming_inspection:update	incoming_inspection编辑	[batch17] SCM 供应链 - incoming_inspection编辑	scm:incoming_inspection	update	2026-11-06 20:35:22.269854+08	\N	1
4d1b3ec6-1d98-41cd-be4a-f88717fe6e2b	finance:receivable_payable:create	receivable_payable新增	[batch17] 财务 - receivable_payable新增	finance:receivable_payable	create	2026-11-06 20:35:22.269854+08	\N	1
3ea53436-19c1-442c-ae10-8b1b28eeea7e	workflow:definition:create	definition新增	[batch17] 工作流 - definition新增	workflow:definition	create	2026-11-06 20:35:22.269854+08	\N	1
5618c32a-d553-454c-a55e-b4b848951dae	mes:material_issue:update	material_issue编辑	[batch17] MES 制造 - material_issue编辑	mes:material_issue	update	2026-11-06 20:35:22.269854+08	\N	1
54043311-7447-437f-8a99-1e9aee3a4a27	mes:material_return:create	material_return新增	[batch17] MES 制造 - material_return新增	mes:material_return	create	2026-11-06 20:35:22.269854+08	\N	1
04c882bf-8f86-44a6-9b57-59b10386726f	scm:incoming_notice:create	incoming_notice新增	[batch17] SCM 供应链 - incoming_notice新增	scm:incoming_notice	create	2026-11-06 20:35:22.269854+08	\N	1
34790df1-fe58-4615-b425-1ce281aa65e1	wms:stocktake:update	stocktake编辑	[batch17] WMS 仓储 - stocktake编辑	wms:stocktake	update	2026-11-06 20:35:22.269854+08	\N	1
f144910d-6781-402f-b059-1da7e7b6b4cc	scm:incoming_notice:update	incoming_notice编辑	[batch17] SCM 供应链 - incoming_notice编辑	scm:incoming_notice	update	2026-11-06 20:35:22.269854+08	\N	1
04917cb1-bb3f-45cb-a481-23a8eabc9254	mes:material_return:update	material_return编辑	[batch17] MES 制造 - material_return编辑	mes:material_return	update	2026-11-06 20:35:22.269854+08	\N	1
af129ae9-e34e-467a-a475-0f21870ae0bd	mes:material_requirement:delete	material_requirement删除	[batch17] MES 制造 - material_requirement删除	mes:material_requirement	delete	2026-11-06 20:35:22.269854+08	\N	1
7f89b056-b99f-4de5-9c12-1d5866400326	integration:mes_erp_sync:update	MES-ERP 同步编辑	[batch18] 资源级细化 - MES-ERP 同步编辑	integration:mes_erp_sync	update	2026-11-06 20:35:22.70089+08	\N	1
322a1d7e-b0aa-465a-990e-5e03aa5e942e	plugin:plugin:create	插件新增	[batch18] 资源级细化 - 插件新增	plugin:plugin	create	2026-11-06 20:35:22.70089+08	\N	1
2512cfea-743c-4d9c-9b8d-ea0550b480be	notification:notification:create	通知新增	[batch18] 资源级细化 - 通知新增	notification:notification	create	2026-11-06 20:35:22.70089+08	\N	1
ebe63d56-486f-452b-b6de-b161daaafb39	integration:lims_qms_sync:create	LIMS-QMS 同步新增	[batch18] 资源级细化 - LIMS-QMS 同步新增	integration:lims_qms_sync	create	2026-11-06 20:35:22.70089+08	\N	1
07a960b5-eff6-4215-b520-b5f2454ed483	integration:mes_erp_sync:delete	MES-ERP 同步删除	[batch18] 资源级细化 - MES-ERP 同步删除	integration:mes_erp_sync	delete	2026-11-06 20:35:22.70089+08	\N	1
4405f644-a32f-4a41-b537-a1c561b9b198	plugin:plugin:update	插件编辑	[batch18] 资源级细化 - 插件编辑	plugin:plugin	update	2026-11-06 20:35:22.70089+08	\N	1
1491b26c-12ec-45b3-b244-445c3f853464	ticket:ticket:delete	工单删除	[batch18] 资源级细化 - 工单删除	ticket:ticket	delete	2026-11-06 20:35:22.70089+08	\N	1
07517026-bf6b-4671-80fc-90db2b4a2dce	integration:mes_erp_sync:create	MES-ERP 同步新增	[batch18] 资源级细化 - MES-ERP 同步新增	integration:mes_erp_sync	create	2026-11-06 20:35:22.70089+08	\N	1
2f57c955-7b0a-4a22-8ec0-c7e0ccc9c841	ticket:ticket:create	工单新增	[batch18] 资源级细化 - 工单新增	ticket:ticket	create	2026-11-06 20:35:22.70089+08	\N	1
60ccc8c2-67b7-4443-8c4d-e90bbceaa71f	integration:wms_scm_sync:create	WMS-SCM 同步新增	[batch18] 资源级细化 - WMS-SCM 同步新增	integration:wms_scm_sync	create	2026-11-06 20:35:22.70089+08	\N	1
a4a41368-eb60-4ddc-b84f-19cec451b993	notification:archived_notification:update	归档通知编辑	[batch18] 资源级细化 - 归档通知编辑	notification:archived_notification	update	2026-11-06 20:35:22.70089+08	\N	1
987b8b58-51f3-4b1f-899d-d8d3542ee47c	notification:archived_notification:create	归档通知新增	[batch18] 资源级细化 - 归档通知新增	notification:archived_notification	create	2026-11-06 20:35:22.70089+08	\N	1
8332357a-92e5-4805-add4-24f6b031ca46	finance:account:create	财务账户新增	[batch18] 资源级细化 - 财务账户新增	finance:account	create	2026-11-06 20:35:22.70089+08	\N	1
220b0863-9c3e-4d57-b330-78c686c01bbd	notification:notification:delete	通知删除	[batch18] 资源级细化 - 通知删除	notification:notification	delete	2026-11-06 20:35:22.70089+08	\N	1
630ded6e-28aa-4b53-a06c-050856caef54	integration:lims_qms_sync:update	LIMS-QMS 同步编辑	[batch18] 资源级细化 - LIMS-QMS 同步编辑	integration:lims_qms_sync	update	2026-11-06 20:35:22.70089+08	\N	1
bc6b1dbf-952e-45cc-a580-4c0dc21c4552	finance:account:update	财务账户编辑	[batch18] 资源级细化 - 财务账户编辑	finance:account	update	2026-11-06 20:35:22.70089+08	\N	1
eb9b1227-b755-4714-a8aa-872b2f79b46c	migration:service:create	迁移服务新增	[batch18] 资源级细化 - 迁移服务新增	migration:service	create	2026-11-06 20:35:22.70089+08	\N	1
4a2625b0-e28a-4fab-8a2d-188692d5823e	integration:lims_qms_sync:delete	LIMS-QMS 同步删除	[batch18] 资源级细化 - LIMS-QMS 同步删除	integration:lims_qms_sync	delete	2026-11-06 20:35:22.70089+08	\N	1
65a587c5-cf86-4c75-919a-6e2f440bba9f	notification:archived_notification:delete	归档通知删除	[batch18] 资源级细化 - 归档通知删除	notification:archived_notification	delete	2026-11-06 20:35:22.70089+08	\N	1
a0d1ee67-68ca-4f4e-a975-b5ed68dca124	integration:wms_scm_sync:delete	WMS-SCM 同步删除	[batch18] 资源级细化 - WMS-SCM 同步删除	integration:wms_scm_sync	delete	2026-11-06 20:35:22.70089+08	\N	1
d060d262-07c5-4ee5-813c-142129947bcf	ticket:ticket:update	工单编辑	[batch18] 资源级细化 - 工单编辑	ticket:ticket	update	2026-11-06 20:35:22.70089+08	\N	1
6392fd1a-35a3-460e-8a68-be10946390ce	migration:service:update	迁移服务编辑	[batch18] 资源级细化 - 迁移服务编辑	migration:service	update	2026-11-06 20:35:22.70089+08	\N	1
d29d5383-1f6d-41a9-b3a7-56f975a1e894	migration:service:delete	迁移服务删除	[batch18] 资源级细化 - 迁移服务删除	migration:service	delete	2026-11-06 20:35:22.70089+08	\N	1
66376c2e-4e25-4fc0-aa85-3a6b35e484d3	notification:notification:update	通知编辑	[batch18] 资源级细化 - 通知编辑	notification:notification	update	2026-11-06 20:35:22.70089+08	\N	1
ffc788e8-e52b-4ba7-a09d-c0c77317037d	integration:wms_scm_sync:update	WMS-SCM 同步编辑	[batch18] 资源级细化 - WMS-SCM 同步编辑	integration:wms_scm_sync	update	2026-11-06 20:35:22.70089+08	\N	1
ecf48b36-2e09-4809-b509-60ec45878d97	plugin:plugin:delete	插件删除	[batch18] 资源级细化 - 插件删除	plugin:plugin	delete	2026-11-06 20:35:22.70089+08	\N	1
bae8d530-1aed-4f95-b848-e3c44a7ded53	finance:account:delete	财务账户删除	[batch18] 资源级细化 - 财务账户删除	finance:account	delete	2026-11-06 20:35:22.70089+08	\N	1
0f8db095-03cf-4246-bae8-5f3fe7cf2ab3	tenant:member:update	租户成员改角色	[batch19] 租户成员 - 租户成员改角色	tenant:member	update	2026-11-06 20:35:23.20453+08	\N	1
c21e8bc9-a85e-438d-9d06-88d0d764e08d	tenant:member:delete	移除租户成员	[batch19] 租户成员 - 移除租户成员	tenant:member	delete	2026-11-06 20:35:23.20453+08	\N	1
bd706b57-6a9e-4361-91c1-63725487d64b	aps:production_plan:update	production_planupdate	\N	aps:production_plan	update	2026-11-06 20:35:24.082186+08	\N	1
763a0958-a245-4179-b189-02ac2c35c2af	srm:scoring_dimension:read	scoring_dimensionread	\N	srm_scoring_dimension	read	2026-11-06 20:35:24.082186+08	\N	1
4b6809f7-cbea-4d04-ba42-deaa93770f00	srm:scoring_dimension:update	scoring_dimensionupdate	\N	srm_scoring_dimension	update	2026-11-06 20:35:24.082186+08	\N	1
4f73d3e8-aa9b-4387-9984-1794868d3fd6	workflow:template:update	templateupdate	\N	workflow:template	update	2026-11-06 20:35:24.082186+08	\N	1
ab0da67e-00fe-436c-8af9-de46cc06ef12	srm:supplier_product:read	supplier_productread	\N	srm_supplier_product	read	2026-11-06 20:35:24.082186+08	\N	1
cf56b722-e4eb-4117-a9ca-d508206facfd	srm:supplier_product:update	supplier_productupdate	\N	srm_supplier_product	update	2026-11-06 20:35:24.082186+08	\N	1
81568d56-098a-40b9-9429-97e34b23c278	notification:template:update	templateupdate	\N	notification:template	update	2026-11-06 20:35:24.082186+08	\N	1
b070a76b-0fbb-44d6-8b9d-5711b3ebd398	aps:material_plan:create	material_plancreate	\N	aps:material_plan	create	2026-11-06 20:35:24.082186+08	\N	1
d0306a25-e4a9-4929-a26c-0498738a74b9	notification:template:delete	templatedelete	\N	notification:template	delete	2026-11-06 20:35:24.082186+08	\N	1
857a18c7-52e1-4cd3-b9b9-6dc0088bf851	aps:production_plan:create	production_plancreate	\N	aps:production_plan	create	2026-11-06 20:35:24.082186+08	\N	1
e14621c2-64f7-4587-a4f1-bd7b5b47f7e2	notification:template:create	templatecreate	\N	notification:template	create	2026-11-06 20:35:24.082186+08	\N	1
a9f6b4e6-822b-4b84-851b-a1ffbab3e43f	srm:scoring_dimension:create	scoring_dimensioncreate	\N	srm_scoring_dimension	create	2026-11-06 20:35:24.082186+08	\N	1
76412a45-a330-4c5d-b980-00eaa4b744a7	srm:supplier_product:create	supplier_productcreate	\N	srm_supplier_product	create	2026-11-06 20:35:24.082186+08	\N	1
90e092fa-d69e-4fd6-b2f4-2b1cf2d8a262	srm:scoring_dimension:delete	scoring_dimensiondelete	\N	srm_scoring_dimension	delete	2026-11-06 20:35:24.082186+08	\N	1
52703bec-08bc-4ee3-a4f9-682ae741bbf9	aps:production_plan:delete	production_plandelete	\N	aps:production_plan	delete	2026-11-06 20:35:24.082186+08	\N	1
f6027850-7b35-4850-bfd0-b15c19174919	notification:template:read	templateread	\N	notification:template	read	2026-11-06 20:35:24.082186+08	\N	1
f6ce6958-2b21-44aa-bb96-39554ec81604	workflow:template:create	templatecreate	\N	workflow:template	create	2026-11-06 20:35:24.082186+08	\N	1
72dc2e76-a39e-406c-8bbc-1559ab645585	srm:supplier_product:delete	supplier_productdelete	\N	srm_supplier_product	delete	2026-11-06 20:35:24.082186+08	\N	1
141b5492-281b-42d2-be27-f8ad5b181a63	workflow:template:delete	templatedelete	\N	workflow:template	delete	2026-11-06 20:35:24.082186+08	\N	1
28a3edea-437f-4365-975a-156ac8a73f8d	aps:material_plan:delete	material_plandelete	\N	aps:material_plan	delete	2026-11-06 20:35:24.082186+08	\N	1
5c5e6265-5a8b-46e8-9bba-15787b9eab28	aps:material_plan:update	material_planupdate	\N	aps:material_plan	update	2026-11-06 20:35:24.082186+08	\N	1
05ec6937-961a-410e-a9ac-227d40d840b7	tenant:iam:user:read	租户用户-查看	查询本租户用户与用户角色	tenant:iam:user	read	2026-11-09 02:28:54.17722+08	\N	1
802f13e3-fd63-4e2d-bbdc-17815703539c	tenant:iam:user:write	租户用户-创建/编辑/停用启用	创建本租户用户、编辑、停用/启用、分配角色	tenant:iam:user	write	2026-11-09 02:28:54.17722+08	\N	1
e7c833e3-4ff2-4b90-bf4e-2919801570bf	tenant:iam:user:delete	租户用户-删除	删除本租户用户	tenant:iam:user	delete	2026-11-09 02:28:54.17722+08	\N	1
b8982ea9-0ce9-47b5-9076-15cd51efa5b2	tenant:iam:role:read	租户角色-查看	查询本租户角色及其权限	tenant:iam:role	read	2026-11-09 02:28:54.17722+08	\N	1
e8a317fb-fa27-4b41-a538-00901208d96d	tenant:iam:role:write	租户角色-创建/编辑/授权	创建/编辑本租户角色并为其授权	tenant:iam:role	write	2026-11-09 02:28:54.17722+08	\N	1
0322e71d-420b-4b48-b61b-03de2dc61699	tenant:iam:role:delete	租户角色-删除	删除本租户角色	tenant:iam:role	delete	2026-11-09 02:28:54.17722+08	\N	1
280a25fb-e477-4949-a8d5-df94fca6b401	erp:consolidation-report:write	合并报表-生成	生成合并报表（法人主体账簿归集）	erp:consolidation-report	write	2026-11-09 02:28:54.762986+08	\N	1
59fb9b24-730c-467a-b976-90dbc7d78f4d	erp:consolidation-report:approve	合并报表-发布	发布/对外出具合并报表	erp:consolidation-report	approve	2026-11-09 02:28:54.762986+08	\N	1
492556b0-a0a7-4b66-9321-8e216814f0aa	erp:consolidation-elimination:write	合并抵消-执行	执行内部交易抵消	erp:consolidation-elimination	write	2026-11-09 02:28:54.762986+08	\N	1
5e308f32-7e48-4772-8ed4-0a1c1ed848d9	finance:admin	财务管理-管理员	\N	finance	admin	2026-11-09 08:07:44.75189+08	\N	1
bc627ce4-1f81-4575-9011-ce8668db061b	finance:sales_invoice:write	销售发票-写（开具/红冲/核销）	finance 销售发票写权限	finance:sales_invoice	write	2026-11-09 09:45:24.446397+08	\N	1
00306d29-c80c-47d1-93a8-2d9192803637	finance:reconciliation:read	对账会话-只读	finance 对账会话只读	finance:reconciliation	read	2026-11-09 09:45:24.446397+08	\N	1
af0c2a4d-126b-4bbb-9a77-d647352fb734	finance:treasury:read	资金池/流动性管理-只读	finance 资金管理只读	finance:treasury	read	2026-11-09 09:45:24.446397+08	\N	1
6cb110b0-75f2-4504-aeef-048e1187ab71	mes:work_order:write	MES 工单写入	创建/修改/删除 MES 工单	mes:work_order	write	2026-11-09 09:45:24.446397+08	\N	1
a8bfdb38-dd1e-41b4-88ec-8189403501f9	finance:reconcile_orders:write	对账单-写（确认/争议/取消/明细）	finance 对账单写权限	finance:reconcile_orders	write	2026-11-09 09:45:24.446397+08	\N	1
848d1b52-bc4f-4f2e-ad73-29df82f5bfc6	bi:data_source:write	BI 数据源写入	创建/修改/删除 BI 数据源	bi:data_source	write	2026-11-09 09:45:24.446397+08	\N	1
225674f2-6e83-4c3e-8a09-a3f6caea07d1	finance:currency:write	币种-写（创建/更新）	finance 币种写权限	finance:currency	write	2026-11-09 09:45:24.446397+08	\N	1
98a20992-7a69-4e57-8a16-fdbb2b5f700b	finance:compliance:read	内控合规-只读	finance 内控合规只读	finance:compliance	read	2026-11-09 09:45:24.446397+08	\N	1
46cddfb6-5882-44aa-b11d-d1aee715439d	finance:account:read	账户管理-只读	finance 账户只读	finance:account	read	2026-11-09 09:45:24.446397+08	\N	1
cf75fe11-f4f8-491d-8394-1980b2f2f94b	finance:risk:read	风险管理/反欺诈/信用评分-只读	finance 风险只读	finance:risk	read	2026-11-09 09:45:24.446397+08	\N	1
babc3cc7-e344-4885-8f20-b9f9d9939240	finance:budget:write	预算管理-写（创建/更新/删除）	finance 预算写权限	finance:budget	write	2026-11-09 09:45:24.446397+08	\N	1
08ed4910-224d-4125-8c3e-dab56be8577d	finance:currency:delete	币种-删除	finance 币种删除权限	finance:currency	delete	2026-11-09 09:45:24.446397+08	\N	1
9bb1e76f-9780-4648-b2ed-7b8bc6671bd9	finance:period:write	会计期间-写（开账/关账/年结）	finance 会计期间写权限	finance:period	write	2026-11-09 09:45:24.446397+08	\N	1
b3f4384c-986c-4b35-aad7-6eb34def291f	finance:reconcile_orders:read	对账单-只读	finance 对账单只读	finance:reconcile_orders	read	2026-11-09 09:45:24.446397+08	\N	1
31095c25-6bab-485f-b7bd-a2e15eb7a0e1	finance:event:read	事件溯源/CQRS 观测-只读	finance 事件观测只读	finance:event	read	2026-11-09 09:45:24.446397+08	\N	1
27cb8d9b-1d9b-47cb-877d-75cd6773ed20	finance:audit:read	审计/异常检测-只读	finance 审计只读	finance:audit	read	2026-11-09 09:45:24.446397+08	\N	1
de52b259-81b0-45c1-9a68-dd98e4fa523c	finance:sales_invoice:read	销售发票-只读	finance 销售发票只读	finance:sales_invoice	read	2026-11-09 09:45:24.446397+08	\N	1
e9a786c4-1f7a-4390-9308-b38c970672c0	wms:stocktake:write	WMS 盘点写入	录入/完成盘点	wms:stocktake	write	2026-11-09 09:45:24.446397+08	\N	1
d5f4bca6-7d6a-4790-887f-5982fca20bb2	rd:read	研发-只读	rd 模块只读入口	rd	read	2026-11-09 09:45:25.950156+08	\N	1
940e226d-5b0e-4877-91e6-2ec4e47498e2	bi:permission_rule:read	BI 行级权限-只读	BI 行级权限规则读取与校验	bi	read	2026-11-09 10:26:20.511016+08	\N	1
00bfb122-253b-4bd5-995b-17cd1ddc5a11	bi:dataset:write	BI 数据集-写	BI 数据集增删改与发布	bi	write	2026-11-09 10:26:20.511016+08	\N	1
070f8f3f-5717-4d45-be78-0d2f9238e4dc	bi:drilldown:read	BI 下钻-只读	BI 下钻路径读取与计算	bi	read	2026-11-09 10:26:20.511016+08	\N	1
1616e92d-1c8d-4ccf-b576-c7d948429544	bi:sync_record:write	BI 同步记录-写	BI 同步记录增删改与重试	bi	write	2026-11-09 10:26:20.511016+08	\N	1
a625a92a-33b7-4221-af0a-24744648366d	bi:sync_record:read	BI 同步记录-只读	BI 同步记录读取	bi	read	2026-11-09 10:26:20.511016+08	\N	1
d66dd64f-f5ff-497d-8461-bb191847f331	bi:multidim:write	BI 多维-写	BI 多维分析配置维护	bi	write	2026-11-09 10:26:20.511016+08	\N	1
6e089f86-ccc8-4fdd-9c3a-66ede7bd962a	bi:drilldown:write	BI 下钻-写	BI 下钻路径增删改	bi	write	2026-11-09 10:26:20.511016+08	\N	1
c9e2eb02-37a8-43aa-90fb-c4d84caa37bb	bi:prediction:read	BI 预测-只读	BI 预测分析计算	bi	read	2026-11-09 10:26:20.511016+08	\N	1
cd9707ee-bbd3-4393-8721-62d20b9e2d22	bi:prediction:write	BI 预测-写	BI 预测分析配置维护	bi	write	2026-11-09 10:26:20.511016+08	\N	1
dc19f4ed-7ffd-4f5e-8275-ba6850b2a039	bi:multidim:read	BI 多维-只读	BI 多维分析计算	bi	read	2026-11-09 10:26:20.511016+08	\N	1
c38202a6-3e12-475d-be8f-c1c59c10927d	bi:widget:read	BI 组件-只读	BI widget 读取	bi	read	2026-11-09 10:26:20.511016+08	\N	1
03d4a358-e823-4e63-891d-ff28f77c268c	bi:permission_rule:write	BI 行级权限-写	BI 行级权限规则增删改	bi	write	2026-11-09 10:26:20.511016+08	\N	1
9b1f71d6-746d-430e-83ae-2f7dfbdb9565	bi:widget:write	BI 组件-写	BI widget 增删改与缓存刷新	bi	write	2026-11-09 10:26:20.511016+08	\N	1
bf28ab8d-d374-4ffd-96c7-bf0aa355993d	bi:comparison:write	BI 对比分析-写	BI 对比分析定义增删改与执行	bi	write	2026-11-09 11:03:00.285893+08	\N	1
2080eeca-74af-463d-93bd-7937274c13a3	bi:visualization:write	BI 可视化-写	BI 可视化创建、联动/下钻配置与导出	bi	write	2026-11-09 11:03:00.285893+08	\N	1
86c8b49a-2712-451a-9834-8b8a7be85130	erp:consolidation-ledger:write	内部交易台账-登记	录入/编辑内部交易台账、标记争议	erp:consolidation-ledger	write	2026-11-09 18:07:55.529691+08	\N	1
8253a7ea-4e44-40f6-a83f-2fd2ec1c5980	erp:consolidation-ledger:approve	内部交易台账-确认	确认内部交易台账（锁定对账金额）	erp:consolidation-ledger	approve	2026-11-09 18:07:55.529691+08	\N	1
80ffbaa3-c385-475c-b6bc-552a8e36c5e8	erp:consolidation-scan:write	内部交易-凭证扫描	按期间与合并范围扫描同额反向凭证候选	erp:consolidation-scan	write	2026-11-09 18:07:55.529691+08	\N	1
9d8e778e-60cb-48c7-9377-ad7bce191b3d	erp:consolidation-reconcile:read	内部交易-对账与预演	查看对账汇总与抵消草案（只读/只算）	erp:consolidation-reconcile	read	2026-11-09 18:07:55.529691+08	\N	1
\.


--
-- Data for Name: core_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_roles (id, name, description, tenant_id, created_at, updated_at, deleted_at) FROM stdin;
4067eaab-92bb-4c68-b572-fae02796cb27	finance_manager	财务管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
2ddf11b1-c45c-4165-a20a-07e75bcccca4	mes_manager	生产执行管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	hrm_manager	人力资源管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
95baa6b7-6091-4ef5-a7fb-46c3fac66353	pdm_manager	产品数据管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
36007d81-ad46-47f0-85cf-17a0fc1b5261	wms_manager	仓储管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
abe01221-93fe-4696-8be4-f337165cce8e	ehs_manager	安全环保管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
e886aca3-bbec-4c39-a1ca-28367293c2ce	lims_manager	实验室管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	crm_manager	客户关系管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	qms_manager	质量管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	scm_manager	供应链管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
7ef90500-6e0a-461c-8e2f-031feb086d85	srm_manager	供应商关系管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
2d1e7e21-dd42-484f-88a6-a7fe10d43825	report_manager	报表中心管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
8f4d643d-905a-4773-8e26-082b78d9e329	pm_manager	项目管理角色	\N	2026-10-26 14:01:29.435478+08	2026-10-26 14:01:29.435478+08	\N
1e637734-778d-41b8-9638-60b13c44be9d	erp_manager	企业管理角色	\N	2026-10-26 14:03:20.555078+08	2026-10-26 14:03:20.555078+08	\N
2ad18844-4410-455b-b26d-f8dcdb10db09	admin	系统管理员角色	\N	2026-10-26 14:03:20.591427+08	2026-10-26 14:03:20.591427+08	\N
0c000000-0000-4000-8000-000000000001	tenant_admin	租户管理员（本租户全部业务权限，无平台级权限）	\N	2026-11-08 08:26:50.347723+08	2026-11-08 08:26:50.347723+08	\N
f820611c-ac5d-4275-ad52-36401dfc093e	f1_prod_check_1111210231	F1 prod acceptance	00000000-0000-0000-0000-000000000001	2026-11-11 21:02:33.69389+08	2026-11-11 21:02:42.875262+08	2026-11-11 21:02:42.875262+08
\.


--
-- Data for Name: core_role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_role_permissions (role_id, permission_id, created_at) FROM stdin;
4067eaab-92bb-4c68-b572-fae02796cb27	a8e0c9ce-4e68-4220-8873-07b3e174fc55	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	5fd4c317-345c-4082-acd3-86b2d1a628d0	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	a8b5e958-a6c9-45b4-b1d1-b9bc24436942	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	bf58df65-0a9f-4350-8ebf-6f935cd76f55	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	0fde9d79-d70b-4d67-98e5-39013bca2049	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	c133dc2a-a880-4aac-b3cb-f5eee2d7a956	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	4b3b52c2-6275-4a92-9605-8542cce2c447	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	51c19f90-6687-4771-aedd-a46847a2e3a4	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	546fe75c-e5a5-4504-b119-0c7606b3f601	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	9b7e89f6-e91f-47bb-97b7-97e34155e1fa	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	96b56a30-f52b-4ba5-aeee-b887d80dac17	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	85ebece3-d64e-4319-8c01-74cac6f0e8f7	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	8d0e2a15-51d1-4ee4-8a1f-9b6dacee6d84	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	5c1fd4b4-e938-4409-8676-c07461a78592	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	960bc690-d63e-4487-921e-83fbfc1f92b5	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	646429bc-10c0-48a0-bca7-9d1f3ddd0a09	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	d7e3bbf7-ef49-4a4b-87e7-64abe01d89f1	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	013a8f85-655b-4605-bd89-c5753b208e84	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	55db4ace-61f3-4e5e-af33-aef22de617c4	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	edac3ada-a2b4-4dae-aafc-314c8cbe9b88	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	5977d93d-c1d1-489d-b82b-0d4bc7d82ea8	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	e66d1aaa-4a3a-4e49-88a9-c6752fe68b13	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	3804bf4b-84ac-4353-857a-7199a4e17d05	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	0b3fcb81-17ac-410f-afda-0813de7613fa	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	eb60c8ca-b38e-47f3-8146-bdf18701e15f	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	7236630c-200c-4c3b-b5a9-37f917e97520	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	010ae5d8-3f48-49d0-bef3-5e4a8f5d10a5	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	4d384c77-8040-4971-ae47-51b53e37843f	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	dd45992d-1935-4d08-a87d-a92079ae1539	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	001ceb18-bfdf-4c96-9de2-45dfed32d0ac	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	936aa7b2-c830-4231-9045-08c0b6a7ccaa	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	01e15450-5a56-429b-b81c-09bb1427f13d	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	808a44a1-7906-4bb7-92e7-69cd0c45c9c8	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	455aae0b-d0c1-48ef-8193-4ed35482702f	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	762d54d2-5f86-4e60-ad17-87a38d8984d7	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	e736e259-e2c0-49e7-9f72-a8b53000bfd9	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	4e6e1cf6-3460-4dfb-9132-f68183f530c3	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	636d4e26-b3e2-4ae7-a032-229a4a8a7841	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	d9f4aab1-3bf8-4fef-bb18-d46f5e0cc5e1	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	01f82c34-63d7-439b-9960-77cf6d630db6	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	9a9b4f53-9d77-4a92-b56c-910cb5f679c1	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	c0e150ca-03d8-41bd-bcdd-ef8ebbdc754d	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	2ff29ce8-ef9e-4548-ada3-7d9f4d31f4b2	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	6710c623-a245-477b-8268-eecc6fcf876b	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	945f8e67-6a22-4cd4-8392-c78f5e6ef327	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	f84d58c1-1cc1-4cf9-a03f-cdb54ebd7a09	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	190c81a3-8393-4cb1-9c04-5f2ad649af5d	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	27412e21-3e81-4d36-9c9e-a99f3d38046f	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	f0d65596-18de-4dc4-b72b-8a79818a207d	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	07cd1e24-e4a1-4dbb-b25e-9f6f88b9367d	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	fa723e87-1395-4aca-9237-10ac9a57ee5e	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	05ec6937-961a-410e-a9ac-227d40d840b7	2026-11-09 02:28:54.17722+08
0c000000-0000-4000-8000-000000000001	05ec6937-961a-410e-a9ac-227d40d840b7	2026-11-09 02:28:54.17722+08
2ad18844-4410-455b-b26d-f8dcdb10db09	802f13e3-fd63-4e2d-bbdc-17815703539c	2026-11-09 02:28:54.17722+08
4067eaab-92bb-4c68-b572-fae02796cb27	3ce5e888-9e7d-4b00-b7e3-e4339f3424d8	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	cfeab591-d11a-469d-9b99-4ba15bc8f49a	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	c3c6fa15-32f9-4d98-aaa6-49264d1b7313	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	d4906907-0467-4dab-8e20-52e1c8baae9e	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	0e2a882b-9d5f-4652-b4cb-3fdbf1ae5316	2026-10-26 14:01:29.435478+08
0c000000-0000-4000-8000-000000000001	802f13e3-fd63-4e2d-bbdc-17815703539c	2026-11-09 02:28:54.17722+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e7c833e3-4ff2-4b90-bf4e-2919801570bf	2026-11-09 02:28:54.17722+08
0c000000-0000-4000-8000-000000000001	e7c833e3-4ff2-4b90-bf4e-2919801570bf	2026-11-09 02:28:54.17722+08
4067eaab-92bb-4c68-b572-fae02796cb27	41b622cf-c723-4c96-a24c-24fc3f08ebe3	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b8982ea9-0ce9-47b5-9076-15cd51efa5b2	2026-11-09 02:28:54.17722+08
0c000000-0000-4000-8000-000000000001	b8982ea9-0ce9-47b5-9076-15cd51efa5b2	2026-11-09 02:28:54.17722+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e8a317fb-fa27-4b41-a538-00901208d96d	2026-11-09 02:28:54.17722+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	10921a0f-4d4c-4a8b-80f7-36dd49329e08	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	1c7b23ea-b36e-4ccf-9da0-ea25555afcea	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	4fc78ace-01fa-4e7b-8bfd-cda3ed05ac48	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	e06dc873-56c7-4336-b870-63a9ead79648	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	83120ae4-ec9d-42e5-ba97-4992b821337a	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	571c2e47-915a-48b8-8bef-d07e887975f9	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	a02f8a09-8e60-41d3-ae57-31290ebff1ea	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	d7a1a601-c219-45c9-ac46-9a59c25bd468	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	2c9382d8-5ae1-4624-ac4c-915cf8ee2b8d	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	fe70ea88-828e-4738-9007-3dd1fe53f8ea	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	168b2e7d-f672-475e-8b5f-57fe73ccd6de	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	6fb10e1e-f330-48c7-ad0c-feca214c574b	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	10662b93-a8e6-4518-8eb3-f9b256915fcc	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	b5b41188-23f9-4b8c-94b4-5874f9e20bea	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	009e9f52-2e61-40b4-932f-0e131dd6f8c1	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	6c32eb6d-4e11-4d46-a975-74bb96409c39	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	6869a699-602f-4d2c-8150-26c975d94562	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	6d6e5327-5026-487e-b845-04d4fcf2923e	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	98e3ab60-733c-4d10-a21a-8134c294645b	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	1e5ab521-a55b-41d0-8ec9-58406058fa61	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	4bd8e98a-d4bd-49eb-84cc-bf5fe790b571	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	509148e7-f34e-4e44-b637-0b83085ade65	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	165d6ddd-16a4-46ed-b0f8-2ca7a777ac7d	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	fa720e0d-e494-4d9e-87f6-62a609e9a103	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	03c480ab-e62a-45f0-b159-1c0b882934dd	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	5c24b0ca-ae87-444e-ae30-de8e099cebed	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	ed8284f0-b8b8-4ae8-8ca4-ef91de0d0c34	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	ad8bbdd3-1f75-4836-ad56-a27f0a01e292	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	e745cac8-9415-4e23-b3a0-a5993c4f374d	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	1edeb642-b711-4af3-a5ca-d48682dc2442	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	3e2033bb-34fb-4693-bb5e-e367af2f626a	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	ecbf4abe-bcc8-4e4e-82d3-d807a9cd38db	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	3b2e6c70-8248-4075-b0ad-4b9f613dc6e0	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	4c2454aa-a2e0-4223-adca-a1669ad62a02	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	ca69cb47-4c0e-4e29-bcb8-afce2c41fb47	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	5ce25f80-91f8-4f98-bc09-28e2d63cc39a	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	48ed375b-8c51-40e8-b400-4969107d8add	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	655d7299-4fbb-48fd-9a67-b4073fa4dc5f	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	c8ed86f5-ce14-4069-a332-0bf43a28b9eb	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	19a6d6f4-803d-4e51-9610-d3dde318b566	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	faa09e9f-fc85-4dfc-8ca5-9c4ea1043a11	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	0840d1e7-a0df-49eb-889c-05090219c464	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	2c8614cd-e470-4f92-a189-19a06080c19c	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	0820e071-6289-4079-bf92-919475011b3d	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	9230a691-7d05-41b2-b03c-77c786a32c35	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	9e01ba74-2e21-440b-bd7b-bc75ed9e0f4d	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	a8ba07cd-57ce-4bca-b956-788e42505749	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	a47e6e07-4923-4574-b03c-51863791b181	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	f272fde9-ef6b-4fc1-bb26-5498354b82e3	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	bef7b45a-f638-4097-bfe6-91099e90e3f4	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	850dff23-444d-4cb7-a9a8-e92259725eae	2026-10-26 14:01:29.435478+08
0c000000-0000-4000-8000-000000000001	e8a317fb-fa27-4b41-a538-00901208d96d	2026-11-09 02:28:54.17722+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0322e71d-420b-4b48-b61b-03de2dc61699	2026-11-09 02:28:54.17722+08
0c000000-0000-4000-8000-000000000001	0322e71d-420b-4b48-b61b-03de2dc61699	2026-11-09 02:28:54.17722+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	473919fc-b929-4a5a-be7e-78da5ed172d8	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	280a25fb-e477-4949-a8d5-df94fca6b401	2026-11-09 02:28:54.762986+08
4067eaab-92bb-4c68-b572-fae02796cb27	59fb9b24-730c-467a-b976-90dbc7d78f4d	2026-11-09 02:28:54.762986+08
4067eaab-92bb-4c68-b572-fae02796cb27	492556b0-a0a7-4b66-9321-8e216814f0aa	2026-11-09 02:28:54.762986+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	dc5e30e2-9930-4122-ab9f-e09eb611c355	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	68bcb990-8045-49fc-887e-b05b5eb3e85c	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	9634edd3-c3db-44cf-80ab-42e285d61f21	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	0b3b1209-4d33-4d56-b806-7492c6bb4707	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	2c1d27d1-1d54-4489-a780-eb9c56e67c01	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	52ae7693-c712-4ce9-95ca-89afbbac2134	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	2d8a31a6-9597-4ca5-8b8d-9159f13ecaa4	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	d1743946-021d-439a-924a-8574bd4b9988	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	1f6fc74d-714d-4cbe-85f9-938e660447a6	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	c30146fa-f946-4f2b-af17-7bc71694e5ea	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	d23459aa-4792-428c-beb2-16624085980d	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	432de1f9-6cf4-4de6-9cbc-8abf02ea5cdb	2026-10-26 14:01:29.435478+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	60bd83c4-7428-4aab-bb88-fe8c3f2c44c1	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	280a25fb-e477-4949-a8d5-df94fca6b401	2026-11-09 02:28:54.762986+08
2ad18844-4410-455b-b26d-f8dcdb10db09	59fb9b24-730c-467a-b976-90dbc7d78f4d	2026-11-09 02:28:54.762986+08
2ad18844-4410-455b-b26d-f8dcdb10db09	492556b0-a0a7-4b66-9321-8e216814f0aa	2026-11-09 02:28:54.762986+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	4ccdf7e0-ae8a-41ee-a29a-211329cfd778	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	44f45d52-a3dc-4bd2-8751-896f42240291	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	eeda10f2-69d8-46b8-b826-d8e0171bde29	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	d0282329-30ee-4b36-b22e-339f2389511a	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	1c883f18-7d3a-4cd8-916a-0c79c594280e	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	57ff869b-2160-4a3b-a3eb-8e060eb0d324	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	86626cfa-5620-4f52-a530-41efc55ef896	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	86234189-20bf-4208-bcab-69fe0e13a155	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	58ed58fc-8ed9-4838-b805-3d444871295f	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	a4136bb7-debb-4a75-9f25-524a3b8a867f	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	8835b668-5fe1-42df-ad09-97a240456194	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	bcb676b8-9361-405b-9293-5f63be4e703b	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	16be4633-23e1-4325-9dcb-3e9784302eb2	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	b5226662-612c-4cd0-90a3-09f75dd42754	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	c86e5223-8208-414b-896f-bfb08ff6b6f2	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	17b4d5f8-6168-40e9-ae1b-e795f48971ed	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	68d96d30-7275-4f54-917c-3cc0bba0e0b5	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	4e804d73-854f-40d9-97b7-b76d72675a88	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	f528110a-0afb-411e-a327-ba222408c203	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	76782c91-0742-42da-9034-59f81deef065	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	0646f558-b946-49db-b885-2e51eeedd825	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	1b9fa8b9-cff4-4077-9bb3-49a355646df6	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	54e1c2f9-cc6f-43b0-96d9-8ca4d41453b6	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	b36cab3f-ae9b-441e-8cdf-d6e7b85bec7c	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	80311410-6609-4329-911f-f6e9f0acaf23	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	21c7c4a2-4a09-4c3c-893a-9b1859caf588	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	504736d0-3c4a-42d9-b326-69d5bf2997fc	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	c3902070-0a29-429c-a0da-c7289f6aa24e	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	a70adb6b-9b8b-427f-bc0a-298ce53671f2	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	1ebe3270-8fb1-4d44-bfc4-f028c53550e1	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	c60449b5-1573-4724-a73c-9c9dcffe4c79	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	8b2a739f-f9c5-42ae-82a0-7e790f25cc77	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	35398804-0d24-4496-9a55-87bea11db0d5	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	076d6603-658f-4e97-9899-adc20cbe704e	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	55da5d18-aa58-4e11-b336-03af4f66e028	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	ece029fe-6262-40ac-80ca-39ce1b745acc	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	c04d939d-58f1-49e5-80f0-3221da1db59a	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	839da72a-756e-4202-906b-6d1dc4a263fe	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	b48b4996-b47f-4b1a-bd5e-a2cc8fab92b0	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	7ecb7277-6d10-423c-a286-1e891cd1a2b6	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	45f06fb5-4437-43b0-b38a-3dc367949390	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	98960006-df7c-4e56-a451-ad51b5af29ae	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	35b8ea5f-f3f3-406d-b97a-af26d7e843bc	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	6eafa6e8-3097-422d-a96e-c6ba2957b3e9	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	6cba1cf2-368e-468b-96a9-d53372291683	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	2cdc28f0-a2a3-4003-9c71-3e73b1f595cc	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	889484a7-bcb1-4910-b9cc-28a83433a468	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	e650288e-a22c-4d2e-9f3c-e183beeb6d1a	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	630e341e-2360-403a-9acc-062e6929e1aa	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	c3d16092-389d-4893-9c0c-ef642d93b91b	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	b8b5ce2e-2430-426f-8cc2-36e873f66539	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	6fb2e2f6-36a8-4971-a66d-352ffe5b5f22	2026-10-26 14:01:29.435478+08
ecbd09b7-62fc-4ae2-a9f1-6517dab42fb4	da44e650-cf58-432f-bb29-2672f67d7cf9	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	843e31a4-9be0-42ec-a07d-4dacc00400b7	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	70c2fff2-f8bc-45ff-898b-2e6723f83b20	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	12379aee-82c9-4147-ace0-6645f3e75cb8	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	b6b500e7-9353-4331-94bc-6eb6db3175ca	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	90a17eb0-6242-46b4-9b55-960791d1d9c9	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	8bc28040-f8c7-4110-a5ae-0fe4d983cef5	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	47550e3b-a7ec-4234-8df5-f7faf2ef7bb9	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	4491822c-0dfc-4d8b-9264-155b6b5c4d5e	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	964b7732-3757-4701-be61-f2a8fa64095b	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	3770a867-0f44-4873-a418-62139e5393a9	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	817144b2-2c06-4541-917e-954b081ae85a	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	2c0f6c33-00f2-4879-bedd-10f35ee1d71b	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	ec81dca5-052b-4b58-9851-6667a27f3c97	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	67d90528-2e5c-4da9-b89a-cc87400b29a6	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	36ce793f-53bb-4756-93e3-b46fd906942d	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	53c99369-cad6-43db-8b02-6f7813dc589d	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	eeec0ea5-873c-4374-a415-3c1d86b58c30	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	294f5260-6c73-4415-9196-d95f005790bb	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	2a9040b6-0dba-4c99-9a13-bc959b53cfe5	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	c31ecd18-bfc5-4621-a780-3bf5b288d816	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	68d4d863-607b-45f2-bcc5-aca4e4516dba	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	4acec583-dede-400f-ae67-8f6a99c4135c	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	be7d0c87-c89e-41bc-bce3-6a29f8c36749	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	d504c18e-b605-4527-b9ae-08df1d8c998f	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	58d47305-af48-4101-863e-e0c6340e111e	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	47b50520-05db-4c39-8b89-72cad268b55e	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	983a05eb-f14c-42ae-a3be-c6d2e34ad1d0	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	f5547113-8057-4ce1-ae98-572d9004b4fb	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	dab34c1c-9858-457c-883e-696dc1d953f9	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	cc174785-b39a-4796-9565-1ce7fe4696b9	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	8d6e736f-13de-477d-8d35-6274ae221c2b	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	0bcad886-044b-4a10-9d41-d6b7632d9df1	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	d943d45b-849d-4756-a0f4-e90eddefe514	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	67831c39-8c38-4cd9-adfa-a9cbec794e2c	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	4fe66c9e-36e2-49b0-955a-17cf9d138779	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	bc3dfb81-dc42-4112-92f5-cd71e9a05eff	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	aa911249-08c3-4ef5-a375-65018744828a	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	5a67854b-b76d-40da-848d-c609d428dba4	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	ca78cc46-4dac-4ea4-866d-5eee21afe13d	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	475ea8a1-15a2-4119-876b-662cef417d80	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	58e208a0-d672-4c93-805f-d2ca15802e03	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	df3da25a-405d-4a20-bf27-ffcb5c6c7775	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	bfe35292-20ff-427a-a6c8-c9fe91fb85b3	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	ff36ec23-af8d-45b4-9a37-efcd0dd4b923	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	c49d284d-a327-4c73-854b-3a74d181105a	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	c502d8d1-2565-4ceb-81e4-3fcfe8df0e49	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	4a3900d4-0018-4fa5-aa07-14664fc15457	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	5e308f32-7e48-4772-8ed4-0a1c1ed848d9	2026-11-09 08:07:44.75189+08
0c000000-0000-4000-8000-000000000001	5e308f32-7e48-4772-8ed4-0a1c1ed848d9	2026-11-09 08:07:44.75189+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	d5fbb4e3-26e0-49c4-b428-bb44eeeb41a2	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	580b1527-90fa-48a7-98d2-f60a2aec37da	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	b047800d-1cf7-4c3c-9942-0a1842b3dd08	2026-10-26 14:01:29.435478+08
95baa6b7-6091-4ef5-a7fb-46c3fac66353	953f9441-6c50-459a-ad7a-80ca20fc0e8e	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	d522e713-a169-4b07-953a-15fac87a516a	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	e4865f32-f0c6-45db-9cc0-a69ad8c23900	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	68b9eb3a-80c1-48e8-9933-7252c8985688	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	6ec53f4b-8f6f-43dc-ac4c-094353ca2e91	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	c84ff030-06b6-40bf-868b-83d05eedca2e	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	71674950-7ef1-4281-8976-529892e61f26	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	309dcb60-cde5-4d03-84cc-6f6c11b8d836	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	3eeda450-f14e-460b-aa1e-7e880db3b9a1	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	5653bd54-d986-484f-aacd-6b00baebfdcc	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	e70982f0-0001-4900-8bd8-0bd41abc85c5	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	65e18ea1-190d-4f51-a8a5-6aeaf5e74b27	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	78fbc412-c95e-4e42-a17a-5773d73774e1	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	172e7fd2-273d-4a38-8edc-1bb039c7c03e	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	5376af21-342a-4e75-a591-1776a8b1c706	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	016d98a5-b27f-4ac8-828b-26343572d93d	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	67d632dc-d8d0-406b-beef-472d3f9164cd	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	9e236ffe-149b-4f50-9a87-4e9814244bbe	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	cd047b78-93b8-477a-8027-eae22e0f49f3	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	35119d75-1d39-474e-99bd-35e2ba2f8aa9	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	2575ddde-6b55-474d-a5a4-9c4e4047511f	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	51022719-092c-4fac-b670-49ac8ab83a77	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	f834bc54-300b-4d0b-8302-8a1f6d2688fd	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	983eced3-366c-4b7f-a2ba-bf7b8de9e9f3	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	f6ff0668-762f-41f7-bd37-fff13fc51d80	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	bc86cc45-56c8-4915-bc36-110f30eab9aa	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	b9651b0b-b17c-4d29-87b5-028e4359567f	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	a26c861d-0483-4a81-bbee-0f51554a92b9	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	503680ee-aa27-4c8f-930c-0b179163309f	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	ce3b5fb1-1ef9-4859-b805-9196c1df7fc0	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	5da3928a-ed7f-4365-a8a8-3fd384658a70	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	8380fdb9-60cf-4b26-8698-e2e41787d085	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	a872b924-9ec3-483b-b750-2db2e38153b1	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	25521bcd-f491-4996-bf43-70c39f3d3d57	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	5bff4f92-a826-4d08-afe4-75fdb9614647	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	2b68bb17-df65-4725-a160-5a44119ec492	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	a9938736-93a7-49bf-942b-e180fce93253	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	c79c205a-84c1-4296-b8dc-f722ac6e4be7	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	e4940665-621a-4cae-bcfc-6eeb6e0cfc6c	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	42fe0562-b0b1-452d-b948-536ed2d536dd	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	14486b97-172b-4b6d-aaf9-2c955e51da16	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	7ae9f8cd-c5ca-401f-9bb7-ddc53b96dcc4	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	39c0774c-1855-45b9-87a8-69ffb3701392	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	e265ffa2-8278-4d17-a1d2-ece5c4e63f9d	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	3e61f288-9acc-48b3-b186-ac7185bfe31d	2026-10-26 14:01:29.435478+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	1733fdc3-eb98-49a0-b0b5-c2bbc2ab3772	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	6bbab1e7-cd92-41d4-8a6f-f1a8f9a24447	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	97fd42c9-f9e8-4f55-b7de-c53a1e197e5c	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	8581a771-d999-4f96-a29b-c9ce95fbafbb	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	3e340190-e9eb-41a0-9151-a90a9a174a15	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	32df47d7-4bdf-4cb2-acb4-78ff37802e28	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	5380f69b-72ce-418f-ab76-d4c6252a92b0	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	da10422e-6327-48c4-995b-e6106a1ad030	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	dfd84fe3-f42d-4af6-b45d-8d6f24fc6691	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	7c7c913d-2347-46e0-9129-5c8c7963fe47	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	58c402e8-0edc-440f-b449-72f554a4f09d	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	8e2f0cd6-e10f-44a1-ac66-c2372ff9aba7	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	15ef228a-4ce4-4914-86d4-8743320f3c45	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	17764847-06a3-481b-b84c-fc64ce0ef960	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	d21829fb-a0fc-4cfe-8850-8b329dd00409	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	15fc7f5e-8b0d-4e4b-805e-fc08787fb446	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	fac82fcf-b132-4678-9882-5fe21ee0a9b5	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	3f1e4adb-0095-49f3-a87a-b917419410d7	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	3435f0a9-c63f-47fd-914a-0157b0af83be	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	318bc331-919b-460c-a42a-9294b5147872	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	aa3a5070-12ae-4a0f-9d18-f57aad030a37	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	a50acd9f-fb68-4812-9136-fa6bd5afee86	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	ec2d7f67-c805-4be2-81d4-108cdf7c9310	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	a5a62714-4c98-4dd2-b023-7d50bd156166	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	6040a799-1c4f-4ec1-8953-645540980bc1	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	ce88b7df-8249-47be-83ac-cac286a47624	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	367957e3-36e5-42a1-8830-ff1068bcd649	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	aeb94a79-3c08-4948-87e9-a404056ec540	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	cc1b9db7-b1bb-4294-baf8-72de4c2b4ea0	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	0ad56aa2-270a-447a-bb55-5c3e5b740862	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	363100c6-ff27-45cf-83c0-05109bd668cf	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	457373e7-b6f6-40da-aa8e-520c0018a26d	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	ff80ed49-ddfa-4b93-8acc-34a9bf186da2	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	d014f331-6483-4671-bc41-6236b06ba37b	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	5fad1a87-658c-4894-9772-72a1b0731d45	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	0eb279fa-b6c6-4e2d-b050-82ea0631c1d9	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	4798d33d-62c5-4150-8235-63bc6389f7c8	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	6ac3d874-41b9-469d-a60a-b4bf8512a7df	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	fff2deec-1d88-4469-a790-ece3eb6a29a8	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	9d3d0448-8f66-4dc7-b0ce-6adf9c45bf45	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	c3ab3508-f352-4528-b837-d5bbf978d697	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	1e38a460-8504-4fe6-b19f-ac4155bb42bd	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	aafd9e68-1a98-4a6e-8174-652e4f296ace	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	d2bc12c6-ad64-4a54-b9e0-f7aa59ecf58d	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	5dd50086-a083-44e9-a7ac-78e011241957	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	19dd599d-6e4f-47ce-a045-d6df8b2a663e	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	a9b0dae7-d770-4ed2-bd96-52b643051248	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	b7dd8d6c-518c-41df-9dd5-4a36fe4bc217	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	43233d63-bf7b-4920-9c63-d3dca088742b	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	32f4462f-b2e2-4436-880a-b5aeebe6dbcb	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	c9bff55f-fad7-4e8d-8141-7761f0291798	2026-10-26 14:01:29.435478+08
abe01221-93fe-4696-8be4-f337165cce8e	a7a34dc8-f4d8-4329-83ef-fb0382eb7950	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	2e2c8722-c8fe-49c8-8959-4df4239c9044	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	2bc8a1f7-ccf4-4937-bb7f-6200e07cb8f3	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	98339e25-73b0-4143-bd7d-be833f6011e0	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	a91e3a12-46a8-4119-ab8a-63a67b5f7d23	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	2cfba3c9-692a-4b93-8aef-fef6c03c333a	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	e38e4a7b-a918-48d2-af8c-4b12851b65cb	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	fbb8a65a-83ec-4eb8-a937-378ec1139263	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	c9f30bdc-2c5b-4713-b2df-5a889d5a5380	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	2edd77a5-3126-43b1-ad18-64ac1bb8ee70	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	5c00d601-fd62-409f-882c-8ffa89aafc4f	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	3da0b417-e73d-48c0-bf5a-4d3dcae4bebd	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	1a27be22-9a1f-4054-ab65-7779d57381f3	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	9e9a26e7-d2b1-4fd0-bdd6-9361ffaf8ef0	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	6adcaa08-fe6a-4b5a-8c7b-d44c94557fd0	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	55ceca93-d6a6-4f84-8786-953df31dc4a6	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	5c69b68a-0953-4860-842c-88164ea83776	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	b5957552-9b9a-4682-8e7c-08dc078cb3cc	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	8bc2a8d0-28e5-4e0e-b893-865456e159f9	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	17b9e9d6-8ea2-45b3-bcef-c5b9ebe9a6c0	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	3c8ae7d8-f5d7-4dbd-bbcb-e9399400e62b	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	a141f05f-088a-458c-90dc-7cf15f4b9feb	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	f939c582-9bb4-4641-bf88-72a01411c863	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	659ee807-6bb1-40f7-a957-8ab515a48f94	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	25709809-5abb-4ac8-9d35-c60a26c4be23	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	eb46ecc2-c83a-4dc3-a2c5-28dc68132cc3	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	958a344b-8b88-425d-b5cd-f73810680d6d	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	461ffd40-0094-4112-bd63-c6dca34085d3	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	c4a88d7e-87df-4141-8f25-d74773a2ddd2	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	14942e67-ae28-4bf2-a9fa-f67cd8f4767b	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	94690540-217c-4346-bcc2-c1f6c694662e	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	6844c638-1130-4954-b776-32a5ed83bb23	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	350c7790-b0fd-412a-86ee-e2defd30bcd7	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	569b856c-d12c-4b6e-aa8b-651f569de24f	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	16b0291b-1539-4f24-ae8a-c45414c36510	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	01de6495-85a2-4eec-be1a-a69efcdf99ea	2026-10-26 14:01:29.435478+08
0c000000-0000-4000-8000-000000000001	af0c2a4d-126b-4bbb-9a77-d647352fb734	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cf75fe11-f4f8-491d-8394-1980b2f2f94b	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	bc627ce4-1f81-4575-9011-ce8668db061b	2026-11-09 09:45:24.446397+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	469185a8-8a14-4cd2-ba82-d1ab5241bd57	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	013eb45f-c4b5-4aca-b0ff-e5914bf89ee9	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	a40e54ed-3d99-4dbf-a2e7-12ca5b9fec7b	2026-10-26 14:01:29.435478+08
e886aca3-bbec-4c39-a1ca-28367293c2ce	11083df3-e024-49c2-a9b7-812aef55a882	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	5eca91e0-af50-4999-9a05-2fd8d696300e	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	9924038f-fa8e-4be5-bff6-9073368a5471	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	3fbf4e67-5d50-41d9-bb14-61ab66b74fd1	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	e388daca-c0e3-4396-b400-5e06cfa67472	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	c633a0b8-53af-4170-b568-a8657b2a5c04	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	9a8df57b-ae58-4af7-a554-747b426f071f	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	1fc6e8a0-b3bf-447d-869f-e61400ca395f	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	c8f7528a-b746-468d-998a-69d9fb77f8eb	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	11f35f26-18f0-4a87-ad53-a19e182f301f	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	d4b29c75-7642-4342-8e5b-6b7e0c50ef3c	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	7d2623e2-e4e7-439e-bdfc-6440b5bb9c56	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	a8bfdb38-dd1e-41b4-88ec-8189403501f9	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	98a20992-7a69-4e57-8a16-fdbb2b5f700b	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	27cb8d9b-1d9b-47cb-877d-75cd6773ed20	2026-11-09 09:45:24.446397+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	de3e8777-42ac-44c8-9a56-68f8e6b22f76	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	ae8b9bbc-9874-4909-a16c-0aa51675766d	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	09275bd7-6be8-4953-8df1-9b3ed697a4de	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	392073c6-cc2d-45c7-8020-881460c0d9df	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	2fe35431-9313-4008-89a1-14c2dca09f89	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	ab9624e5-b9f6-45b8-af1b-009ede398d86	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	5a4e7fc0-6fab-499c-9a08-e852a78de7c9	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	78de2802-d14c-438c-a5c9-f39a20ed8bc8	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	f7110152-0258-4661-9227-70eab5916f73	2026-10-26 14:01:29.435478+08
0c000000-0000-4000-8000-000000000001	babc3cc7-e344-4885-8f20-b9f9d9939240	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	46cddfb6-5882-44aa-b11d-d1aee715439d	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	98a20992-7a69-4e57-8a16-fdbb2b5f700b	2026-11-09 09:45:24.446397+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	8894b09f-abe4-4418-8a75-567c2d127099	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	8d62857b-9efd-4d30-ba34-02e17f821fa5	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	2ca05c4a-9100-4313-a735-d4f3c5e75924	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	19b54313-877c-4b9f-ad0b-5343a9966292	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	3ae80f7a-9350-44c3-bcfc-164be9cbadbd	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	27cb8d9b-1d9b-47cb-877d-75cd6773ed20	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	babc3cc7-e344-4885-8f20-b9f9d9939240	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	46cddfb6-5882-44aa-b11d-d1aee715439d	2026-11-09 09:45:24.446397+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	2907d0c5-27f4-4ce4-b6fe-334626688c45	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	97297d4b-9179-4391-bfa0-9d6671729e78	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	7b64ace7-aaa3-4b7e-b0b1-f3d6ae9db4b4	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	b9708b1f-0b9c-41b3-a699-5d101458ee70	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	1deeadb4-e989-4e07-9d6c-b033e2989538	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	7ff89f7b-af75-49bd-a509-95c599b177e7	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	131d6ee2-495c-4852-9a3a-42b57690ee27	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	bd763c66-dcd5-4dd2-89a0-9aac5980c719	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	ec97e8b2-337e-4211-a6fa-c991f8f27326	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	68b087bd-6501-440a-be6e-33d99a78203b	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	06b5af3a-8568-46af-9ba9-8a4c2872ff86	2026-10-26 14:01:29.435478+08
5c3a1249-d754-4c1f-9ca4-6122291ecc9e	0ba75724-da4d-4646-a6d4-e0131f922587	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	02549094-9064-43b4-9b14-4cdd00202012	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	5bb222e0-7245-40fe-8b23-0c1cf908eb79	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	ba312a07-1dd6-475a-bb8c-b922d4188a94	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	af0c2a4d-126b-4bbb-9a77-d647352fb734	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	b3f4384c-986c-4b35-aad7-6eb34def291f	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	cf75fe11-f4f8-491d-8394-1980b2f2f94b	2026-11-09 09:45:24.446397+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	2253dc7f-c302-4a74-af27-b5fdb26f6722	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bc627ce4-1f81-4575-9011-ce8668db061b	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	a8bfdb38-dd1e-41b4-88ec-8189403501f9	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	bc627ce4-1f81-4575-9011-ce8668db061b	2026-11-09 09:45:24.446397+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	5c8c0ef5-33bd-4141-ab4c-1314cef089c0	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	af0c2a4d-126b-4bbb-9a77-d647352fb734	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b3f4384c-986c-4b35-aad7-6eb34def291f	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	babc3cc7-e344-4885-8f20-b9f9d9939240	2026-11-09 09:45:24.446397+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	d2bd2922-2739-40d7-b7b9-f9399cf4eb5b	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	fb14a52b-6f41-4333-a3f0-ef935bc6adb8	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	079581ab-d7d3-4719-837d-33ce4bd4ddd0	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	ee2f55e4-b0d4-4e23-a64d-296cd87825c0	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	eb77fbf8-089f-402c-b935-bd4a911fcd3a	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	404e380b-5e2a-4b81-a362-c18e4059b0fe	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	d9502659-74a5-4b31-9e5e-f05bf09bc61e	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	3c2283da-8b6e-4f71-8174-e527becff9cb	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	7a579dc8-7d46-4ac5-a209-b3cce98718e6	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	af0d82c8-c095-4d86-914f-b86216b9d8b7	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	37197ac0-1809-40b4-af13-a58b5cbdc795	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	a9b5bd16-c459-4e1b-b8cd-b75499c0212a	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	fe7160d4-8588-4408-923d-c75e27c32d66	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	c59c8a73-c1b7-4872-be60-0053197e9b72	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	234f4124-6147-495d-8c73-343b542cdf98	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	9e73093d-8c11-4a8f-a20f-354b0fea42ea	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	13421cff-3527-41a0-a28c-b70f1a3585a0	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	96ed4ac9-5cc4-44a8-ad49-86372a73425d	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	e72535d1-26f5-412a-ad4c-44e22dd37aa7	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	e5bd49ff-31a1-4af8-a96f-e559f6ab56e5	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	6c903dd3-55be-4942-b8d7-6acf379830f2	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	e7ead4bc-4a61-4bba-a2ac-ed3c2a127f53	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	a5ede0df-cf02-42ea-ab96-99595da8f88a	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	8aa7d8ec-fc90-4515-9bb0-fa5c9b01c59c	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	2c9b3eca-e592-4e7b-8325-fb0e858ab64e	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	53b99751-94b8-4812-bb66-a9a6184afb24	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	87420d52-ba91-4e2f-ac58-943add2a94b2	2026-10-26 14:01:29.435478+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	2ddb6ac6-ffc2-495a-8ad2-cde85e51805f	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	9b8ef6b9-fa20-478c-9c07-70d5ef7b77f4	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	d0e130c7-e561-4c51-804e-174c1c214acf	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	0219820f-acc8-42e8-9cfc-076678845d8d	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	e3d3c5c9-ffb5-49f6-b5e1-28a6fd63d729	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	062db79a-115b-43e0-809b-c61cbc101d08	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	acc141d9-8527-4302-b086-286cc8b4e26d	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	e1f9389a-5b46-48d6-8f4d-b6acda13224c	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	bef50f16-48fe-43ee-b602-ce0648d60bec	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	a2235068-27aa-4cdb-8186-8dc5f34b9906	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	b21307d2-04bc-47ad-afbc-5f3c63516e69	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	0131194a-d752-45f5-98df-aa7d4b966495	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	f3feddd3-d875-41b3-88dc-45b530338100	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	2511b976-6160-43e0-8fb7-f481aa7a942a	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	b6a8bca9-2601-48f2-a84e-6c429ad28b57	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	32931da2-7f1b-45f3-b8b6-693c85a78214	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	c5f852c6-3ce8-4733-906d-0b3219038030	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	64af5f26-55bf-4344-b773-ed05b9343ddb	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	fcd2b07f-1bc1-40a6-980b-38e7c50271b1	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	3599d649-04de-456c-aff1-918b055821f2	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	2895206b-f2a0-46e4-9591-6496e86ee998	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	21734117-630c-41e0-9254-f6f0c413a60a	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	a5d09c5c-fcae-4ac0-a12d-cb25599807ee	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	b9e62243-f9b8-4fdd-b1bb-505a40ea5af1	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	91ba6a97-484a-4a82-adf7-75311a7e1a1c	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	0266701c-10e1-47d2-a950-556be5d801df	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	7ea4ad92-2ff1-40b8-b71e-a22a01ce162b	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	d5974ebc-b20a-4380-ab81-6bd5ece9eb69	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	6fe0fa7b-f293-46a7-af89-76586fb43a88	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	5a117c91-85bc-4953-9c6a-e8796aa088eb	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	df097ebe-254d-4429-89b7-abc8021be8b0	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	9c0cbd06-1385-43ff-9ab9-693e26af462c	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	dc3b3534-41b4-45e5-9e98-0fa92cc64014	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	414ef850-468d-4775-8f69-9d6b445515f6	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	66ba4a48-7630-4ff4-8074-b22f3cd667a5	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	f0bbf9aa-9a56-42dc-8211-8092a0c2c4e0	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	76f15e54-cbdd-435b-9674-a382aecf952d	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	37359d83-d5f8-4bd3-9472-0f2faf5f04a1	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	55ea4b4e-06b1-4c6a-bffe-62f11d3b8f37	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	6f027480-1c78-4d9e-9968-2b25ed52d404	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	c8f60ebc-38df-414b-83d8-01e551347e90	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	3b80ae6b-0c62-486d-9466-d47f9f9aa61e	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	bcf0e340-cecf-4cdd-9931-6a530d48f6cf	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	817f3abf-8b60-4e41-ad3f-116b3491cc2f	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	afabc962-6aec-41dd-b62f-15d35f06fb21	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	893a3899-6db1-439c-b6e6-b348a0ce750f	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	c1f84f46-fb11-4f6e-b482-8d79602426a0	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	b3c44503-8d14-4940-b8ff-92e12f0330d3	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	613aa7b0-bff6-4274-8fb0-d055835f5b67	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	e608a054-194d-4b03-bbe8-b136d4e563ff	2026-10-26 14:01:29.435478+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	7599c635-56eb-4596-843d-8bb7f9e90030	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	dde1f05d-951b-437f-83dd-ce3488c922aa	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	366229bc-ff89-4a2b-809b-f72dcd98cd64	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	37c957c2-94f3-4a92-a99c-c070a1e3e0d1	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	1fb8e26f-8700-4ad6-91a5-6d670223264e	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	7b7c1cd5-c3d0-4e9f-9a16-277e62c997ba	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	49eb6481-e64c-4569-9118-78c24d76409b	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	29ffc53c-b93d-4268-ad7c-d43449f79622	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	e8187b78-17b3-4db9-bded-6969db485bb7	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	02abd9e0-faf0-4ad0-9a6b-b11402fcdaec	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	e12ac640-497e-4877-8911-dc8b8429499c	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	0fc2eeff-f6cf-4b1e-83f6-87e5590fb996	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	5951879f-237e-4d16-aaf8-f7b2f91f760f	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	83d6a617-bae4-46f5-9d29-c91172b29eb2	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	9370dc2b-11a8-40a7-b7c9-ca3c512b9969	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	f1eef12a-224f-4bfc-b4c0-78f0f4365717	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	7284c60f-61b8-4358-bfff-1ad0a28766cf	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	7f10e653-23be-48b0-a3cb-a06e0898151b	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	4f11c6ed-7a00-41bf-8224-46e13b5d9bad	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	d84664ce-ae82-49f5-8a53-05c9a4d7cba5	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	23c50969-a410-49a0-96a5-1817ece1ba47	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	cde49d8a-9c6e-4c97-9582-9b2f9af19916	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	ec945b09-9169-4bd6-84b6-bf413e8df431	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	08a7eafd-46a2-47d1-a482-28f7a6d1d6ee	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	1d6ce285-d577-43c6-9c72-b9fdb34ad41e	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	2a2274c4-9add-4720-a052-440bbf48ba4e	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	d5b39d10-bdfa-4982-b45c-1bbf17d55eed	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	9be516cb-913e-4823-b57f-3b641577bd45	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	86bce5a8-1d56-4650-89b4-650ece7b4c2a	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	7cc0f634-61d1-4ab1-843b-841399c92dbd	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	cec60167-5fd1-4f27-9897-b722fb54534e	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	2583dd2f-8591-4c95-b602-372feb3e8477	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	59202f74-f468-4ec3-8819-b1c1e2739762	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	e0e6b4a3-5856-40d4-a34d-4d77e3506b4d	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	c640d369-53ab-4b61-a818-95b60a1b58a9	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	b322c847-46f8-4169-ae78-162b4d5f944d	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	970fbbab-5287-4b95-96cc-6e703f3fc988	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	8918e044-f0c6-4981-8112-de8427367969	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	f4e6500b-b196-4ab8-97c6-316000f71f2b	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	8378ac17-4000-477b-9a81-cb34ace6c9ba	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	4853e6e1-0c01-4cd1-8321-9c769e12735d	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	00080d63-f28b-493c-8e8e-f0f929f46329	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	a6aeb533-db2e-4a7f-9fa6-cdd0bed5cb07	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	6d214a03-6461-4b89-a2bb-5429ea0a56e7	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	98a20992-7a69-4e57-8a16-fdbb2b5f700b	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	27cb8d9b-1d9b-47cb-877d-75cd6773ed20	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	46cddfb6-5882-44aa-b11d-d1aee715439d	2026-11-09 09:45:24.446397+08
7ef90500-6e0a-461c-8e2f-031feb086d85	49cd8606-84d2-4b74-96e8-71c6a27cdade	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	88e6c1bb-025d-4320-8939-2616f71dcd07	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	ec557fbd-dd4b-426f-9802-08f17e53de5b	2026-10-26 14:01:29.435478+08
7ef90500-6e0a-461c-8e2f-031feb086d85	7859bae3-2f07-49bb-9a0b-95c2f3d44fc1	2026-10-26 14:01:29.435478+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	2bc4a409-d6fa-4711-8ba4-d42ae723a6fc	2026-10-26 14:01:29.435478+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	00db48de-8483-4b5f-8e00-e2c53a57a33a	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a8bfdb38-dd1e-41b4-88ec-8189403501f9	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	cf75fe11-f4f8-491d-8394-1980b2f2f94b	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	b3f4384c-986c-4b35-aad7-6eb34def291f	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	225674f2-6e83-4c3e-8a09-a3f6caea07d1	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	00306d29-c80c-47d1-93a8-2d9192803637	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	de52b259-81b0-45c1-9a68-dd98e4fa523c	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	9bb1e76f-9780-4648-b2ed-7b8bc6671bd9	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	08ed4910-224d-4125-8c3e-dab56be8577d	2026-11-09 09:45:24.446397+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	9738a126-0112-4e48-a33e-c03f1212713c	2026-10-26 14:01:29.435478+08
4067eaab-92bb-4c68-b572-fae02796cb27	31095c25-6bab-485f-b7bd-a2e15eb7a0e1	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	225674f2-6e83-4c3e-8a09-a3f6caea07d1	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	9bb1e76f-9780-4648-b2ed-7b8bc6671bd9	2026-11-09 09:45:24.446397+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	b7c7443f-19c2-448d-9acb-82a4770f626e	2026-10-26 14:01:29.435478+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	30938453-4723-4d6f-967f-4eb7366bf31f	2026-10-26 14:01:29.435478+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	eb0379d6-cf5e-4138-8296-1d3d26797ce7	2026-10-26 14:01:29.435478+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	abb57291-1b9e-4528-8aa8-ce1173490c6a	2026-10-26 14:01:29.435478+08
2d1e7e21-dd42-484f-88a6-a7fe10d43825	a69ff633-b1d9-4eef-b75c-7d4a19e53275	2026-10-26 14:01:29.435478+08
0c000000-0000-4000-8000-000000000001	00306d29-c80c-47d1-93a8-2d9192803637	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	de52b259-81b0-45c1-9a68-dd98e4fa523c	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	31095c25-6bab-485f-b7bd-a2e15eb7a0e1	2026-11-09 09:45:24.446397+08
8f4d643d-905a-4773-8e26-082b78d9e329	1948ee1c-63f3-4172-91b7-4e3b6565f872	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	1ed32704-aa8f-40cb-9575-06190a597154	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	44be4839-b13d-4441-8fce-f63d7c1134d4	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	81bb7faa-3dcb-4e54-83bf-4ce7849f995e	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	c562c184-e015-4546-a582-0c7fffed8947	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	44c473b2-e325-4f8d-8c1c-93837945a6af	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	75ac5cce-e9c5-4544-8d5b-72c1fc3622d6	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	24759246-4008-4e6a-84e1-b2abf02cbde3	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	d5d17649-01e6-4d2b-b7ee-2c2275226520	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	d1885cc3-f822-4c3a-ade5-bea5c3116d2e	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	d19ae1a8-c61f-41d4-a91f-91647b934f13	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	bf2b5ab6-6669-4c69-b4ab-4ec6d2f1ec98	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	80457de9-b5ff-4126-8b96-71f54746fd40	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	bc09003b-7994-4375-8ded-88cd26594627	2026-10-26 14:01:29.435478+08
8f4d643d-905a-4773-8e26-082b78d9e329	d84d44a6-19ca-4bca-93e8-8ac6c47efe95	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	08ed4910-224d-4125-8c3e-dab56be8577d	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	31095c25-6bab-485f-b7bd-a2e15eb7a0e1	2026-11-09 09:45:24.446397+08
0c000000-0000-4000-8000-000000000001	08ed4910-224d-4125-8c3e-dab56be8577d	2026-11-09 09:45:24.446397+08
8f4d643d-905a-4773-8e26-082b78d9e329	a2ffd5d8-bb3f-4208-935c-119ed2595800	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9bb1e76f-9780-4648-b2ed-7b8bc6671bd9	2026-11-09 09:45:24.446397+08
4067eaab-92bb-4c68-b572-fae02796cb27	225674f2-6e83-4c3e-8a09-a3f6caea07d1	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	00306d29-c80c-47d1-93a8-2d9192803637	2026-11-09 09:45:24.446397+08
8f4d643d-905a-4773-8e26-082b78d9e329	d7383cfa-0340-4b30-9deb-821749cb6652	2026-10-26 14:01:29.435478+08
2ad18844-4410-455b-b26d-f8dcdb10db09	de52b259-81b0-45c1-9a68-dd98e4fa523c	2026-11-09 09:45:24.446397+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	6cb110b0-75f2-4504-aeef-048e1187ab71	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6cb110b0-75f2-4504-aeef-048e1187ab71	2026-11-09 09:45:24.446397+08
1e637734-778d-41b8-9638-60b13c44be9d	ca97156c-f828-42cb-a36c-a83bd2147360	2026-10-26 14:03:20.555078+08
1e637734-778d-41b8-9638-60b13c44be9d	219e704e-8616-401b-aabd-dd48d3b13a6b	2026-10-26 14:03:20.555078+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	bdd7cae3-e309-480d-ba9b-1602e16dac04	2026-10-26 14:03:20.555078+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	fd02f665-2a01-4829-ba04-ca3e7c9de378	2026-10-26 14:03:20.555078+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	533497ec-ea83-4f69-b0c7-fba74522f8a7	2026-10-26 14:03:20.555078+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	4f264a35-cfb0-4c52-889a-44590b9b8b8d	2026-10-26 14:03:20.558662+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	369009df-a3d0-4990-b50d-f0b02af5efd8	2026-10-26 14:03:20.558662+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	4f264a35-cfb0-4c52-889a-44590b9b8b8d	2026-10-26 14:03:20.558662+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	369009df-a3d0-4990-b50d-f0b02af5efd8	2026-10-26 14:03:20.558662+08
2ad18844-4410-455b-b26d-f8dcdb10db09	73e091f3-f678-4548-b7d5-370e4b486655	2026-10-26 14:03:20.591427+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cd89f3d7-6ec0-45e7-871f-e62097d491ea	2026-10-26 14:03:20.593971+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e31feacc-4a30-490f-b173-375ead7b2fb3	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ae101460-ef29-4327-8c77-18b4bd109320	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6b9f15b6-1c00-429f-9c54-e192facd59e6	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	573ad993-551d-443d-954a-20e44767d5cf	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bbc4dcd7-99c0-4148-8915-e06fc6cbc833	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eabbf099-1303-4434-9bca-17652fa22ca1	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d3d4b9d3-2140-4d76-bb32-bce236bd4f0c	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	23c6f3bd-dd65-42b3-b57a-c485c70558c2	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6f79971c-b230-4a92-ba13-69188108309c	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	47923145-e4be-4350-ac74-8cfe890533b2	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	24632f0f-ce01-4386-bb3e-2eccb5bcc920	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	67dfc397-b2c5-49cd-b7da-8d8bbc5122eb	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1f322e19-0ff3-483a-81dd-304c23282b27	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	15390d64-f3c0-4127-b008-ea0f1a2bf690	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c41cfb69-6e61-41da-8650-81d3dc4e1fa8	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	223105d7-e76b-43ae-9524-0e02ac5a1ac3	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6d7a4023-6492-45a1-a8b4-9682b52126d8	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9c8c8b63-6f88-461a-a172-dee0ac14cc51	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8d98bc0f-fa2a-40c9-9116-a41b7b08c66c	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	88c6b68f-0c2b-4a68-8a48-8672efe0a013	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1cc56556-0648-462c-9730-5686c0264e66	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3ecb2792-67fa-4734-977d-c3b40ad5d05a	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	64dafa81-85df-4596-9061-9557146b7382	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	86a4d0cc-cfe9-406a-b80c-e1850f264de3	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fbd5c768-6d9f-434c-9ff4-d98bb80277ab	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a7e632e5-fe29-48f8-aea5-67fbb2ef7369	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8a68c851-2105-4a36-bf67-0eab421b8582	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fd2560b3-6d67-4522-a0c9-4f5edd895df5	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	39f25038-14d2-4123-824e-fc20fe6b22f4	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5b118c55-e72b-4dbb-9aba-8e716e08a6f7	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4f18c700-e7a0-4547-9232-a280ed8c2df4	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	647b6492-8b28-4989-85bb-df7223821bcc	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f3f0981e-26e0-4cf8-b9a7-c7b4d8615cac	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9cafeb0e-5448-4467-a62d-742dad34cedb	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b370ebcc-ce80-4528-9bfa-2b387bf6ccee	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bf5c2543-ddf2-4d0f-a7e7-cba992ec3127	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f3fbad59-003b-4dfa-80d5-f73a0f708650	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	383db516-cca1-486f-9bd1-7550cea844a7	2026-11-06 20:35:21.825245+08
0c000000-0000-4000-8000-000000000001	6cb110b0-75f2-4504-aeef-048e1187ab71	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	707b0352-6829-4f0e-8609-66b370c98a17	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b7d05e03-a561-4d67-8168-90ab4b1cf04a	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0d971516-47cf-4ca6-ad37-2a8724a2dfe8	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	48a2f41e-3f20-4db9-a75c-2b71971b1f2c	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	89f6fe83-a512-4c96-b256-f4f956ea0c08	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3dea6223-95dc-4a61-9d64-d2551968590d	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	30a979bd-a09e-482e-b51d-8bd2763e449a	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f0f59552-3199-4dac-8b6d-6df0b32e6a9e	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	23e5b4e4-352d-4dab-86cf-df4a1ccd8380	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7f0ddcea-c48e-4747-af7c-ad08517c247e	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0d77d1a7-c5f6-48b1-94dd-e987285c537d	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bbfc592d-499c-4483-81da-a0c5ae958063	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4b583b8b-e9d8-4b4d-ae49-402c1b14e569	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5fd9bd0b-5d5d-4bc1-a245-6d8f2217215e	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	69505033-3cc0-40db-a954-afe956723692	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1875af07-a87a-4ddf-907c-de3e12d9b434	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	46763a8a-2429-4510-a825-2f8a0b7c9908	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	36bd5c40-d171-42b1-affc-0516465d37ee	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b7923c83-4e59-47ea-b96d-3a67d3ac923e	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	70b849cd-5cc4-419c-b14d-5c256dfe7a7d	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7badcf9a-2b27-4b35-9c17-6aaddd9eed8f	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c96f19df-d062-408d-b5fd-05fa72cb465e	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ddeaad4e-f897-4226-8364-46af22178aab	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	42010586-8561-4fce-83a4-863e637a6d9c	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	33952e42-e03d-4b19-91a2-0d953fe6e1ba	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4f917038-fc9c-4c90-94e1-250df4bda5b2	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	42391cd3-3470-4978-8e11-1bac98bcd0a8	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6c391362-1d63-4cc4-94d0-96bfac0849a8	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8147ed19-ba6b-4bb1-9d49-160bb1e9e2b3	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4b0fcf9f-0416-419a-9861-b20b5c7153e3	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dc7c3a71-fb90-426b-9703-4404f58c01b0	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2acd48cb-6ffa-4391-b1a0-b66876f6505a	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3b664429-cf41-4e2e-9e7a-46c95110c6b4	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	279f9b8a-1713-4a00-bda1-34fb4cb27226	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	88de0358-05fe-4c33-9bb6-300af3cfd748	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c9f6d494-47b2-4f83-940a-5929c78a3401	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	84313eef-a7a7-4306-8afd-9c95673a1d8f	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4e3e7c14-1079-42cf-ac2d-b66f531cfbed	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e3f9406e-9950-4ecc-b6a5-fb64b10fc677	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	54a55151-62a6-4c46-bc65-7a863f051b10	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	551f3b81-7e55-409a-af7e-4f51816229a8	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9fc43219-edbe-4479-8a2b-8462bb644459	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	611bd0d1-e9ae-471f-bc7e-ffa776ee3fcd	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4e77bd6b-8e16-4a7d-9875-4afb75c46c8b	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1eb391c1-df41-4f4e-b8f6-489bf1c65626	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4416b533-7f9b-4c0a-8fa8-daf56d407a90	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a870eef4-cb4a-4870-b330-1d78f1956c05	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2c624c3e-59d9-43e2-92a0-994ba529f25a	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	48c9ec2c-ba09-4f1e-980f-6434bc4bf30a	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4a5a6390-6630-47ad-b5b1-ae88037dc587	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3202458d-597a-4eb8-b9a2-29b98aa25b6f	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7d8ddd4e-5c73-4ae8-ab3c-215d18a0d4fd	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3fcd6460-d9f1-4496-804f-14597ff7620e	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f20b3f2e-e6cf-4e69-ada7-ecf24915ec1e	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b78d6f35-ee92-4831-8283-3fc3eed905d1	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bd24cb01-82c5-4851-9f7c-d1319dd2effd	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	379fd337-d4f4-4bb0-ad9a-dbe2268edacb	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f36b5cdc-cca4-4115-9960-a4a8abe5c98d	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ea8b4868-7bbf-44ac-9e79-977f9c5fb5b9	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	91c54e37-7f62-4822-b194-28ca25f55062	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a2a9ea71-0d6d-4452-aa83-aa55f41f20c3	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	848d1b52-bc4f-4f2e-ad73-29df82f5bfc6	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8e9531b5-f234-468f-9a25-5a8860701109	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ec93d7ff-3b95-46de-b8a9-512cdd524861	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	04f106e2-2975-42ac-a144-b62a0ae5738d	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aad113ba-a3ae-43cb-adec-2afe23519e7d	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bd3288fb-2960-4be5-8776-dbc02cb9ccb1	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	188474c2-34e8-48ae-87ab-fcab345b9b95	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	907d69eb-3590-45be-a28e-b391718c6e56	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	33b6bfb7-6c9f-4e4d-a756-4f1e86587c6d	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fee722ff-21b6-4f65-87fe-d67e7e9d2576	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	72c5e40b-997c-4c27-a210-7397eef54dd9	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	07f1cbac-a321-4bc0-b6f4-fdf803fd57ae	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2e94c2e2-6bf2-4c3a-a839-77f4e17e3070	2026-11-06 20:35:21.825245+08
0c000000-0000-4000-8000-000000000001	848d1b52-bc4f-4f2e-ad73-29df82f5bfc6	2026-11-09 09:45:24.446397+08
2ad18844-4410-455b-b26d-f8dcdb10db09	37e6e627-364c-4bd5-af58-6bdca0b8a847	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5d267a0a-ce17-4427-a02e-0356cac077e0	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	81286431-6731-45e0-b874-4cf1bc1caf0c	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	24eec346-bc4b-4387-ac07-b3f6c7e596ee	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ceaf56cc-bbbd-459f-9cbb-3a1e77b0bde3	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7ee28d50-4c03-4515-9d91-3eb71d4eba53	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ee6c4fa8-797b-4ed0-b6d2-7f78d2fada20	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fd8abaf6-06db-48a0-bdf6-0fe14b845ad0	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a8a2fe5f-7a86-4010-878f-187b93a22442	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4f349891-bdbf-4941-941d-08b4c40ab301	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3edb7f96-bb99-464d-a749-7676069ef2c6	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e052f81b-07dd-46fd-ac73-f638214ecba1	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cffc5f46-3d00-442f-b5ba-4dc70f767179	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	136000bf-b5c3-426c-80aa-bed1cd06b968	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	34c08f35-a24b-4235-813e-67b2c4bdf494	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	32c39d9e-b7fb-4923-b064-c64b41e43276	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8e4e60b4-66de-4373-87e6-00ebb5ba47fe	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0b2ee1a8-0ef7-4361-858a-19d68e5a5a11	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	64dc19d2-3c93-497f-ae14-38c0d1bcb94b	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f9a8df86-604a-4080-a489-df804759ebc4	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0c751837-3a89-4398-8cca-be3ec545f3e7	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	e31feacc-4a30-490f-b173-375ead7b2fb3	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	bbc4dcd7-99c0-4148-8915-e06fc6cbc833	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	eabbf099-1303-4434-9bca-17652fa22ca1	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	67dfc397-b2c5-49cd-b7da-8d8bbc5122eb	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	223105d7-e76b-43ae-9524-0e02ac5a1ac3	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	9c8c8b63-6f88-461a-a172-dee0ac14cc51	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	8a68c851-2105-4a36-bf67-0eab421b8582	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	4f18c700-e7a0-4547-9232-a280ed8c2df4	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	647b6492-8b28-4989-85bb-df7223821bcc	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	383db516-cca1-486f-9bd1-7550cea844a7	2026-11-06 20:35:21.825245+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	e9a786c4-1f7a-4390-9308-b38c970672c0	2026-11-09 09:45:24.446397+08
1e637734-778d-41b8-9638-60b13c44be9d	707b0352-6829-4f0e-8609-66b370c98a17	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	48a2f41e-3f20-4db9-a75c-2b71971b1f2c	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	89f6fe83-a512-4c96-b256-f4f956ea0c08	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	f0f59552-3199-4dac-8b6d-6df0b32e6a9e	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	bbfc592d-499c-4483-81da-a0c5ae958063	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	4b583b8b-e9d8-4b4d-ae49-402c1b14e569	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	69505033-3cc0-40db-a954-afe956723692	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	1875af07-a87a-4ddf-907c-de3e12d9b434	2026-11-06 20:35:21.825245+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	46763a8a-2429-4510-a825-2f8a0b7c9908	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	36bd5c40-d171-42b1-affc-0516465d37ee	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	b7923c83-4e59-47ea-b96d-3a67d3ac923e	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	70b849cd-5cc4-419c-b14d-5c256dfe7a7d	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	ddeaad4e-f897-4226-8364-46af22178aab	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	42010586-8561-4fce-83a4-863e637a6d9c	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	8147ed19-ba6b-4bb1-9d49-160bb1e9e2b3	2026-11-06 20:35:21.825245+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	279f9b8a-1713-4a00-bda1-34fb4cb27226	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	84313eef-a7a7-4306-8afd-9c95673a1d8f	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	611bd0d1-e9ae-471f-bc7e-ffa776ee3fcd	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	4e77bd6b-8e16-4a7d-9875-4afb75c46c8b	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	4416b533-7f9b-4c0a-8fa8-daf56d407a90	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	7d8ddd4e-5c73-4ae8-ab3c-215d18a0d4fd	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	bd24cb01-82c5-4851-9f7c-d1319dd2effd	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	ea8b4868-7bbf-44ac-9e79-977f9c5fb5b9	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	91c54e37-7f62-4822-b194-28ca25f55062	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e9a786c4-1f7a-4390-9308-b38c970672c0	2026-11-09 09:45:24.446397+08
1e637734-778d-41b8-9638-60b13c44be9d	ec93d7ff-3b95-46de-b8a9-512cdd524861	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	aad113ba-a3ae-43cb-adec-2afe23519e7d	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	188474c2-34e8-48ae-87ab-fcab345b9b95	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	07f1cbac-a321-4bc0-b6f4-fdf803fd57ae	2026-11-06 20:35:21.825245+08
71e2d8e1-d2b3-4a22-8b22-3d388bc13430	2e94c2e2-6bf2-4c3a-a839-77f4e17e3070	2026-11-06 20:35:21.825245+08
0c000000-0000-4000-8000-000000000001	e9a786c4-1f7a-4390-9308-b38c970672c0	2026-11-09 09:45:24.446397+08
1e637734-778d-41b8-9638-60b13c44be9d	5d267a0a-ce17-4427-a02e-0356cac077e0	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	136000bf-b5c3-426c-80aa-bed1cd06b968	2026-11-06 20:35:21.825245+08
1e637734-778d-41b8-9638-60b13c44be9d	32c39d9e-b7fb-4923-b064-c64b41e43276	2026-11-06 20:35:21.825245+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f9959e1d-7345-4be4-ac85-4f733dde1041	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f1367393-cb31-4103-8177-7fb79d1d5567	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e5570395-9bf2-48e3-bdaa-1caa8810b4c2	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bbe66186-90df-4c43-88f8-54ce32dfd20d	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c8402f97-7599-4c34-bc17-144b4518324c	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	74a37ede-defc-483a-913d-3e0f762cae04	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	941413ed-8ca1-48b9-84e9-8bb1395cdb1d	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b9e23e2b-ed1f-4834-a7c9-bfa25ff84cfc	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2bfb8102-c606-4931-915f-7e7bbbcffaf3	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5c73c8c9-23f0-4930-9a01-ba45778b655b	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b7fb70ce-b504-46e5-9e97-23034498d018	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d940bc3a-36de-447f-8d42-3ee20e6ec6e9	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7f0e8e33-a778-49ea-9154-41ca1b615438	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	053645fc-9d06-40e3-965c-b709647a52b5	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6e2cf085-c106-4cb2-b1a4-50372588f9a0	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	99335c7e-5f9b-48c0-83d0-281c7547cbea	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	faaa9c07-8aa1-4f26-ae01-8c90845911fe	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	00fdeef7-9fbc-48dc-9821-77c1939b82a2	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7da73fc8-601a-442b-93c7-5821ab844ff7	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c832dbf0-2d98-4259-8f4d-f560222e26bc	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2742d55e-6096-4249-b354-9c6b34c7f7b9	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4d1b3ec6-1d98-41cd-be4a-f88717fe6e2b	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3ea53436-19c1-442c-ae10-8b1b28eeea7e	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5618c32a-d553-454c-a55e-b4b848951dae	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	54043311-7447-437f-8a99-1e9aee3a4a27	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	04c882bf-8f86-44a6-9b57-59b10386726f	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	34790df1-fe58-4615-b425-1ce281aa65e1	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f144910d-6781-402f-b059-1da7e7b6b4cc	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	04917cb1-bb3f-45cb-a481-23a8eabc9254	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	af129ae9-e34e-467a-a475-0f21870ae0bd	2026-11-06 20:35:22.269854+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	f1367393-cb31-4103-8177-7fb79d1d5567	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	bbe66186-90df-4c43-88f8-54ce32dfd20d	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	c8402f97-7599-4c34-bc17-144b4518324c	2026-11-06 20:35:22.269854+08
4067eaab-92bb-4c68-b572-fae02796cb27	74a37ede-defc-483a-913d-3e0f762cae04	2026-11-06 20:35:22.269854+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	b9e23e2b-ed1f-4834-a7c9-bfa25ff84cfc	2026-11-06 20:35:22.269854+08
4067eaab-92bb-4c68-b572-fae02796cb27	2bfb8102-c606-4931-915f-7e7bbbcffaf3	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	5c73c8c9-23f0-4930-9a01-ba45778b655b	2026-11-06 20:35:22.269854+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	b7fb70ce-b504-46e5-9e97-23034498d018	2026-11-06 20:35:22.269854+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	d940bc3a-36de-447f-8d42-3ee20e6ec6e9	2026-11-06 20:35:22.269854+08
4067eaab-92bb-4c68-b572-fae02796cb27	7f0e8e33-a778-49ea-9154-41ca1b615438	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	6e2cf085-c106-4cb2-b1a4-50372588f9a0	2026-11-06 20:35:22.269854+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	99335c7e-5f9b-48c0-83d0-281c7547cbea	2026-11-06 20:35:22.269854+08
4067eaab-92bb-4c68-b572-fae02796cb27	00fdeef7-9fbc-48dc-9821-77c1939b82a2	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	7da73fc8-601a-442b-93c7-5821ab844ff7	2026-11-06 20:35:22.269854+08
4067eaab-92bb-4c68-b572-fae02796cb27	c832dbf0-2d98-4259-8f4d-f560222e26bc	2026-11-06 20:35:22.269854+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	2742d55e-6096-4249-b354-9c6b34c7f7b9	2026-11-06 20:35:22.269854+08
4067eaab-92bb-4c68-b572-fae02796cb27	4d1b3ec6-1d98-41cd-be4a-f88717fe6e2b	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	5618c32a-d553-454c-a55e-b4b848951dae	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	54043311-7447-437f-8a99-1e9aee3a4a27	2026-11-06 20:35:22.269854+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	04c882bf-8f86-44a6-9b57-59b10386726f	2026-11-06 20:35:22.269854+08
36007d81-ad46-47f0-85cf-17a0fc1b5261	34790df1-fe58-4615-b425-1ce281aa65e1	2026-11-06 20:35:22.269854+08
c7b9f2f1-a77b-494c-be54-b62a4dcef59c	f144910d-6781-402f-b059-1da7e7b6b4cc	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	04917cb1-bb3f-45cb-a481-23a8eabc9254	2026-11-06 20:35:22.269854+08
2ddf11b1-c45c-4165-a20a-07e75bcccca4	af129ae9-e34e-467a-a475-0f21870ae0bd	2026-11-06 20:35:22.269854+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7f89b056-b99f-4de5-9c12-1d5866400326	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	322a1d7e-b0aa-465a-990e-5e03aa5e942e	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2512cfea-743c-4d9c-9b8d-ea0550b480be	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ebe63d56-486f-452b-b6de-b161daaafb39	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	07a960b5-eff6-4215-b520-b5f2454ed483	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4405f644-a32f-4a41-b537-a1c561b9b198	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1491b26c-12ec-45b3-b244-445c3f853464	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	07517026-bf6b-4671-80fc-90db2b4a2dce	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2f57c955-7b0a-4a22-8ec0-c7e0ccc9c841	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	60ccc8c2-67b7-4443-8c4d-e90bbceaa71f	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a4a41368-eb60-4ddc-b84f-19cec451b993	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	987b8b58-51f3-4b1f-899d-d8d3542ee47c	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8332357a-92e5-4805-add4-24f6b031ca46	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	220b0863-9c3e-4d57-b330-78c686c01bbd	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	630ded6e-28aa-4b53-a06c-050856caef54	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bc6b1dbf-952e-45cc-a580-4c0dc21c4552	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eb9b1227-b755-4714-a8aa-872b2f79b46c	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4a2625b0-e28a-4fab-8a2d-188692d5823e	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	65a587c5-cf86-4c75-919a-6e2f440bba9f	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a0d1ee67-68ca-4f4e-a975-b5ed68dca124	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d060d262-07c5-4ee5-813c-142129947bcf	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6392fd1a-35a3-460e-8a68-be10946390ce	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d29d5383-1f6d-41a9-b3a7-56f975a1e894	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	66376c2e-4e25-4fc0-aa85-3a6b35e484d3	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ffc788e8-e52b-4ba7-a09d-c0c77317037d	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ecf48b36-2e09-4809-b509-60ec45878d97	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bae8d530-1aed-4f95-b848-e3c44a7ded53	2026-11-06 20:35:22.70089+08
4067eaab-92bb-4c68-b572-fae02796cb27	8332357a-92e5-4805-add4-24f6b031ca46	2026-11-06 20:35:22.70089+08
4067eaab-92bb-4c68-b572-fae02796cb27	bc6b1dbf-952e-45cc-a580-4c0dc21c4552	2026-11-06 20:35:22.70089+08
4067eaab-92bb-4c68-b572-fae02796cb27	bae8d530-1aed-4f95-b848-e3c44a7ded53	2026-11-06 20:35:22.70089+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0f8db095-03cf-4246-bae8-5f3fe7cf2ab3	2026-11-06 20:35:23.20453+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c21e8bc9-a85e-438d-9d06-88d0d764e08d	2026-11-06 20:35:23.20453+08
1e637734-778d-41b8-9638-60b13c44be9d	a8b5e958-a6c9-45b4-b1d1-b9bc24436942	2026-11-06 20:35:23.68215+08
2ad18844-4410-455b-b26d-f8dcdb10db09	141b5492-281b-42d2-be27-f8ad5b181a63	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bd706b57-6a9e-4361-91c1-63725487d64b	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	857a18c7-52e1-4cd3-b9b9-6dc0088bf851	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a9f6b4e6-822b-4b84-851b-a1ffbab3e43f	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4b6809f7-cbea-4d04-ba42-deaa93770f00	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	81568d56-098a-40b9-9429-97e34b23c278	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e14621c2-64f7-4587-a4f1-bd7b5b47f7e2	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5c5e6265-5a8b-46e8-9bba-15787b9eab28	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	76412a45-a330-4c5d-b980-00eaa4b744a7	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f6ce6958-2b21-44aa-bb96-39554ec81604	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	28a3edea-437f-4365-975a-156ac8a73f8d	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b070a76b-0fbb-44d6-8b9d-5711b3ebd398	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cf56b722-e4eb-4117-a9ca-d508206facfd	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4f73d3e8-aa9b-4387-9984-1794868d3fd6	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f6027850-7b35-4850-bfd0-b15c19174919	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	90e092fa-d69e-4fd6-b2f4-2b1cf2d8a262	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ab0da67e-00fe-436c-8af9-de46cc06ef12	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	52703bec-08bc-4ee3-a4f9-682ae741bbf9	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	763a0958-a245-4179-b189-02ac2c35c2af	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d0306a25-e4a9-4929-a26c-0498738a74b9	2026-11-06 20:35:24.082186+08
2ad18844-4410-455b-b26d-f8dcdb10db09	72dc2e76-a39e-406c-8bbc-1559ab645585	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	763a0958-a245-4179-b189-02ac2c35c2af	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	ab0da67e-00fe-436c-8af9-de46cc06ef12	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	72dc2e76-a39e-406c-8bbc-1559ab645585	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	cf56b722-e4eb-4117-a9ca-d508206facfd	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	90e092fa-d69e-4fd6-b2f4-2b1cf2d8a262	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	4b6809f7-cbea-4d04-ba42-deaa93770f00	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	a9f6b4e6-822b-4b84-851b-a1ffbab3e43f	2026-11-06 20:35:24.082186+08
7ef90500-6e0a-461c-8e2f-031feb086d85	76412a45-a330-4c5d-b980-00eaa4b744a7	2026-11-06 20:35:24.082186+08
0c000000-0000-4000-8000-000000000001	d5f4bca6-7d6a-4790-887f-5982fca20bb2	2026-11-09 09:45:25.950156+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1616e92d-1c8d-4ccf-b576-c7d948429544	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	03d4a358-e823-4e63-891d-ff28f77c268c	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6e089f86-ccc8-4fdd-9c3a-66ede7bd962a	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	070f8f3f-5717-4d45-be78-0d2f9238e4dc	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	940e226d-5b0e-4877-91e6-2ec4e47498e2	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d66dd64f-f5ff-497d-8461-bb191847f331	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c9e2eb02-37a8-43aa-90fb-c4d84caa37bb	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	dc19f4ed-7ffd-4f5e-8275-ba6850b2a039	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	9b1f71d6-746d-430e-83ae-2f7dfbdb9565	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cd9707ee-bbd3-4393-8721-62d20b9e2d22	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	00bfb122-253b-4bd5-995b-17cd1ddc5a11	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	a625a92a-33b7-4221-af0a-24744648366d	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	c38202a6-3e12-475d-be8f-c1c59c10927d	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	00bfb122-253b-4bd5-995b-17cd1ddc5a11	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	cd9707ee-bbd3-4393-8721-62d20b9e2d22	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9b1f71d6-746d-430e-83ae-2f7dfbdb9565	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c38202a6-3e12-475d-be8f-c1c59c10927d	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a625a92a-33b7-4221-af0a-24744648366d	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	1616e92d-1c8d-4ccf-b576-c7d948429544	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	03d4a358-e823-4e63-891d-ff28f77c268c	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	070f8f3f-5717-4d45-be78-0d2f9238e4dc	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	6e089f86-ccc8-4fdd-9c3a-66ede7bd962a	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	940e226d-5b0e-4877-91e6-2ec4e47498e2	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dc19f4ed-7ffd-4f5e-8275-ba6850b2a039	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	d66dd64f-f5ff-497d-8461-bb191847f331	2026-11-09 10:26:20.511016+08
0c000000-0000-4000-8000-000000000001	c9e2eb02-37a8-43aa-90fb-c4d84caa37bb	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	070f8f3f-5717-4d45-be78-0d2f9238e4dc	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	a625a92a-33b7-4221-af0a-24744648366d	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	c84c3478-cba6-40d0-a077-759805f7fc26	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	c38202a6-3e12-475d-be8f-c1c59c10927d	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	f1b2e6bb-e6f5-4178-9796-564cac064aeb	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	fcfe77a6-5349-48ce-b3c7-8093730393a7	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	a418147a-18ea-40e4-bf1d-aa9a02ad20ec	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	c9e2eb02-37a8-43aa-90fb-c4d84caa37bb	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	dc19f4ed-7ffd-4f5e-8275-ba6850b2a039	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	15d576f8-a39c-4ec7-bf37-f3245f1fb3dc	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	940e226d-5b0e-4877-91e6-2ec4e47498e2	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	40bc4a3c-ff77-44fa-8c5d-6ce4307a18f2	2026-11-09 10:26:20.511016+08
4067eaab-92bb-4c68-b572-fae02796cb27	5f9c0a91-658f-41f0-9523-9ab2b3c58929	2026-11-09 10:26:20.511016+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bf28ab8d-d374-4ffd-96c7-bf0aa355993d	2026-11-09 11:03:00.285893+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2080eeca-74af-463d-93bd-7937274c13a3	2026-11-09 11:03:00.285893+08
0c000000-0000-4000-8000-000000000001	bf28ab8d-d374-4ffd-96c7-bf0aa355993d	2026-11-09 11:03:00.285893+08
0c000000-0000-4000-8000-000000000001	2080eeca-74af-463d-93bd-7937274c13a3	2026-11-09 11:03:00.285893+08
4067eaab-92bb-4c68-b572-fae02796cb27	86c8b49a-2712-451a-9834-8b8a7be85130	2026-11-09 18:07:55.529691+08
2ad18844-4410-455b-b26d-f8dcdb10db09	86c8b49a-2712-451a-9834-8b8a7be85130	2026-11-09 18:07:55.529691+08
4067eaab-92bb-4c68-b572-fae02796cb27	8253a7ea-4e44-40f6-a83f-2fd2ec1c5980	2026-11-09 18:07:55.529691+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8253a7ea-4e44-40f6-a83f-2fd2ec1c5980	2026-11-09 18:07:55.529691+08
4067eaab-92bb-4c68-b572-fae02796cb27	80ffbaa3-c385-475c-b6bc-552a8e36c5e8	2026-11-09 18:07:55.529691+08
2ad18844-4410-455b-b26d-f8dcdb10db09	80ffbaa3-c385-475c-b6bc-552a8e36c5e8	2026-11-09 18:07:55.529691+08
4067eaab-92bb-4c68-b572-fae02796cb27	9d8e778e-60cb-48c7-9377-ad7bce191b3d	2026-11-09 18:07:55.529691+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9d8e778e-60cb-48c7-9377-ad7bce191b3d	2026-11-09 18:07:55.529691+08
0c000000-0000-4000-8000-000000000001	86c8b49a-2712-451a-9834-8b8a7be85130	2026-11-09 18:34:01.958455+08
0c000000-0000-4000-8000-000000000001	8253a7ea-4e44-40f6-a83f-2fd2ec1c5980	2026-11-09 18:34:01.958455+08
0c000000-0000-4000-8000-000000000001	80ffbaa3-c385-475c-b6bc-552a8e36c5e8	2026-11-09 18:34:01.958455+08
0c000000-0000-4000-8000-000000000001	9d8e778e-60cb-48c7-9377-ad7bce191b3d	2026-11-09 18:34:01.958455+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aca9a9ae-236e-43fe-b5f8-5987d4fcd819	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	509148e7-f34e-4e44-b637-0b83085ade65	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	23c50969-a410-49a0-96a5-1817ece1ba47	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	17764847-06a3-481b-b84c-fc64ce0ef960	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f4e6500b-b196-4ab8-97c6-316000f71f2b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1ed32704-aa8f-40cb-9575-06190a597154	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	84e88b19-7ea3-4c83-9ae4-b595f42642dc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a93574bc-243f-4919-a136-3c5451b3099b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d19ae1a8-c61f-41d4-a91f-91647b934f13	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bef50f16-48fe-43ee-b602-ce0648d60bec	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	78de2802-d14c-438c-a5c9-f39a20ed8bc8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	87420d52-ba91-4e2f-ac58-943add2a94b2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	24c83555-0fac-4aa3-b263-263da1a66725	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c86e5223-8208-414b-896f-bfb08ff6b6f2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	936aa7b2-c830-4231-9045-08c0b6a7ccaa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b5226662-612c-4cd0-90a3-09f75dd42754	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	94690540-217c-4346-bcc2-c1f6c694662e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0820e071-6289-4079-bf92-919475011b3d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d680d4a1-0deb-4555-b977-40639d3390b0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b9651b0b-b17c-4d29-87b5-028e4359567f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e4865f32-f0c6-45db-9cc0-a69ad8c23900	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	37652085-c739-4340-981d-06672288e823	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	475ea8a1-15a2-4119-876b-662cef417d80	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	219e704e-8616-401b-aabd-dd48d3b13a6b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	76782c91-0742-42da-9034-59f81deef065	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7e292473-2e5d-4234-acf5-b8683e7ff051	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7e3da5e3-4a15-4293-9666-17089f7221aa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	afc7b2a7-fd2d-446a-b3b2-b2869469a55a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f354b4ef-f930-425c-9f35-8bcef8ba8d4d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	91ba6a97-484a-4a82-adf7-75311a7e1a1c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6fb2e2f6-36a8-4971-a66d-352ffe5b5f22	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a78504eb-35d5-4358-b063-384b5167979b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b95075d7-960e-4ab8-adf1-d51900deecc5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	94cb55f4-5d0f-429a-96d5-0e68d24f92aa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	44be5995-4db6-4193-baee-dec6a9b50e91	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5376af21-342a-4e75-a591-1776a8b1c706	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	02549094-9064-43b4-9b14-4cdd00202012	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	52ae7693-c712-4ce9-95ca-89afbbac2134	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	677c220d-4713-432b-bf46-a97babadd713	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6bf564bd-2b91-49d6-9365-9b2045af8e8f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ed034c2b-a527-450e-9268-7d4288a83a50	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	87532d47-b031-4c33-bd67-219740197598	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0fc2eeff-f6cf-4b1e-83f6-87e5590fb996	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	af34ee5e-2497-4802-92f5-bdb634ae828b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ea81d652-434b-48d9-80b0-631d85cf2903	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	15fc7f5e-8b0d-4e4b-805e-fc08787fb446	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6eafa6e8-3097-422d-a96e-c6ba2957b3e9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	88263dff-3e83-4a75-9d01-e692c0404a3d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	076d6603-658f-4e97-9899-adc20cbe704e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	70c2fff2-f8bc-45ff-898b-2e6723f83b20	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ca683d73-c1d0-4e45-b118-f52a71957d1b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	57e887ca-e62a-4666-9395-1af50fc20e33	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f0bbf9aa-9a56-42dc-8211-8092a0c2c4e0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	655d7299-4fbb-48fd-9a67-b4073fa4dc5f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c9f30bdc-2c5b-4713-b2df-5a889d5a5380	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	48ed375b-8c51-40e8-b400-4969107d8add	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	00db48de-8483-4b5f-8e00-e2c53a57a33a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b322c847-46f8-4169-ae78-162b4d5f944d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1b9fa8b9-cff4-4077-9bb3-49a355646df6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e66d1aaa-4a3a-4e49-88a9-c6752fe68b13	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6ec53f4b-8f6f-43dc-ac4c-094353ca2e91	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	68bcb990-8045-49fc-887e-b05b5eb3e85c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6ac3d874-41b9-469d-a60a-b4bf8512a7df	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b4d2fa99-a7cd-4fee-aa77-1737c239e907	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ef38764f-b3a6-4e33-9e99-7de82d4a3d69	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3c2283da-8b6e-4f71-8174-e527becff9cb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	540931f1-e88a-4387-8109-ebdd0fe87c25	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dab34c1c-9858-457c-883e-696dc1d953f9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cde49d8a-9c6e-4c97-9582-9b2f9af19916	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	addafe6b-3ed0-4203-a3d1-f49786234367	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0219820f-acc8-42e8-9cfc-076678845d8d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fe7160d4-8588-4408-923d-c75e27c32d66	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c9bff55f-fad7-4e8d-8141-7761f0291798	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9033c0cf-765e-47fc-9be4-aefa68be48e3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	75eea67f-240f-429f-a401-84750e3756f2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b6b500e7-9353-4331-94bc-6eb6db3175ca	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1fc6e8a0-b3bf-447d-869f-e61400ca395f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	35119d75-1d39-474e-99bd-35e2ba2f8aa9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	29ffc53c-b93d-4268-ad7c-d43449f79622	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bd763c66-dcd5-4dd2-89a0-9aac5980c719	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e84e5bc7-1c4c-4d85-9361-fc23da95ceef	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d20125ba-910a-4bfb-a3ff-5f9028f2dcd4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2c0f6c33-00f2-4879-bedd-10f35ee1d71b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	13421cff-3527-41a0-a28c-b70f1a3585a0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c8f7528a-b746-468d-998a-69d9fb77f8eb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	17b4d5f8-6168-40e9-ae1b-e795f48971ed	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7b64ace7-aaa3-4b7e-b0b1-f3d6ae9db4b4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4f11c6ed-7a00-41bf-8224-46e13b5d9bad	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2ddb6ac6-ffc2-495a-8ad2-cde85e51805f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	02abd9e0-faf0-4ad0-9a6b-b11402fcdaec	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d0e130c7-e561-4c51-804e-174c1c214acf	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2c9382d8-5ae1-4624-ac4c-915cf8ee2b8d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d5974ebc-b20a-4380-ab81-6bd5ece9eb69	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	37359d83-d5f8-4bd3-9472-0f2faf5f04a1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5c24b0ca-ae87-444e-ae30-de8e099cebed	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	51c19f90-6687-4771-aedd-a46847a2e3a4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c3d67379-0ead-42e1-9357-f7bd07869a9e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2e2c8722-c8fe-49c8-8959-4df4239c9044	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	45a8787d-c4fb-41b7-a638-ce30e1acaca5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d014f331-6483-4671-bc41-6236b06ba37b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b2801f5d-d1a1-416c-9b22-71722d0991f3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	363100c6-ff27-45cf-83c0-05109bd668cf	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c58700ee-14a5-476c-9a26-7a2e66421ce1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7599c635-56eb-4596-843d-8bb7f9e90030	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	016536cd-2144-48fb-a420-18802aff14a4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a141f05f-088a-458c-90dc-7cf15f4b9feb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d5d17649-01e6-4d2b-b7ee-2c2275226520	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8bc28040-f8c7-4110-a5ae-0fe4d983cef5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4fd2b28a-5c0e-4391-a046-ea90b14b78f0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	af0d82c8-c095-4d86-914f-b86216b9d8b7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	350c7790-b0fd-412a-86ee-e2defd30bcd7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9e1e67ee-c0bf-4709-853f-b4c202d4ae01	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	60bd83c4-7428-4aab-bb88-fe8c3f2c44c1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	773bdd1d-9a8f-4a83-affb-3c692d6540bd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	67003d99-42ed-4b8c-8999-d85802d0e285	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6d214a03-6461-4b89-a2bb-5429ea0a56e7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1a27610c-e0c6-4fee-9d25-892bb6f4fe10	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	00080d63-f28b-493c-8e8e-f0f929f46329	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b30a10d4-dd01-4e0a-a5ad-a1ce9d5245f7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c252a2a8-afc2-4317-8726-edfae372e93c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	571c2e47-915a-48b8-8bef-d07e887975f9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1a20d9ac-13f4-40b5-b67f-ba076f50d938	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	174bffd6-fb89-463f-b9d4-8db402c2b49e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c3f4aa2f-0cea-4705-877a-27e969a2682e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	36ce793f-53bb-4756-93e3-b46fd906942d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	55da5d18-aa58-4e11-b336-03af4f66e028	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8aa7d8ec-fc90-4515-9bb0-fa5c9b01c59c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0da71896-a82d-4d46-9ba5-48dd04b4f80c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6f027480-1c78-4d9e-9968-2b25ed52d404	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	96ed4ac9-5cc4-44a8-ad49-86372a73425d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bef93b63-4a75-4f51-bcc8-a8d343e25fb7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	82af438f-777f-4c00-bdf1-53b2aeb289e7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	05b369b2-d6b1-438b-8b08-c937508faeaa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	46879577-3358-4986-8bfc-114f5574cdb5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f939c582-9bb4-4641-bf88-72a01411c863	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c0bce82d-61ea-4d23-bf01-e315cf76e808	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	35398804-0d24-4496-9a55-87bea11db0d5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cad31fa1-e7a0-41c6-9324-5ea00aa5dd21	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9924038f-fa8e-4be5-bff6-9073368a5471	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1a27be22-9a1f-4054-ab65-7779d57381f3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b372ac5c-b9e0-4bad-a3cd-9e7d879a6ef1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	513baea3-28e8-4a36-a4e7-beb5c01b2961	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3b9dd14c-fb41-4491-9fc8-2d8576a5c67c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e3d806db-5e8d-4127-a2b0-1615ff910e38	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	03c480ab-e62a-45f0-b159-1c0b882934dd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a4136bb7-debb-4a75-9f25-524a3b8a867f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	de7b1d04-0479-4b18-bf96-f328a70e3dc3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0b3b1209-4d33-4d56-b806-7492c6bb4707	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a9b0dae7-d770-4ed2-bd96-52b643051248	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a3e49191-3e1a-4d06-bfa8-eb947a17df9b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9be516cb-913e-4823-b57f-3b641577bd45	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d9502659-74a5-4b31-9e5e-f05bf09bc61e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	569b856c-d12c-4b6e-aa8b-651f569de24f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9b8ef6b9-fa20-478c-9c07-70d5ef7b77f4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dbcfb335-82a9-4afa-859c-71ba034cd839	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	df3da25a-405d-4a20-bf27-ffcb5c6c7775	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6aa15c55-13d7-425b-b62e-b1f99966352a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c562c184-e015-4546-a582-0c7fffed8947	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	81d3c9b2-9279-4528-a61b-e4c39522c5c4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	76f15e54-cbdd-435b-9674-a382aecf952d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4b3b52c2-6275-4a92-9605-8542cce2c447	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	404e380b-5e2a-4b81-a362-c18e4059b0fe	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9a658dea-e0dc-407e-b239-c322a0df7edc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ee2f55e4-b0d4-4e23-a64d-296cd87825c0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8380fdb9-60cf-4b26-8698-e2e41787d085	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f0d65596-18de-4dc4-b72b-8a79818a207d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2edd77a5-3126-43b1-ad18-64ac1bb8ee70	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a7a34dc8-f4d8-4329-83ef-fb0382eb7950	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	43233d63-bf7b-4920-9c63-d3dca088742b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	808a44a1-7906-4bb7-92e7-69cd0c45c9c8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	afabc962-6aec-41dd-b62f-15d35f06fb21	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d5b39d10-bdfa-4982-b45c-1bbf17d55eed	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b8d03281-9a40-4b89-bbe0-d4c4dd6d4b4a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	24490971-d0b7-492c-a1c5-942be9b7449b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4a8e0cee-b789-4605-8078-f7f833f62e93	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f1b2e6bb-e6f5-4178-9796-564cac064aeb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3f46003b-7a9e-4a87-b9f7-c02dd07d733a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	21c7c4a2-4a09-4c3c-893a-9b1859caf588	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	25709809-5abb-4ac8-9d35-c60a26c4be23	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	131d6ee2-495c-4852-9a3a-42b57690ee27	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eb60c8ca-b38e-47f3-8146-bdf18701e15f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9dc03863-f1bb-4302-b822-a3c8f831b46a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7859bae3-2f07-49bb-9a0b-95c2f3d44fc1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2d8a31a6-9597-4ca5-8b8d-9159f13ecaa4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7a579dc8-7d46-4ac5-a209-b3cce98718e6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c84c3478-cba6-40d0-a077-759805f7fc26	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	469185a8-8a14-4cd2-ba82-d1ab5241bd57	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ec945b09-9169-4bd6-84b6-bf413e8df431	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8835b668-5fe1-42df-ad09-97a240456194	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	58b3df4f-fb0b-49cb-b63a-00a89a9d5b9a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8d6e736f-13de-477d-8d35-6274ae221c2b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	958a344b-8b88-425d-b5cd-f73810680d6d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	65e18ea1-190d-4f51-a8a5-6aeaf5e74b27	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d88b01a1-09dc-42ad-93c7-3fa95604d0ea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3ce5e888-9e7d-4b00-b7e3-e4339f3424d8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	24523602-d294-4ee4-9682-b4b7033e2dbb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ce88b7df-8249-47be-83ac-cac286a47624	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	57ff869b-2160-4a3b-a3eb-8e060eb0d324	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1e5ab521-a55b-41d0-8ec9-58406058fa61	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b36cab3f-ae9b-441e-8cdf-d6e7b85bec7c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	10921a0f-4d4c-4a8b-80f7-36dd49329e08	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4d384c77-8040-4971-ae47-51b53e37843f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	58d47305-af48-4101-863e-e0c6340e111e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	44e82e3b-4314-406a-b3e1-cc47742da6ee	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6623accd-dab6-4e3b-a046-d6d94043c3a1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	73f56787-1414-4a11-921b-c4957e8edf5f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e39ba050-965c-4cc1-a6d7-7be396bed06f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	546fe75c-e5a5-4504-b119-0c7606b3f601	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	58ed58fc-8ed9-4838-b805-3d444871295f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	01b86ba9-4d13-4f27-9dfa-eca19055186b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	309dcb60-cde5-4d03-84cc-6f6c11b8d836	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f834bc54-300b-4d0b-8302-8a1f6d2688fd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5ce25f80-91f8-4f98-bc09-28e2d63cc39a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	97ed19db-ed13-4a4f-8d35-205f3d5f1930	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	abb116ab-5ae5-4b95-a76d-69f84ef60531	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	001ceb18-bfdf-4c96-9de2-45dfed32d0ac	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2895206b-f2a0-46e4-9591-6496e86ee998	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ca69cb47-4c0e-4e29-bcb8-afce2c41fb47	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d7a1a601-c219-45c9-ac46-9a59c25bd468	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6869a699-602f-4d2c-8150-26c975d94562	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3f5a72bc-3e9d-438e-83dd-ed96959deeb8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5dd50086-a083-44e9-a7ac-78e011241957	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fe70ea88-828e-4738-9007-3dd1fe53f8ea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b3dada46-c85a-4345-9057-569872c36b76	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dd45992d-1935-4d08-a87d-a92079ae1539	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3435f0a9-c63f-47fd-914a-0157b0af83be	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1edeb642-b711-4af3-a5ca-d48682dc2442	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b9708b1f-0b9c-41b3-a699-5d101458ee70	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2c8614cd-e470-4f92-a189-19a06080c19c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e70982f0-0001-4900-8bd8-0bd41abc85c5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	68b9eb3a-80c1-48e8-9933-7252c8985688	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d522e713-a169-4b07-953a-15fac87a516a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a0994733-323a-4b99-8cb7-32666d016bac	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0c5349c3-e059-4134-a7f7-57e18ab03b86	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3ae80f7a-9350-44c3-bcfc-164be9cbadbd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9e9a26e7-d2b1-4fd0-bdd6-9361ffaf8ef0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fc7d6711-4c02-4d31-bb23-196ee3ece6cd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5653bd54-d986-484f-aacd-6b00baebfdcc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	17b9e9d6-8ea2-45b3-bcef-c5b9ebe9a6c0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	689a0f23-9ec2-4358-800b-72301791a8fb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fb14a52b-6f41-4333-a3f0-ef935bc6adb8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5187300b-a108-4506-b4fc-1a0e36bcc5f5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	64af5f26-55bf-4344-b773-ed05b9343ddb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5a117c91-85bc-4953-9c6a-e8796aa088eb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e38e4a7b-a918-48d2-af8c-4b12851b65cb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e12ac640-497e-4877-8911-dc8b8429499c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4798d33d-62c5-4150-8235-63bc6389f7c8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6e924747-5f61-400a-96f2-d39678c53ebe	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	369009df-a3d0-4990-b50d-f0b02af5efd8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f1b652f7-08ed-4f89-ba99-3c175c01f115	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	21734117-630c-41e0-9254-f6f0c413a60a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bf2b5ab6-6669-4c69-b4ab-4ec6d2f1ec98	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cfeab591-d11a-469d-9b99-4ba15bc8f49a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	683fce65-e197-4d10-aee6-b01fb1d3a013	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	44799ef4-b664-4b1a-95ea-98d49d02f8be	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f66cc7ec-ecc9-43a7-8f65-6008e4aedb9c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	88e4530a-d048-4770-aee2-88b210e836d4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4e6e1cf6-3460-4dfb-9132-f68183f530c3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e388daca-c0e3-4396-b400-5e06cfa67472	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a549fb54-39e3-453c-a2b8-be2bf032d196	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a8ba07cd-57ce-4bca-b956-788e42505749	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a6aeb533-db2e-4a7f-9fa6-cdd0bed5cb07	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5fad1a87-658c-4894-9772-72a1b0731d45	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c640d369-53ab-4b61-a818-95b60a1b58a9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	613aa7b0-bff6-4274-8fb0-d055835f5b67	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7d5c46e7-f828-474f-8c29-7253136d9871	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d219c621-f386-4fa5-b846-cc578167286f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	983eced3-366c-4b7f-a2ba-bf7b8de9e9f3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d9f4aab1-3bf8-4fef-bb18-d46f5e0cc5e1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cef380ce-868f-4537-bc5f-73b390a16702	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3e61f288-9acc-48b3-b186-ac7185bfe31d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	13383d43-a6de-4bce-845f-1d53202c5bc1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9ba3cac0-e113-43d1-8197-bc6e62c006a5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	945f8e67-6a22-4cd4-8392-c78f5e6ef327	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1f093cf6-422a-41f4-afb7-0f506087c3b8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dc29e592-994c-411c-b42b-b186a5191a17	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5fd4c317-345c-4082-acd3-86b2d1a628d0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bdd7cae3-e309-480d-ba9b-1602e16dac04	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f9114ecd-4fec-4dbb-84fc-076055dc106a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	234f4124-6147-495d-8c73-343b542cdf98	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3599d649-04de-456c-aff1-918b055821f2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3b2e6c70-8248-4075-b0ad-4b9f613dc6e0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	01f82c34-63d7-439b-9960-77cf6d630db6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8417286d-3d11-452e-a91f-d5fad61b3b16	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8e2ccfcf-fe5c-4b18-b512-47956b16926f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ec97e8b2-337e-4211-a6fa-c991f8f27326	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dc3b3534-41b4-45e5-9e98-0fa92cc64014	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	97fd42c9-f9e8-4f55-b7de-c53a1e197e5c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c0e150ca-03d8-41bd-bcdd-ef8ebbdc754d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	168a10ee-0cd4-4bf6-8050-e4e011d40762	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	98960006-df7c-4e56-a451-ad51b5af29ae	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8469a43b-4c95-44aa-b423-f2c21ea7ac63	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e736e259-e2c0-49e7-9f72-a8b53000bfd9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ed8284f0-b8b8-4ae8-8ca4-ef91de0d0c34	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	47550e3b-a7ec-4234-8df5-f7faf2ef7bb9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	da44e650-cf58-432f-bb29-2672f67d7cf9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	630e341e-2360-403a-9acc-062e6929e1aa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9c0cbd06-1385-43ff-9ab9-693e26af462c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	79f587ea-df95-4b8a-9831-b0de393ce226	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	34cc6d5a-d1c6-469c-bde7-6258b4a4c5da	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	893a3899-6db1-439c-b6e6-b348a0ce750f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	faf3128f-d3c6-406e-9dc3-416d8479a9b5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9e69f6d6-1c4b-4b11-8db8-b2409cf29275	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fbb8a65a-83ec-4eb8-a937-378ec1139263	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	42fe0562-b0b1-452d-b948-536ed2d536dd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6040a799-1c4f-4ec1-8953-645540980bc1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	67d90528-2e5c-4da9-b89a-cc87400b29a6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cd047b78-93b8-477a-8027-eae22e0f49f3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7ecb7277-6d10-423c-a286-1e891cd1a2b6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4e074869-df5c-4e30-a7cc-dfb680eff1fa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9cb62667-ee23-4912-ba8d-ad2d934ab0d9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5bb222e0-7245-40fe-8b23-0c1cf908eb79	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7d2623e2-e4e7-439e-bdfc-6440b5bb9c56	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	394cc5b5-9357-4162-8fbf-18e50b88d473	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d84d44a6-19ca-4bca-93e8-8ac6c47efe95	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eb77fbf8-089f-402c-b935-bd4a911fcd3a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1733fdc3-eb98-49a0-b0b5-c2bbc2ab3772	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1deeadb4-e989-4e07-9d6c-b033e2989538	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9738fddf-e331-47bc-a5d6-2f352731990f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e72535d1-26f5-412a-ad4c-44e22dd37aa7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a70adb6b-9b8b-427f-bc0a-298ce53671f2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	111b391a-e8a2-40f7-bac8-c28831bd5aca	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e265ffa2-8278-4d17-a1d2-ece5c4e63f9d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c1f84f46-fb11-4f6e-b482-8d79602426a0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	acc141d9-8527-4302-b086-286cc8b4e26d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ba3440b7-756f-4128-8968-5dbc298d3a2a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	208b623d-85b5-4324-91e4-03b4417b7f26	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8918e044-f0c6-4981-8112-de8427367969	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1f6fc74d-714d-4cbe-85f9-938e660447a6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d1885cc3-f822-4c3a-ade5-bea5c3116d2e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	010ae5d8-3f48-49d0-bef3-5e4a8f5d10a5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bb620e33-0136-465b-afdc-37448d768113	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0fde9d79-d70b-4d67-98e5-39013bca2049	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eeec0ea5-873c-4374-a415-3c1d86b58c30	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2a9040b6-0dba-4c99-9a13-bc959b53cfe5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	58e208a0-d672-4c93-805f-d2ca15802e03	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	51b1fb64-a696-4a71-b474-c5fb55fd7d06	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	762d54d2-5f86-4e60-ad17-87a38d8984d7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2f2e9393-e4d5-4036-9552-403e66a084c3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	473919fc-b929-4a5a-be7e-78da5ed172d8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	81bb7faa-3dcb-4e54-83bf-4ce7849f995e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8d62857b-9efd-4d30-ba34-02e17f821fa5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	659ee807-6bb1-40f7-a957-8ab515a48f94	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	43f9c115-2ea5-4023-9c8b-46a0e414afb0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1e38a460-8504-4fe6-b19f-ac4155bb42bd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	de37755f-72dd-412d-b342-3e1f3c46e62c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7cc0f634-61d1-4ab1-843b-841399c92dbd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	de3e8777-42ac-44c8-9a56-68f8e6b22f76	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1087e748-6534-4806-8ddb-bd68027d9b85	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e1f9389a-5b46-48d6-8f4d-b6acda13224c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4e36af96-4097-445f-bae7-fd61c42e44fc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	165d6ddd-16a4-46ed-b0f8-2ca7a777ac7d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	392abfe3-e8ce-44f9-ba6d-41000d49e3bb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	029132a4-e1dc-4e69-8b6c-b0a4455a00e4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9e73093d-8c11-4a8f-a20f-354b0fea42ea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	013eb45f-c4b5-4aca-b0ff-e5914bf89ee9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2ff29ce8-ef9e-4548-ada3-7d9f4d31f4b2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6fb10e1e-f330-48c7-ad0c-feca214c574b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dde1f05d-951b-437f-83dd-ce3488c922aa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3e340190-e9eb-41a0-9151-a90a9a174a15	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9230a691-7d05-41b2-b03c-77c786a32c35	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4bbb1f4d-3ab1-4f59-a1d7-a41e613e4433	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	69d56e64-d6ce-4cf5-b5a8-b5168cc94d74	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a5ede0df-cf02-42ea-ab96-99595da8f88a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4491822c-0dfc-4d8b-9264-155b6b5c4d5e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	96b56a30-f52b-4ba5-aeee-b887d80dac17	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	685bb93d-1594-4d64-8df3-9ab74108b1dc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cbec48fa-6412-40df-b582-2406d2827682	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f6ff0668-762f-41f7-bd37-fff13fc51d80	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	966e484b-ed28-4914-813e-a71afc555abf	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f528110a-0afb-411e-a327-ba222408c203	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6d6e5327-5026-487e-b845-04d4fcf2923e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e7ead4bc-4a61-4bba-a2ac-ed3c2a127f53	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8ca422bd-ed92-41be-aa9d-16476426670c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fafc560a-66f8-4dcb-9b34-81ec34e7485c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b48b4996-b47f-4b1a-bd5e-a2cc8fab92b0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9a090c49-615e-4189-81b7-c68f70588a9a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d5705b38-a0e0-4199-8654-e5e6393f7fa5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3fbf4e67-5d50-41d9-bb14-61ab66b74fd1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bc09003b-7994-4375-8ded-88cd26594627	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	27412e21-3e81-4d36-9c9e-a99f3d38046f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1c7b23ea-b36e-4ccf-9da0-ea25555afcea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1c4d487a-c653-4b38-9434-1d1d8db8d74c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2cfba3c9-692a-4b93-8aef-fef6c03c333a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dc14fba4-c712-4136-8e76-89b7d7cf9018	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	df22e30d-4ed2-452f-99bc-cbcdb74e9b82	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6c0e8343-5b19-498c-b10d-6369a1653919	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dc5e30e2-9930-4122-ab9f-e09eb611c355	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1d6ce285-d577-43c6-9c72-b9fdb34ad41e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	593c95f0-77e3-403b-87fb-400e608c273e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8e2f0cd6-e10f-44a1-ac66-c2372ff9aba7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	661aa554-93d9-4580-a089-da3c188403aa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ed24d521-dc32-430a-babb-3b972d27ca5f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7c8e444d-6dd4-42e0-b6ae-6f8e3cf554ab	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4fe66c9e-36e2-49b0-955a-17cf9d138779	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c04d939d-58f1-49e5-80f0-3221da1db59a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0e2a882b-9d5f-4652-b4cb-3fdbf1ae5316	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	07cd1e24-e4a1-4dbb-b25e-9f6f88b9367d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	47b50520-05db-4c39-8b89-72cad268b55e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c5f852c6-3ce8-4733-906d-0b3219038030	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6e9ef4e4-091a-49f5-ae34-4516d56fa2d1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	df097ebe-254d-4429-89b7-abc8021be8b0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c60449b5-1573-4724-a73c-9c9dcffe4c79	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ca97156c-f828-42cb-a36c-a83bd2147360	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a69ff633-b1d9-4eef-b75c-7d4a19e53275	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ffac61a9-9ac7-4611-b41b-e90cdee8d0db	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f5ff4dcc-ae10-4f4c-bd53-67793f8f37a6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aafd9e68-1a98-4a6e-8174-652e4f296ace	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f07328f9-3da8-4478-b74b-70837fdf5abc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	19b54313-877c-4b9f-ad0b-5343a9966292	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2ca05c4a-9100-4313-a735-d4f3c5e75924	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0bcad886-044b-4a10-9d41-d6b7632d9df1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b7dd8d6c-518c-41df-9dd5-4a36fe4bc217	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e74d0bed-1796-45ec-b90b-139bfe02c93a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7351a6a3-9e92-4d9c-9a42-0e0b6199c00c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9370dc2b-11a8-40a7-b7c9-ca3c512b9969	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a91e3a12-46a8-4119-ab8a-63a67b5f7d23	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c31ecd18-bfc5-4621-a780-3bf5b288d816	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fd807b2f-5696-4918-a37c-1f8b279f8539	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	970fbbab-5287-4b95-96cc-6e703f3fc988	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0b3fcb81-17ac-410f-afda-0813de7613fa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d2bc12c6-ad64-4a54-b9e0-f7aa59ecf58d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	504736d0-3c4a-42d9-b326-69d5bf2997fc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	11f35f26-18f0-4a87-ad53-a19e182f301f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	016d98a5-b27f-4ac8-828b-26343572d93d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	474cfbbb-563a-45c8-ac15-7d312796ab85	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ec2d7f67-c805-4be2-81d4-108cdf7c9310	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	94d7636a-6ba0-4498-8dc1-59aebc2010b5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7284c60f-61b8-4358-bfff-1ad0a28766cf	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2812f17a-2a84-4dfd-8ecf-f70ee8cc6494	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	86bce5a8-1d56-4650-89b4-650ece7b4c2a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a26c861d-0483-4a81-bbee-0f51554a92b9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	278dc783-e8b4-4a50-8f15-1c04780e6a71	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2525c5c8-f8ef-4704-95de-d8cdffeec983	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0ad56aa2-270a-447a-bb55-5c3e5b740862	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	21adeaeb-4919-4a28-b04b-e661a6618016	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4bd8e98a-d4bd-49eb-84cc-bf5fe790b571	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eb0379d6-cf5e-4138-8296-1d3d26797ce7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	44c473b2-e325-4f8d-8c1c-93837945a6af	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0a805f49-09fc-47fa-8cad-aa56c648747f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c59c8a73-c1b7-4872-be60-0053197e9b72	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	19dd599d-6e4f-47ce-a045-d6df8b2a663e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	656641f6-f723-48ff-b4b0-0d72cac5e1fc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a40248d3-6777-43a0-9169-fec2d8c294fb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fa30e46d-ad83-41d7-8475-3e4d3408879e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	14486b97-172b-4b6d-aaf9-2c955e51da16	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	519985a7-4bd4-42f6-8035-c89821184328	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	44be4839-b13d-4441-8fce-f63d7c1134d4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	457373e7-b6f6-40da-aa8e-520c0018a26d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6c32eb6d-4e11-4d46-a975-74bb96409c39	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a418147a-18ea-40e4-bf1d-aa9a02ad20ec	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bf58df65-0a9f-4350-8ebf-6f935cd76f55	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	120c66ee-5a1a-45a0-ae9b-0b6616f2b600	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c70305b6-2202-43ac-9fef-dfc7a57b5045	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0840d1e7-a0df-49eb-889c-05090219c464	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3e3d4592-c126-4c82-a08e-d792d44cb6c5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	303bc82d-6530-4fdb-bcf1-37ae7c1fea83	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c4a88d7e-87df-4141-8f25-d74773a2ddd2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	455aae0b-d0c1-48ef-8193-4ed35482702f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c84ff030-06b6-40bf-868b-83d05eedca2e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b03482a2-6040-4faf-97bc-a3f7644f0835	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2657cddf-c478-4725-a857-ef7908e8ddf7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	53c99369-cad6-43db-8b02-6f7813dc589d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	728fd516-3774-4f71-8990-d8a51606c38b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3b80ae6b-0c62-486d-9466-d47f9f9aa61e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1df026cf-4519-4d1c-b857-dcb6e700254e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	54006b5a-2ac1-4ab7-95c5-36f43d5d6d7c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	65376494-25fb-4a72-b02f-0ee381a9988f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	889484a7-bcb1-4910-b9cc-28a83433a468	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	be7d0c87-c89e-41bc-bce3-6a29f8c36749	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a47e6e07-4923-4574-b03c-51863791b181	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	37c957c2-94f3-4a92-a99c-c070a1e3e0d1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2575ddde-6b55-474d-a5a4-9c4e4047511f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	432de1f9-6cf4-4de6-9cbc-8abf02ea5cdb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	366229bc-ff89-4a2b-809b-f72dcd98cd64	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8d4dff04-6c17-4796-a7ad-ca556089b374	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d4b29c75-7642-4342-8e5b-6b7e0c50ef3c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d9dab3aa-56f9-4842-b667-8d7b5c9d3e02	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	294f5260-6c73-4415-9196-d95f005790bb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6946f7c8-a78c-415f-9bde-fe58f20aae42	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d9ed67f8-d69e-441c-840f-752a6b40bd26	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4f264a35-cfb0-4c52-889a-44590b9b8b8d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7d8f033a-b8dc-4234-a758-5c401c1b69fc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	faa09e9f-fc85-4dfc-8ca5-9c4ea1043a11	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e0d6837e-b854-49a6-ba15-23e29619e81c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6710c623-a245-477b-8268-eecc6fcf876b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	20885dd4-e791-40ea-9f9b-4571dd959b83	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e4ace075-d690-42e8-8430-01a8fa9e13ae	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	75ac5cce-e9c5-4544-8d5b-72c1fc3622d6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	646429bc-10c0-48a0-bca7-9d1f3ddd0a09	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7ea4ad92-2ff1-40b8-b71e-a22a01ce162b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0eb279fa-b6c6-4e2d-b050-82ea0631c1d9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2907d0c5-27f4-4ce4-b6fe-334626688c45	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	90a17eb0-6242-46b4-9b55-960791d1d9c9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	deb3a50e-c197-4ab9-ba23-611cc8014412	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3f1e4adb-0095-49f3-a87a-b917419410d7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c8f60ebc-38df-414b-83d8-01e551347e90	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7fac1587-989e-4b31-b155-40e4e28b907f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	37197ac0-1809-40b4-af13-a58b5cbdc795	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fe78983e-74c6-4ebe-86a3-00711dc74175	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cec60167-5fd1-4f27-9897-b722fb54534e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f026f048-5b29-4b4e-b95e-ff6eb7267137	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6e1bf8bc-ccbe-42d5-b42f-7e6adb53c9c8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	21dee80e-d8dc-4409-9372-c60dc1e71cd8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f09cf8d8-23da-4e62-ae56-61b34820de41	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5c8c0ef5-33bd-4141-ab4c-1314cef089c0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e3d3c5c9-ffb5-49f6-b5e1-28a6fd63d729	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	86626cfa-5620-4f52-a530-41efc55ef896	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2f229a24-baf5-451f-931d-17429fdbcf10	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1fb8e26f-8700-4ad6-91a5-6d670223264e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	06dde5b6-4093-4058-a0d7-5867cfa26a94	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	817144b2-2c06-4541-917e-954b081ae85a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0646f558-b946-49db-b885-2e51eeedd825	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	48fc858b-c74d-4efc-a305-e347e53cce48	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	66981a07-954c-4511-83d2-bd6a3e377c39	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e91e6a6f-50c1-47b1-a847-7f3c23cae68a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	533497ec-ea83-4f69-b0c7-fba74522f8a7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	953f9441-6c50-459a-ad7a-80ca20fc0e8e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	98339e25-73b0-4143-bd7d-be833f6011e0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	da10422e-6327-48c4-995b-e6106a1ad030	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b5a0a8da-6a07-4b16-b206-6c502cea7ded	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	80457de9-b5ff-4126-8b96-71f54746fd40	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a8e0c9ce-4e68-4220-8873-07b3e174fc55	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	16b0291b-1539-4f24-ae8a-c45414c36510	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d4906907-0467-4dab-8e20-52e1c8baae9e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fcd2b07f-1bc1-40a6-980b-38e7c50271b1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	009e9f52-2e61-40b4-932f-0e131dd6f8c1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d76b309b-70a1-4935-8fc3-5c609012c3e0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7b14c334-7fb1-4758-be33-6b9b02e6e5fa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fcfe77a6-5349-48ce-b3c7-8093730393a7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2bc4a409-d6fa-4711-8ba4-d42ae723a6fc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d21829fb-a0fc-4cfe-8850-8b329dd00409	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9b458eb1-3887-4d09-aacf-0c4056f191a4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	318bc331-919b-460c-a42a-9294b5147872	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2fe35431-9313-4008-89a1-14c2dca09f89	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a02f8a09-8e60-41d3-ae57-31290ebff1ea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a5d09c5c-fcae-4ac0-a12d-cb25599807ee	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3bf67112-270f-493b-b325-fff48a5a9229	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	12379aee-82c9-4147-ace0-6645f3e75cb8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e4834c12-4554-4ff4-a8a4-c5a0c27a55c3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6844c638-1130-4954-b776-32a5ed83bb23	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d943d45b-849d-4756-a0f4-e90eddefe514	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2b19edd6-4c3a-4921-bbc3-24ef8204d606	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	88e6c1bb-025d-4320-8939-2616f71dcd07	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a9938736-93a7-49bf-942b-e180fce93253	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	febf33da-dd87-4c39-9676-71bc9e78e58d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e0e6b4a3-5856-40d4-a34d-4d77e3506b4d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b21307d2-04bc-47ad-afbc-5f3c63516e69	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b7c7443f-19c2-448d-9acb-82a4770f626e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	68d96d30-7275-4f54-917c-3cc0bba0e0b5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2511b976-6160-43e0-8fb7-f481aa7a942a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	97297d4b-9179-4391-bfa0-9d6671729e78	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	91af3b5b-d16e-4054-9b31-6b278102778b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	271b281b-57c5-4631-b187-4a46a85bea6f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ba586539-40b3-413d-9660-7ded48037558	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7d5ab67c-98b5-42c0-8d14-9e7bf4451014	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	83d6a617-bae4-46f5-9d29-c91172b29eb2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8a29f576-8679-4d49-ad38-f49468049c59	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	013a8f85-655b-4605-bd89-c5753b208e84	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bef7b45a-f638-4097-bfe6-91099e90e3f4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e608a054-194d-4b03-bbe8-b136d4e563ff	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4c2454aa-a2e0-4223-adca-a1669ad62a02	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b6a8bca9-2601-48f2-a84e-6c429ad28b57	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8378ac17-4000-477b-9a81-cb34ace6c9ba	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	956bd7e3-a78c-44cb-88f8-76be26c6b9e8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3b02fa01-e1ab-4875-b96f-19216052d179	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	55ea4b4e-06b1-4c6a-bffe-62f11d3b8f37	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	367957e3-36e5-42a1-8830-ff1068bcd649	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	37ad2ca7-9188-4af8-9d97-3d459c9b4ec6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	43413d05-33f5-4196-8fe8-fbeead68cc4e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6fe0fa7b-f293-46a7-af89-76586fb43a88	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	04e45746-ec9e-4246-8c99-d307b9319a78	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d52b9fcc-2d1d-4284-8871-227ebdca2187	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cc1b9db7-b1bb-4294-baf8-72de4c2b4ea0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9a9b4f53-9d77-4a92-b56c-910cb5f679c1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a5f015f2-7036-4da0-94f6-a54894f3806f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	411369a8-67dd-4438-88d9-d41a9c4dc5a6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7bf2906e-3608-4419-ba2d-9260dccff270	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a2ffd5d8-bb3f-4208-935c-119ed2595800	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b5957552-9b9a-4682-8e7c-08dc078cb3cc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	df9c7ab0-a0fa-4cf1-b8bd-f46f19121074	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	66ba4a48-7630-4ff4-8074-b22f3cd667a5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d7e3bbf7-ef49-4a4b-87e7-64abe01d89f1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eeda10f2-69d8-46b8-b826-d8e0171bde29	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ce3b5fb1-1ef9-4859-b805-9196c1df7fc0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c502d8d1-2565-4ceb-81e4-3fcfe8df0e49	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8bc2a8d0-28e5-4e0e-b893-865456e159f9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c9ca55ff-7006-4bb7-9b7c-c16d1de70405	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c7777459-3b55-470c-b4ba-2a923c687a38	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a9798a7a-6374-4a5c-9439-2fb10e1adcbe	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aa911249-08c3-4ef5-a375-65018744828a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	55ceca93-d6a6-4f84-8786-953df31dc4a6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	86234189-20bf-4208-bcab-69fe0e13a155	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3b5154ff-87a4-4e59-9c15-d25e04d341a1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e5bd49ff-31a1-4af8-a96f-e559f6ab56e5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	45f06fb5-4437-43b0-b38a-3dc367949390	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9a8df57b-ae58-4af7-a554-747b426f071f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4e804d73-854f-40d9-97b7-b76d72675a88	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ddae4668-cc94-4612-b91d-f91c2060a0bb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	33cfc4df-dd51-4c7b-8b1a-7c15cbb4f7d2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	de92105e-2042-4e48-ad3d-c8429e70e950	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5984b868-a5eb-4bba-b6c7-37782c657feb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fa27c4d5-7075-4690-add0-f7342e77347c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5977d93d-c1d1-489d-b82b-0d4bc7d82ea8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7fa6c91c-708d-434a-b58a-2579eaaa6856	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9634edd3-c3db-44cf-80ab-42e285d61f21	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7f10e653-23be-48b0-a3cb-a06e0898151b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2b68bb17-df65-4725-a160-5a44119ec492	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7236630c-200c-4c3b-b5a9-37f917e97520	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d23459aa-4792-428c-beb2-16624085980d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ba312a07-1dd6-475a-bb8c-b922d4188a94	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a50acd9f-fb68-4812-9136-fa6bd5afee86	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5da3928a-ed7f-4365-a8a8-3fd384658a70	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8143ea35-c604-499b-b7a0-a8b8f2e8fd28	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f1e9a303-fa8b-474b-8ce2-d33f78f79a4e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8d0e2a15-51d1-4ee4-8a1f-9b6dacee6d84	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c4c06366-0137-4e4d-bbc4-9c36159df749	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c3b90803-dd05-492c-8474-905bd25fe7fa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2a2274c4-9add-4720-a052-440bbf48ba4e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bc3dfb81-dc42-4112-92f5-cd71e9a05eff	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	69001fe1-feb3-4341-b0d9-a268b6da6904	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	98e3ab60-733c-4d10-a21a-8134c294645b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1948ee1c-63f3-4172-91b7-4e3b6565f872	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	43c438a3-4897-4dc1-87da-2d8a2c03834f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c92527de-ae27-46ac-93db-1c8c96a4fb41	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5a4e7fc0-6fab-499c-9a08-e852a78de7c9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b8b330a4-4b6c-4ee7-a59f-8947c086fe22	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f3feddd3-d875-41b3-88dc-45b530338100	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	34afc0ee-4606-459b-94dc-9c7d379105c0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ae8b9bbc-9874-4909-a16c-0aa51675766d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	74b1a124-6b6f-4890-8e6f-b3a082a6780e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c79c205a-84c1-4296-b8dc-f722ac6e4be7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2cdc28f0-a2a3-4003-9c71-3e73b1f595cc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ccbd664f-eb54-4a49-8ded-e7448645ea03	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7ff89f7b-af75-49bd-a509-95c599b177e7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4eca7254-449f-4597-9df7-57ffec2c690e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d84664ce-ae82-49f5-8a53-05c9a4d7cba5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a9b5bd16-c459-4e1b-b8cd-b75499c0212a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e430dd64-a3bf-4554-9d98-5e110b89d230	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9d3d0448-8f66-4dc7-b0ce-6adf9c45bf45	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d49d9373-ed87-4bbe-8379-fbf55d658832	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	09275bd7-6be8-4953-8df1-9b3ed697a4de	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2583dd2f-8591-4c95-b602-372feb3e8477	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6adcaa08-fe6a-4b5a-8c7b-d44c94557fd0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2f8f36f4-6755-47ce-8139-f82e5bf6ab1c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3edf125e-7794-49b0-9564-3ae59a0abe0d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	172e7fd2-273d-4a38-8edc-1bb039c7c03e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f1eef12a-224f-4bfc-b4c0-78f0f4365717	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	32df47d7-4bdf-4cb2-acb4-78ff37802e28	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a40e54ed-3d99-4dbf-a2e7-12ca5b9fec7b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	01e15450-5a56-429b-b81c-09bb1427f13d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7ae9f8cd-c5ca-401f-9bb7-ddc53b96dcc4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8894b09f-abe4-4418-8a75-567c2d127099	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	843e31a4-9be0-42ec-a07d-4dacc00400b7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	045d017d-449e-4fff-9d12-f2dd4bbad635	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1b8eb69e-c20e-4dbb-b573-0df704fd632a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8b2a739f-f9c5-42ae-82a0-7e790f25cc77	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bfe35292-20ff-427a-a6c8-c9fe91fb85b3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	44f45d52-a3dc-4bd2-8751-896f42240291	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ece029fe-6262-40ac-80ca-39ce1b745acc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5951879f-237e-4d16-aaf8-f7b2f91f760f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7e053ee0-763f-4fed-ab98-428845d7c2e2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	777c9417-2f89-43dd-9176-f6e577a8579d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	32931da2-7f1b-45f3-b8b6-693c85a78214	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ad8bbdd3-1f75-4836-ad56-a27f0a01e292	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a872b924-9ec3-483b-b750-2db2e38153b1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	794fb74b-0a23-40de-b6f7-13d88c33f55d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	33745e62-1dbc-476d-a0a0-94bb7ad26eb2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e78e5683-e3db-4078-b32c-b6982f436bac	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	da04ad6f-b312-4c12-8157-d5a88925c692	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cf1f7b7e-1ea7-4b2b-bfa3-9c26945c42ba	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c17c0424-eb48-4764-bd45-1c5ca21b0253	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	48491ed0-e0d3-40dc-b7d9-8534da3dee34	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	839da72a-756e-4202-906b-6d1dc4a263fe	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a6d65792-cb28-468b-b386-f507bfa6bc8e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c3ab3508-f352-4528-b837-d5bbf978d697	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ab9624e5-b9f6-45b8-af1b-009ede398d86	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	55db4ace-61f3-4e5e-af33-aef22de617c4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0b4ab5d7-8212-45a3-8659-c1c868e2a8df	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5a67854b-b76d-40da-848d-c609d428dba4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fac82fcf-b132-4678-9882-5fe21ee0a9b5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	25521bcd-f491-4996-bf43-70c39f3d3d57	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	503680ee-aa27-4c8f-930c-0b179163309f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	392073c6-cc2d-45c7-8020-881460c0d9df	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	10662b93-a8e6-4518-8eb3-f9b256915fcc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0b04c86a-f7db-4f0e-bdb2-0d6c7ed6f466	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f84d58c1-1cc1-4cf9-a03f-cdb54ebd7a09	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7c7c913d-2347-46e0-9129-5c8c7963fe47	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6c903dd3-55be-4942-b8d7-6acf379830f2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f1e968e2-4935-43ee-b126-ae55ae053269	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3eeda450-f14e-460b-aa1e-7e880db3b9a1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0266701c-10e1-47d2-a950-556be5d801df	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	03ec1cea-a4f6-4c00-bb0b-17adaaed14fa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4edb86c9-2d44-482e-94ea-7d912fb462e4	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	580b1527-90fa-48a7-98d2-f60a2aec37da	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	edac3ada-a2b4-4dae-aafc-314c8cbe9b88	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	850dff23-444d-4cb7-a9a8-e92259725eae	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cde99b41-2a0d-4f1d-9c45-975637fdae58	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6cba1cf2-368e-468b-96a9-d53372291683	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d2bd2922-2739-40d7-b7b9-f9399cf4eb5b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	267b9164-aab8-41cf-945f-62354f22bd10	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	59202f74-f468-4ec3-8819-b1c1e2739762	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7be81cc9-8dd7-4ae5-a8e7-5e094c69b4c6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0131194a-d752-45f5-98df-aa7d4b966495	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bcb676b8-9361-405b-9293-5f63be4e703b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	54e1c2f9-cc6f-43b0-96d9-8ca4d41453b6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1514fad6-240a-44ee-b5ee-632e3b23eaee	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	232afb75-423d-445b-ae5c-5f12238c0be2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ec81dca5-052b-4b58-9851-6667a27f3c97	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	062db79a-115b-43e0-809b-c61cbc101d08	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	69048971-72b8-4338-9e25-5b0ddfa88a12	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c8ed86f5-ce14-4069-a332-0bf43a28b9eb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9a84d23e-75e1-4e32-bb7d-41d4e6a0da62	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2f99d846-95d6-46d3-bed0-c7ebb9ab0d92	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	964b7732-3757-4701-be61-f2a8fa64095b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fb4498b2-0a0a-45ea-8a03-86e88b97ab87	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	abb57291-1b9e-4528-8aa8-ce1173490c6a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	101fdf4c-274d-4940-bca5-d9c946a88f35	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4c96467d-f886-443a-a248-affa29a7ae19	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	30938453-4723-4d6f-967f-4eb7366bf31f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	50e08104-c1ee-4229-8429-5101c39b6d79	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d0282329-30ee-4b36-b22e-339f2389511a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	15d576f8-a39c-4ec7-bf37-f3245f1fb3dc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aeb94a79-3c08-4948-87e9-a404056ec540	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1a04ca8f-5d4b-48d0-892e-2f4434a2d723	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	0ba75724-da4d-4646-a6d4-e0131f922587	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	78bd3daa-4af1-44b8-8eac-0900ff7cb297	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	39c0774c-1855-45b9-87a8-69ffb3701392	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5380f69b-72ce-418f-ab76-d4c6252a92b0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b684edce-c6f8-426a-a929-b5d367d7e8d7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bedb1e39-a308-490a-ba73-c1507ea219c2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fa723e87-1395-4aca-9237-10ac9a57ee5e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	45818393-8aa1-4b91-911a-1afe36d94aa2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4a3900d4-0018-4fa5-aa07-14664fc15457	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f7110152-0258-4661-9227-70eab5916f73	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d7383cfa-0340-4b30-9deb-821749cb6652	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	98622c44-196d-49a6-bd4a-4b7e4fd11666	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ca78cc46-4dac-4ea4-866d-5eee21afe13d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a7f8f58a-d087-42cb-8ea6-61c3e9a07d16	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b5b41188-23f9-4b8c-94b4-5874f9e20bea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5c1fd4b4-e938-4409-8676-c07461a78592	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aa3f9c3c-649a-4056-a5eb-2ddcdfa91d0e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	35b8ea5f-f3f3-406d-b97a-af26d7e843bc	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3c8ae7d8-f5d7-4dbd-bbcb-e9399400e62b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	58eff06e-93f7-46d3-8377-5367652a0008	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4e0310c4-82c9-493d-a714-f1b67716510b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5723409b-ff89-4020-bb52-da7ef3fdf75f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	49cd8606-84d2-4b74-96e8-71c6a27cdade	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c3902070-0a29-429c-a0da-c7289f6aa24e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e8187b78-17b3-4db9-bded-6969db485bb7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3804bf4b-84ac-4353-857a-7199a4e17d05	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c3d16092-389d-4893-9c0c-ef642d93b91b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a9fcb6aa-3ce8-48ab-a0ea-4c2dd49ffb17	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	960bc690-d63e-4487-921e-83fbfc1f92b5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	eb46ecc2-c83a-4dc3-a2c5-28dc68132cc3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8a8900fb-31ac-4cd9-9e93-eb8d73c39ebf	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ce453dba-d80e-4771-8d33-59b8341ccd0b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ff36ec23-af8d-45b4-9a37-efcd0dd4b923	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	168b2e7d-f672-475e-8b5f-57fe73ccd6de	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	afb3fa83-3a66-4c5a-9e2f-f0cd7d813749	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5f9c0a91-658f-41f0-9523-9ab2b3c58929	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f272fde9-ef6b-4fc1-bb26-5498354b82e3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	24759246-4008-4e6a-84e1-b2abf02cbde3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	08a7eafd-46a2-47d1-a482-28f7a6d1d6ee	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cc174785-b39a-4796-9565-1ce7fe4696b9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6a3efc4c-a6fe-4fb3-9ca1-c5b2cac3251e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4ccdf7e0-ae8a-41ee-a29a-211329cfd778	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c30146fa-f946-4f2b-af17-7bc71694e5ea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	40bc4a3c-ff77-44fa-8c5d-6ce4307a18f2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5c00d601-fd62-409f-882c-8ffa89aafc4f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	01de6495-85a2-4eec-be1a-a69efcdf99ea	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	72624182-b481-4779-a41e-b80fa310eb84	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3770a867-0f44-4873-a418-62139e5393a9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2c1d27d1-1d54-4489-a780-eb9c56e67c01	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	41b622cf-c723-4c96-a24c-24fc3f08ebe3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	78fbc412-c95e-4e42-a17a-5773d73774e1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3e2033bb-34fb-4693-bb5e-e367af2f626a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b9e62243-f9b8-4fdd-b1bb-505a40ea5af1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	983a05eb-f14c-42ae-a3be-c6d2e34ad1d0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7b7c1cd5-c3d0-4e9f-9a16-277e62c997ba	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a39ae325-13b9-4f48-bc54-fd126d4712bd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d5fbb4e3-26e0-49c4-b428-bb44eeeb41a2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2e5479a1-797c-4d3e-96f0-5b4ac46b9092	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	3da0b417-e73d-48c0-bf5a-4d3dcae4bebd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b047800d-1cf7-4c3c-9942-0a1842b3dd08	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d1743946-021d-439a-924a-8574bd4b9988	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	13658522-b5dc-48f2-8f2a-d7e0debfb19e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	67d632dc-d8d0-406b-beef-472d3f9164cd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dc50d5ec-e123-4df1-bdc2-e057bbad5a3a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9b7e89f6-e91f-47bb-97b7-97e34155e1fa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	14942e67-ae28-4bf2-a9fa-f67cd8f4767b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ecbf4abe-bcc8-4e4e-82d3-d807a9cd38db	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	580b846c-b358-4288-9b61-b6519fff624e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	658eb2ce-8a38-4c61-8706-95a1e0674067	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	32f4462f-b2e2-4436-880a-b5aeebe6dbcb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5bff4f92-a826-4d08-afe4-75fdb9614647	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4acec583-dede-400f-ae67-8f6a99c4135c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7a57df41-e0ec-4cca-9c94-eba4ca06fe58	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	303229b7-b86f-4df8-a02d-d197b4cf0484	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6c4d2ee1-e121-42d8-b891-8d47b78fdcab	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a051effe-6568-4ffb-8d80-fa27f462fa19	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ff80ed49-ddfa-4b93-8acc-34a9bf186da2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2253dc7f-c302-4a74-af27-b5fdb26f6722	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6bbab1e7-cd92-41d4-8a6f-f1a8f9a24447	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	49c143fd-ba12-4367-99e9-fb9b93d16eeb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	817f3abf-8b60-4e41-ad3f-116b3491cc2f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e02eb922-9b43-4c78-9c95-23670fabb2db	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	68b087bd-6501-440a-be6e-33d99a78203b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	68d4d863-607b-45f2-bcc5-aca4e4516dba	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e745cac8-9415-4e23-b3a0-a5993c4f374d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2be70162-7bb7-4d80-a364-b0b21811f6c8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2bc8a1f7-ccf4-4937-bb7f-6200e07cb8f3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6e961f90-c999-4b5e-93cc-2755f2023f10	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	636d4e26-b3e2-4ae7-a032-229a4a8a7841	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ac116969-5777-401b-a20b-35cd1fe1926c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	67831c39-8c38-4cd9-adfa-a9cbec794e2c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c3c6fa15-32f9-4d98-aaa6-49264d1b7313	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	80311410-6609-4329-911f-f6e9f0acaf23	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5eca91e0-af50-4999-9a05-2fd8d696300e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2df54da6-ee63-4bd2-8124-d1de88d8d59a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	53b99751-94b8-4812-bb66-a9a6184afb24	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fd02f665-2a01-4829-ba04-ca3e7c9de378	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f5547113-8057-4ce1-ae98-572d9004b4fb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b8b5ce2e-2430-426f-8cc2-36e873f66539	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	15ef228a-4ce4-4914-86d4-8743320f3c45	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	11083df3-e024-49c2-a9b7-812aef55a882	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cab775e1-2108-4a21-84f6-c37c4e25c4b5	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aa3a5070-12ae-4a0f-9d18-f57aad030a37	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ec557fbd-dd4b-426f-9802-08f17e53de5b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f052a97d-8f42-4ef2-bd0a-8c1647fcd040	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8581a771-d999-4f96-a29b-c9ce95fbafbb	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	414ef850-468d-4775-8f69-9d6b445515f6	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a2235068-27aa-4cdb-8186-8dc5f34b9906	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f9856349-66de-44e4-a348-5726f6ad4677	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fff2deec-1d88-4469-a790-ece3eb6a29a8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	190c81a3-8393-4cb1-9c04-5f2ad649af5d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4853e6e1-0c01-4cd1-8321-9c769e12735d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c633a0b8-53af-4170-b568-a8657b2a5c04	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	16be4633-23e1-4325-9dcb-3e9784302eb2	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	4fc78ace-01fa-4e7b-8bfd-cda3ed05ac48	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	13effc0b-81d0-48b4-9c9a-ed2995bd9130	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9e236ffe-149b-4f50-9a87-4e9814244bbe	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	856e33cd-3581-41cb-8d9c-44cf0528ab0b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	461ffd40-0094-4112-bd63-c6dca34085d3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c49d284d-a327-4c73-854b-3a74d181105a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	92e9fbf3-c400-4030-b9a4-34c29ebb67dd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	2c9b3eca-e592-4e7b-8325-fb0e858ab64e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bc86cc45-56c8-4915-bc36-110f30eab9aa	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bcf0e340-cecf-4cdd-9931-6a530d48f6cf	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	51022719-092c-4fac-b670-49ac8ab83a77	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	58c402e8-0edc-440f-b449-72f554a4f09d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	19a6d6f4-803d-4e51-9610-d3dde318b566	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	8a011a76-e565-459f-ad16-d1e1b261828b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	079581ab-d7d3-4719-837d-33ce4bd4ddd0	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	83120ae4-ec9d-42e5-ba97-4992b821337a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	44f3e8a4-1bcf-4be8-9eef-173178527b73	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6def9c3f-c2ac-47e6-be24-270767260bf1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b171631b-7efb-4c03-82a4-469fb499044b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	62f418c6-0e01-4f6c-995e-a97da16c11a1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	bf5c9fd8-7a08-4e1a-8838-bc69ea3271d9	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e06dc873-56c7-4336-b870-63a9ead79648	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6b8b687a-b96a-4b8b-b9b9-4df42e0d7b84	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e4940665-621a-4cae-bcfc-6eeb6e0cfc6c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9e01ba74-2e21-440b-bd7b-bc75ed9e0f4d	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c64d3bae-9693-48f3-bb39-1ac8cb1f3fdd	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1c883f18-7d3a-4cd8-916a-0c79c594280e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	71674950-7ef1-4281-8976-529892e61f26	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	f681e57a-aadf-4711-9985-f3b90ad82a4a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	06b5af3a-8568-46af-9ba9-8a4c2872ff86	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a5a62714-4c98-4dd2-b023-7d50bd156166	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a859a422-34b9-4702-a7a4-7d06900efaa8	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	ac0ffea6-a0b5-486d-866a-6ba34337d202	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	c133dc2a-a880-4aac-b3cb-f5eee2d7a956	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1ebe3270-8fb1-4d44-bfc4-f028c53550e1	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	cef7d121-7d38-4acd-90f7-596f2eef92f7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b7b53077-3762-4f75-ba3e-687aabacb536	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	58084aa1-ad0b-44b4-9625-8bfbcd706c85	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	b3c44503-8d14-4940-b8ff-92e12f0330d3	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	a8b5e958-a6c9-45b4-b1d1-b9bc24436942	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	85ebece3-d64e-4319-8c01-74cac6f0e8f7	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5a956f8b-aba8-4fe0-b9be-d45f3ba78d5b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d504c18e-b605-4527-b9ae-08df1d8c998f	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	e650288e-a22c-4d2e-9f3c-e183beeb6d1a	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	aaa2e854-33fd-4132-80d9-11c2e17b5d66	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	1130f587-8c1d-4f85-822c-119811a2aa61	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	5c69b68a-0953-4860-842c-88164ea83776	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	dfd84fe3-f42d-4af6-b45d-8d6f24fc6691	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	49eb6481-e64c-4569-9118-78c24d76409b	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	fa720e0d-e494-4d9e-87f6-62a609e9a103	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	addc323d-1303-4ac8-8708-e0b0264a7469	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	d85e107d-4e6b-4e82-bdd4-873b80d8e10e	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7b33f3bd-439a-4c29-bf7c-ef476b666594	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	7bed07ca-f474-45bd-a838-f7d17efbd062	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	9738a126-0112-4e48-a33e-c03f1212713c	2026-11-08 08:11:42.343822+08
2ad18844-4410-455b-b26d-f8dcdb10db09	6b51d9ea-d6f0-49aa-9815-ba2676e98129	2026-11-08 08:11:42.343822+08
0c000000-0000-4000-8000-000000000001	a8e0c9ce-4e68-4220-8873-07b3e174fc55	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5fd4c317-345c-4082-acd3-86b2d1a628d0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a8b5e958-a6c9-45b4-b1d1-b9bc24436942	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bf58df65-0a9f-4350-8ebf-6f935cd76f55	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0fde9d79-d70b-4d67-98e5-39013bca2049	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c133dc2a-a880-4aac-b3cb-f5eee2d7a956	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4b3b52c2-6275-4a92-9605-8542cce2c447	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	51c19f90-6687-4771-aedd-a46847a2e3a4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	546fe75c-e5a5-4504-b119-0c7606b3f601	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9b7e89f6-e91f-47bb-97b7-97e34155e1fa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	96b56a30-f52b-4ba5-aeee-b887d80dac17	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	85ebece3-d64e-4319-8c01-74cac6f0e8f7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8d0e2a15-51d1-4ee4-8a1f-9b6dacee6d84	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5c1fd4b4-e938-4409-8676-c07461a78592	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	960bc690-d63e-4487-921e-83fbfc1f92b5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	646429bc-10c0-48a0-bca7-9d1f3ddd0a09	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d7e3bbf7-ef49-4a4b-87e7-64abe01d89f1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	013a8f85-655b-4605-bd89-c5753b208e84	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	55db4ace-61f3-4e5e-af33-aef22de617c4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	edac3ada-a2b4-4dae-aafc-314c8cbe9b88	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5977d93d-c1d1-489d-b82b-0d4bc7d82ea8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e66d1aaa-4a3a-4e49-88a9-c6752fe68b13	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3804bf4b-84ac-4353-857a-7199a4e17d05	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0b3fcb81-17ac-410f-afda-0813de7613fa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	eb60c8ca-b38e-47f3-8146-bdf18701e15f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7236630c-200c-4c3b-b5a9-37f917e97520	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	010ae5d8-3f48-49d0-bef3-5e4a8f5d10a5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4d384c77-8040-4971-ae47-51b53e37843f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dd45992d-1935-4d08-a87d-a92079ae1539	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	001ceb18-bfdf-4c96-9de2-45dfed32d0ac	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	936aa7b2-c830-4231-9045-08c0b6a7ccaa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	01e15450-5a56-429b-b81c-09bb1427f13d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	808a44a1-7906-4bb7-92e7-69cd0c45c9c8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	455aae0b-d0c1-48ef-8193-4ed35482702f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	762d54d2-5f86-4e60-ad17-87a38d8984d7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e736e259-e2c0-49e7-9f72-a8b53000bfd9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4e6e1cf6-3460-4dfb-9132-f68183f530c3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	636d4e26-b3e2-4ae7-a032-229a4a8a7841	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d9f4aab1-3bf8-4fef-bb18-d46f5e0cc5e1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	01f82c34-63d7-439b-9960-77cf6d630db6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9a9b4f53-9d77-4a92-b56c-910cb5f679c1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c0e150ca-03d8-41bd-bcdd-ef8ebbdc754d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2ff29ce8-ef9e-4548-ada3-7d9f4d31f4b2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6710c623-a245-477b-8268-eecc6fcf876b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	945f8e67-6a22-4cd4-8392-c78f5e6ef327	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f84d58c1-1cc1-4cf9-a03f-cdb54ebd7a09	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	190c81a3-8393-4cb1-9c04-5f2ad649af5d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	27412e21-3e81-4d36-9c9e-a99f3d38046f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f0d65596-18de-4dc4-b72b-8a79818a207d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	07cd1e24-e4a1-4dbb-b25e-9f6f88b9367d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fa723e87-1395-4aca-9237-10ac9a57ee5e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3ce5e888-9e7d-4b00-b7e3-e4339f3424d8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cfeab591-d11a-469d-9b99-4ba15bc8f49a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c3c6fa15-32f9-4d98-aaa6-49264d1b7313	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d4906907-0467-4dab-8e20-52e1c8baae9e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0e2a882b-9d5f-4652-b4cb-3fdbf1ae5316	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	41b622cf-c723-4c96-a24c-24fc3f08ebe3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	10921a0f-4d4c-4a8b-80f7-36dd49329e08	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1c7b23ea-b36e-4ccf-9da0-ea25555afcea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6bbab1e7-cd92-41d4-8a6f-f1a8f9a24447	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4fc78ace-01fa-4e7b-8bfd-cda3ed05ac48	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e06dc873-56c7-4336-b870-63a9ead79648	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	83120ae4-ec9d-42e5-ba97-4992b821337a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	571c2e47-915a-48b8-8bef-d07e887975f9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a02f8a09-8e60-41d3-ae57-31290ebff1ea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d7a1a601-c219-45c9-ac46-9a59c25bd468	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2c9382d8-5ae1-4624-ac4c-915cf8ee2b8d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fe70ea88-828e-4738-9007-3dd1fe53f8ea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	168b2e7d-f672-475e-8b5f-57fe73ccd6de	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6fb10e1e-f330-48c7-ad0c-feca214c574b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	10662b93-a8e6-4518-8eb3-f9b256915fcc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b5b41188-23f9-4b8c-94b4-5874f9e20bea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	009e9f52-2e61-40b4-932f-0e131dd6f8c1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6c32eb6d-4e11-4d46-a975-74bb96409c39	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6869a699-602f-4d2c-8150-26c975d94562	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6d6e5327-5026-487e-b845-04d4fcf2923e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	98e3ab60-733c-4d10-a21a-8134c294645b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1e5ab521-a55b-41d0-8ec9-58406058fa61	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4bd8e98a-d4bd-49eb-84cc-bf5fe790b571	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	509148e7-f34e-4e44-b637-0b83085ade65	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	165d6ddd-16a4-46ed-b0f8-2ca7a777ac7d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fa720e0d-e494-4d9e-87f6-62a609e9a103	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	03c480ab-e62a-45f0-b159-1c0b882934dd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5c24b0ca-ae87-444e-ae30-de8e099cebed	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ed8284f0-b8b8-4ae8-8ca4-ef91de0d0c34	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ad8bbdd3-1f75-4836-ad56-a27f0a01e292	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e745cac8-9415-4e23-b3a0-a5993c4f374d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1edeb642-b711-4af3-a5ca-d48682dc2442	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3e2033bb-34fb-4693-bb5e-e367af2f626a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ecbf4abe-bcc8-4e4e-82d3-d807a9cd38db	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3b2e6c70-8248-4075-b0ad-4b9f613dc6e0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4c2454aa-a2e0-4223-adca-a1669ad62a02	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ca69cb47-4c0e-4e29-bcb8-afce2c41fb47	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5ce25f80-91f8-4f98-bc09-28e2d63cc39a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	48ed375b-8c51-40e8-b400-4969107d8add	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	655d7299-4fbb-48fd-9a67-b4073fa4dc5f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c8ed86f5-ce14-4069-a332-0bf43a28b9eb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	19a6d6f4-803d-4e51-9610-d3dde318b566	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	faa09e9f-fc85-4dfc-8ca5-9c4ea1043a11	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0840d1e7-a0df-49eb-889c-05090219c464	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2c8614cd-e470-4f92-a189-19a06080c19c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0820e071-6289-4079-bf92-919475011b3d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9230a691-7d05-41b2-b03c-77c786a32c35	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9e01ba74-2e21-440b-bd7b-bc75ed9e0f4d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a8ba07cd-57ce-4bca-b956-788e42505749	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a47e6e07-4923-4574-b03c-51863791b181	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f272fde9-ef6b-4fc1-bb26-5498354b82e3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bef7b45a-f638-4097-bfe6-91099e90e3f4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	850dff23-444d-4cb7-a9a8-e92259725eae	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	473919fc-b929-4a5a-be7e-78da5ed172d8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dc5e30e2-9930-4122-ab9f-e09eb611c355	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	68bcb990-8045-49fc-887e-b05b5eb3e85c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9634edd3-c3db-44cf-80ab-42e285d61f21	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0b3b1209-4d33-4d56-b806-7492c6bb4707	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2c1d27d1-1d54-4489-a780-eb9c56e67c01	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	52ae7693-c712-4ce9-95ca-89afbbac2134	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2d8a31a6-9597-4ca5-8b8d-9159f13ecaa4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d1743946-021d-439a-924a-8574bd4b9988	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1f6fc74d-714d-4cbe-85f9-938e660447a6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c30146fa-f946-4f2b-af17-7bc71694e5ea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d23459aa-4792-428c-beb2-16624085980d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	432de1f9-6cf4-4de6-9cbc-8abf02ea5cdb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	60bd83c4-7428-4aab-bb88-fe8c3f2c44c1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4ccdf7e0-ae8a-41ee-a29a-211329cfd778	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	44f45d52-a3dc-4bd2-8751-896f42240291	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	eeda10f2-69d8-46b8-b826-d8e0171bde29	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d0282329-30ee-4b36-b22e-339f2389511a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1c883f18-7d3a-4cd8-916a-0c79c594280e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	57ff869b-2160-4a3b-a3eb-8e060eb0d324	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	86626cfa-5620-4f52-a530-41efc55ef896	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	86234189-20bf-4208-bcab-69fe0e13a155	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	58ed58fc-8ed9-4838-b805-3d444871295f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a4136bb7-debb-4a75-9f25-524a3b8a867f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8835b668-5fe1-42df-ad09-97a240456194	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bcb676b8-9361-405b-9293-5f63be4e703b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	16be4633-23e1-4325-9dcb-3e9784302eb2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b5226662-612c-4cd0-90a3-09f75dd42754	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c86e5223-8208-414b-896f-bfb08ff6b6f2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	17b4d5f8-6168-40e9-ae1b-e795f48971ed	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	68d96d30-7275-4f54-917c-3cc0bba0e0b5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4e804d73-854f-40d9-97b7-b76d72675a88	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f528110a-0afb-411e-a327-ba222408c203	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	76782c91-0742-42da-9034-59f81deef065	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0646f558-b946-49db-b885-2e51eeedd825	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1b9fa8b9-cff4-4077-9bb3-49a355646df6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	54e1c2f9-cc6f-43b0-96d9-8ca4d41453b6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b36cab3f-ae9b-441e-8cdf-d6e7b85bec7c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	80311410-6609-4329-911f-f6e9f0acaf23	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	21c7c4a2-4a09-4c3c-893a-9b1859caf588	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	504736d0-3c4a-42d9-b326-69d5bf2997fc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c3902070-0a29-429c-a0da-c7289f6aa24e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a70adb6b-9b8b-427f-bc0a-298ce53671f2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1ebe3270-8fb1-4d44-bfc4-f028c53550e1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c60449b5-1573-4724-a73c-9c9dcffe4c79	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8b2a739f-f9c5-42ae-82a0-7e790f25cc77	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	35398804-0d24-4496-9a55-87bea11db0d5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	076d6603-658f-4e97-9899-adc20cbe704e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	55da5d18-aa58-4e11-b336-03af4f66e028	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ece029fe-6262-40ac-80ca-39ce1b745acc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c04d939d-58f1-49e5-80f0-3221da1db59a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	839da72a-756e-4202-906b-6d1dc4a263fe	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b48b4996-b47f-4b1a-bd5e-a2cc8fab92b0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7ecb7277-6d10-423c-a286-1e891cd1a2b6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	45f06fb5-4437-43b0-b38a-3dc367949390	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	98960006-df7c-4e56-a451-ad51b5af29ae	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	35b8ea5f-f3f3-406d-b97a-af26d7e843bc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6eafa6e8-3097-422d-a96e-c6ba2957b3e9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6cba1cf2-368e-468b-96a9-d53372291683	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2cdc28f0-a2a3-4003-9c71-3e73b1f595cc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	889484a7-bcb1-4910-b9cc-28a83433a468	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e650288e-a22c-4d2e-9f3c-e183beeb6d1a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	630e341e-2360-403a-9acc-062e6929e1aa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c3d16092-389d-4893-9c0c-ef642d93b91b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b8b5ce2e-2430-426f-8cc2-36e873f66539	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6fb2e2f6-36a8-4971-a66d-352ffe5b5f22	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	da44e650-cf58-432f-bb29-2672f67d7cf9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	843e31a4-9be0-42ec-a07d-4dacc00400b7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	70c2fff2-f8bc-45ff-898b-2e6723f83b20	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	12379aee-82c9-4147-ace0-6645f3e75cb8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b6b500e7-9353-4331-94bc-6eb6db3175ca	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	90a17eb0-6242-46b4-9b55-960791d1d9c9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8bc28040-f8c7-4110-a5ae-0fe4d983cef5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	47550e3b-a7ec-4234-8df5-f7faf2ef7bb9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4491822c-0dfc-4d8b-9264-155b6b5c4d5e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	964b7732-3757-4701-be61-f2a8fa64095b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3770a867-0f44-4873-a418-62139e5393a9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	817144b2-2c06-4541-917e-954b081ae85a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2c0f6c33-00f2-4879-bedd-10f35ee1d71b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ec81dca5-052b-4b58-9851-6667a27f3c97	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	67d90528-2e5c-4da9-b89a-cc87400b29a6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	36ce793f-53bb-4756-93e3-b46fd906942d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	53c99369-cad6-43db-8b02-6f7813dc589d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	eeec0ea5-873c-4374-a415-3c1d86b58c30	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	294f5260-6c73-4415-9196-d95f005790bb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2a9040b6-0dba-4c99-9a13-bc959b53cfe5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c31ecd18-bfc5-4621-a780-3bf5b288d816	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	68d4d863-607b-45f2-bcc5-aca4e4516dba	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4acec583-dede-400f-ae67-8f6a99c4135c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	be7d0c87-c89e-41bc-bce3-6a29f8c36749	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d504c18e-b605-4527-b9ae-08df1d8c998f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	58d47305-af48-4101-863e-e0c6340e111e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	47b50520-05db-4c39-8b89-72cad268b55e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	983a05eb-f14c-42ae-a3be-c6d2e34ad1d0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f5547113-8057-4ce1-ae98-572d9004b4fb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dab34c1c-9858-457c-883e-696dc1d953f9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cc174785-b39a-4796-9565-1ce7fe4696b9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8d6e736f-13de-477d-8d35-6274ae221c2b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0bcad886-044b-4a10-9d41-d6b7632d9df1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d943d45b-849d-4756-a0f4-e90eddefe514	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	67831c39-8c38-4cd9-adfa-a9cbec794e2c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4fe66c9e-36e2-49b0-955a-17cf9d138779	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bc3dfb81-dc42-4112-92f5-cd71e9a05eff	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aa911249-08c3-4ef5-a375-65018744828a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5a67854b-b76d-40da-848d-c609d428dba4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ca78cc46-4dac-4ea4-866d-5eee21afe13d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	475ea8a1-15a2-4119-876b-662cef417d80	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	58e208a0-d672-4c93-805f-d2ca15802e03	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	df3da25a-405d-4a20-bf27-ffcb5c6c7775	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bfe35292-20ff-427a-a6c8-c9fe91fb85b3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ff36ec23-af8d-45b4-9a37-efcd0dd4b923	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c49d284d-a327-4c73-854b-3a74d181105a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c502d8d1-2565-4ceb-81e4-3fcfe8df0e49	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4a3900d4-0018-4fa5-aa07-14664fc15457	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d5fbb4e3-26e0-49c4-b428-bb44eeeb41a2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	580b1527-90fa-48a7-98d2-f60a2aec37da	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b047800d-1cf7-4c3c-9942-0a1842b3dd08	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	953f9441-6c50-459a-ad7a-80ca20fc0e8e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d522e713-a169-4b07-953a-15fac87a516a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e4865f32-f0c6-45db-9cc0-a69ad8c23900	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	68b9eb3a-80c1-48e8-9933-7252c8985688	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6ec53f4b-8f6f-43dc-ac4c-094353ca2e91	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c84ff030-06b6-40bf-868b-83d05eedca2e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	71674950-7ef1-4281-8976-529892e61f26	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	309dcb60-cde5-4d03-84cc-6f6c11b8d836	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3eeda450-f14e-460b-aa1e-7e880db3b9a1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5653bd54-d986-484f-aacd-6b00baebfdcc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e70982f0-0001-4900-8bd8-0bd41abc85c5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	65e18ea1-190d-4f51-a8a5-6aeaf5e74b27	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	78fbc412-c95e-4e42-a17a-5773d73774e1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	172e7fd2-273d-4a38-8edc-1bb039c7c03e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5376af21-342a-4e75-a591-1776a8b1c706	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	016d98a5-b27f-4ac8-828b-26343572d93d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	67d632dc-d8d0-406b-beef-472d3f9164cd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9e236ffe-149b-4f50-9a87-4e9814244bbe	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cd047b78-93b8-477a-8027-eae22e0f49f3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	35119d75-1d39-474e-99bd-35e2ba2f8aa9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2575ddde-6b55-474d-a5a4-9c4e4047511f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	51022719-092c-4fac-b670-49ac8ab83a77	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f834bc54-300b-4d0b-8302-8a1f6d2688fd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	983eced3-366c-4b7f-a2ba-bf7b8de9e9f3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f6ff0668-762f-41f7-bd37-fff13fc51d80	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bc86cc45-56c8-4915-bc36-110f30eab9aa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b9651b0b-b17c-4d29-87b5-028e4359567f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a26c861d-0483-4a81-bbee-0f51554a92b9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	503680ee-aa27-4c8f-930c-0b179163309f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ce3b5fb1-1ef9-4859-b805-9196c1df7fc0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5da3928a-ed7f-4365-a8a8-3fd384658a70	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8380fdb9-60cf-4b26-8698-e2e41787d085	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a872b924-9ec3-483b-b750-2db2e38153b1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	25521bcd-f491-4996-bf43-70c39f3d3d57	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5bff4f92-a826-4d08-afe4-75fdb9614647	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2b68bb17-df65-4725-a160-5a44119ec492	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a9938736-93a7-49bf-942b-e180fce93253	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c79c205a-84c1-4296-b8dc-f722ac6e4be7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e4940665-621a-4cae-bcfc-6eeb6e0cfc6c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	42fe0562-b0b1-452d-b948-536ed2d536dd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	14486b97-172b-4b6d-aaf9-2c955e51da16	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7ae9f8cd-c5ca-401f-9bb7-ddc53b96dcc4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	39c0774c-1855-45b9-87a8-69ffb3701392	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e265ffa2-8278-4d17-a1d2-ece5c4e63f9d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3e61f288-9acc-48b3-b186-ac7185bfe31d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1733fdc3-eb98-49a0-b0b5-c2bbc2ab3772	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	97fd42c9-f9e8-4f55-b7de-c53a1e197e5c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8581a771-d999-4f96-a29b-c9ce95fbafbb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3e340190-e9eb-41a0-9151-a90a9a174a15	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	32df47d7-4bdf-4cb2-acb4-78ff37802e28	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5380f69b-72ce-418f-ab76-d4c6252a92b0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	da10422e-6327-48c4-995b-e6106a1ad030	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dfd84fe3-f42d-4af6-b45d-8d6f24fc6691	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7c7c913d-2347-46e0-9129-5c8c7963fe47	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	58c402e8-0edc-440f-b449-72f554a4f09d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8e2f0cd6-e10f-44a1-ac66-c2372ff9aba7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	15ef228a-4ce4-4914-86d4-8743320f3c45	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	17764847-06a3-481b-b84c-fc64ce0ef960	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d21829fb-a0fc-4cfe-8850-8b329dd00409	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	15fc7f5e-8b0d-4e4b-805e-fc08787fb446	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fac82fcf-b132-4678-9882-5fe21ee0a9b5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3f1e4adb-0095-49f3-a87a-b917419410d7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3435f0a9-c63f-47fd-914a-0157b0af83be	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	318bc331-919b-460c-a42a-9294b5147872	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aa3a5070-12ae-4a0f-9d18-f57aad030a37	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a50acd9f-fb68-4812-9136-fa6bd5afee86	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ec2d7f67-c805-4be2-81d4-108cdf7c9310	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a5a62714-4c98-4dd2-b023-7d50bd156166	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6040a799-1c4f-4ec1-8953-645540980bc1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ce88b7df-8249-47be-83ac-cac286a47624	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	367957e3-36e5-42a1-8830-ff1068bcd649	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aeb94a79-3c08-4948-87e9-a404056ec540	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cc1b9db7-b1bb-4294-baf8-72de4c2b4ea0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0ad56aa2-270a-447a-bb55-5c3e5b740862	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	363100c6-ff27-45cf-83c0-05109bd668cf	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	457373e7-b6f6-40da-aa8e-520c0018a26d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ff80ed49-ddfa-4b93-8acc-34a9bf186da2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d014f331-6483-4671-bc41-6236b06ba37b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5fad1a87-658c-4894-9772-72a1b0731d45	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0eb279fa-b6c6-4e2d-b050-82ea0631c1d9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4798d33d-62c5-4150-8235-63bc6389f7c8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6ac3d874-41b9-469d-a60a-b4bf8512a7df	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fff2deec-1d88-4469-a790-ece3eb6a29a8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9d3d0448-8f66-4dc7-b0ce-6adf9c45bf45	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c3ab3508-f352-4528-b837-d5bbf978d697	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1e38a460-8504-4fe6-b19f-ac4155bb42bd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aafd9e68-1a98-4a6e-8174-652e4f296ace	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d2bc12c6-ad64-4a54-b9e0-f7aa59ecf58d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5dd50086-a083-44e9-a7ac-78e011241957	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	19dd599d-6e4f-47ce-a045-d6df8b2a663e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a9b0dae7-d770-4ed2-bd96-52b643051248	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b7dd8d6c-518c-41df-9dd5-4a36fe4bc217	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	43233d63-bf7b-4920-9c63-d3dca088742b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	32f4462f-b2e2-4436-880a-b5aeebe6dbcb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c9bff55f-fad7-4e8d-8141-7761f0291798	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a7a34dc8-f4d8-4329-83ef-fb0382eb7950	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2e2c8722-c8fe-49c8-8959-4df4239c9044	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2bc8a1f7-ccf4-4937-bb7f-6200e07cb8f3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	98339e25-73b0-4143-bd7d-be833f6011e0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a91e3a12-46a8-4119-ab8a-63a67b5f7d23	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2cfba3c9-692a-4b93-8aef-fef6c03c333a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e38e4a7b-a918-48d2-af8c-4b12851b65cb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fbb8a65a-83ec-4eb8-a937-378ec1139263	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c9f30bdc-2c5b-4713-b2df-5a889d5a5380	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2edd77a5-3126-43b1-ad18-64ac1bb8ee70	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5c00d601-fd62-409f-882c-8ffa89aafc4f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3da0b417-e73d-48c0-bf5a-4d3dcae4bebd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1a27be22-9a1f-4054-ab65-7779d57381f3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9e9a26e7-d2b1-4fd0-bdd6-9361ffaf8ef0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6adcaa08-fe6a-4b5a-8c7b-d44c94557fd0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	55ceca93-d6a6-4f84-8786-953df31dc4a6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5c69b68a-0953-4860-842c-88164ea83776	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b5957552-9b9a-4682-8e7c-08dc078cb3cc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8bc2a8d0-28e5-4e0e-b893-865456e159f9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	17b9e9d6-8ea2-45b3-bcef-c5b9ebe9a6c0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3c8ae7d8-f5d7-4dbd-bbcb-e9399400e62b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a141f05f-088a-458c-90dc-7cf15f4b9feb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f939c582-9bb4-4641-bf88-72a01411c863	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	659ee807-6bb1-40f7-a957-8ab515a48f94	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	25709809-5abb-4ac8-9d35-c60a26c4be23	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	eb46ecc2-c83a-4dc3-a2c5-28dc68132cc3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	958a344b-8b88-425d-b5cd-f73810680d6d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	461ffd40-0094-4112-bd63-c6dca34085d3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c4a88d7e-87df-4141-8f25-d74773a2ddd2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	14942e67-ae28-4bf2-a9fa-f67cd8f4767b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	94690540-217c-4346-bcc2-c1f6c694662e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6844c638-1130-4954-b776-32a5ed83bb23	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	350c7790-b0fd-412a-86ee-e2defd30bcd7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	569b856c-d12c-4b6e-aa8b-651f569de24f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	16b0291b-1539-4f24-ae8a-c45414c36510	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	01de6495-85a2-4eec-be1a-a69efcdf99ea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	469185a8-8a14-4cd2-ba82-d1ab5241bd57	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	013eb45f-c4b5-4aca-b0ff-e5914bf89ee9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a40e54ed-3d99-4dbf-a2e7-12ca5b9fec7b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	11083df3-e024-49c2-a9b7-812aef55a882	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5eca91e0-af50-4999-9a05-2fd8d696300e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9924038f-fa8e-4be5-bff6-9073368a5471	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3fbf4e67-5d50-41d9-bb14-61ab66b74fd1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e388daca-c0e3-4396-b400-5e06cfa67472	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c633a0b8-53af-4170-b568-a8657b2a5c04	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9a8df57b-ae58-4af7-a554-747b426f071f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1fc6e8a0-b3bf-447d-869f-e61400ca395f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c8f7528a-b746-468d-998a-69d9fb77f8eb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	11f35f26-18f0-4a87-ad53-a19e182f301f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d4b29c75-7642-4342-8e5b-6b7e0c50ef3c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7d2623e2-e4e7-439e-bdfc-6440b5bb9c56	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	de3e8777-42ac-44c8-9a56-68f8e6b22f76	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ae8b9bbc-9874-4909-a16c-0aa51675766d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	09275bd7-6be8-4953-8df1-9b3ed697a4de	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	392073c6-cc2d-45c7-8020-881460c0d9df	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2fe35431-9313-4008-89a1-14c2dca09f89	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ab9624e5-b9f6-45b8-af1b-009ede398d86	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5a4e7fc0-6fab-499c-9a08-e852a78de7c9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	78de2802-d14c-438c-a5c9-f39a20ed8bc8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f7110152-0258-4661-9227-70eab5916f73	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8894b09f-abe4-4418-8a75-567c2d127099	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8d62857b-9efd-4d30-ba34-02e17f821fa5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2ca05c4a-9100-4313-a735-d4f3c5e75924	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	19b54313-877c-4b9f-ad0b-5343a9966292	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3ae80f7a-9350-44c3-bcfc-164be9cbadbd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2907d0c5-27f4-4ce4-b6fe-334626688c45	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	97297d4b-9179-4391-bfa0-9d6671729e78	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7b64ace7-aaa3-4b7e-b0b1-f3d6ae9db4b4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b9708b1f-0b9c-41b3-a699-5d101458ee70	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1deeadb4-e989-4e07-9d6c-b033e2989538	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7ff89f7b-af75-49bd-a509-95c599b177e7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	131d6ee2-495c-4852-9a3a-42b57690ee27	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bd763c66-dcd5-4dd2-89a0-9aac5980c719	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ec97e8b2-337e-4211-a6fa-c991f8f27326	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	68b087bd-6501-440a-be6e-33d99a78203b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	06b5af3a-8568-46af-9ba9-8a4c2872ff86	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0ba75724-da4d-4646-a6d4-e0131f922587	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	02549094-9064-43b4-9b14-4cdd00202012	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5bb222e0-7245-40fe-8b23-0c1cf908eb79	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ba312a07-1dd6-475a-bb8c-b922d4188a94	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2253dc7f-c302-4a74-af27-b5fdb26f6722	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5c8c0ef5-33bd-4141-ab4c-1314cef089c0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d2bd2922-2739-40d7-b7b9-f9399cf4eb5b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fb14a52b-6f41-4333-a3f0-ef935bc6adb8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	079581ab-d7d3-4719-837d-33ce4bd4ddd0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ee2f55e4-b0d4-4e23-a64d-296cd87825c0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	eb77fbf8-089f-402c-b935-bd4a911fcd3a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	404e380b-5e2a-4b81-a362-c18e4059b0fe	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d9502659-74a5-4b31-9e5e-f05bf09bc61e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3c2283da-8b6e-4f71-8174-e527becff9cb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7a579dc8-7d46-4ac5-a209-b3cce98718e6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	af0d82c8-c095-4d86-914f-b86216b9d8b7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	37197ac0-1809-40b4-af13-a58b5cbdc795	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a9b5bd16-c459-4e1b-b8cd-b75499c0212a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fe7160d4-8588-4408-923d-c75e27c32d66	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c59c8a73-c1b7-4872-be60-0053197e9b72	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	234f4124-6147-495d-8c73-343b542cdf98	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9e73093d-8c11-4a8f-a20f-354b0fea42ea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	13421cff-3527-41a0-a28c-b70f1a3585a0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	96ed4ac9-5cc4-44a8-ad49-86372a73425d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e72535d1-26f5-412a-ad4c-44e22dd37aa7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e5bd49ff-31a1-4af8-a96f-e559f6ab56e5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6c903dd3-55be-4942-b8d7-6acf379830f2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e7ead4bc-4a61-4bba-a2ac-ed3c2a127f53	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a5ede0df-cf02-42ea-ab96-99595da8f88a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8aa7d8ec-fc90-4515-9bb0-fa5c9b01c59c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2c9b3eca-e592-4e7b-8325-fb0e858ab64e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	53b99751-94b8-4812-bb66-a9a6184afb24	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	87420d52-ba91-4e2f-ac58-943add2a94b2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2ddb6ac6-ffc2-495a-8ad2-cde85e51805f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9b8ef6b9-fa20-478c-9c07-70d5ef7b77f4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d0e130c7-e561-4c51-804e-174c1c214acf	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0219820f-acc8-42e8-9cfc-076678845d8d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e3d3c5c9-ffb5-49f6-b5e1-28a6fd63d729	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	062db79a-115b-43e0-809b-c61cbc101d08	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	acc141d9-8527-4302-b086-286cc8b4e26d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e1f9389a-5b46-48d6-8f4d-b6acda13224c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bef50f16-48fe-43ee-b602-ce0648d60bec	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a2235068-27aa-4cdb-8186-8dc5f34b9906	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b21307d2-04bc-47ad-afbc-5f3c63516e69	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0131194a-d752-45f5-98df-aa7d4b966495	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f3feddd3-d875-41b3-88dc-45b530338100	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2511b976-6160-43e0-8fb7-f481aa7a942a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b6a8bca9-2601-48f2-a84e-6c429ad28b57	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	32931da2-7f1b-45f3-b8b6-693c85a78214	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c5f852c6-3ce8-4733-906d-0b3219038030	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	64af5f26-55bf-4344-b773-ed05b9343ddb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fcd2b07f-1bc1-40a6-980b-38e7c50271b1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3599d649-04de-456c-aff1-918b055821f2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2895206b-f2a0-46e4-9591-6496e86ee998	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	21734117-630c-41e0-9254-f6f0c413a60a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a5d09c5c-fcae-4ac0-a12d-cb25599807ee	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b9e62243-f9b8-4fdd-b1bb-505a40ea5af1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	91ba6a97-484a-4a82-adf7-75311a7e1a1c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0266701c-10e1-47d2-a950-556be5d801df	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7ea4ad92-2ff1-40b8-b71e-a22a01ce162b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d5974ebc-b20a-4380-ab81-6bd5ece9eb69	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6fe0fa7b-f293-46a7-af89-76586fb43a88	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5a117c91-85bc-4953-9c6a-e8796aa088eb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	df097ebe-254d-4429-89b7-abc8021be8b0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9c0cbd06-1385-43ff-9ab9-693e26af462c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dc3b3534-41b4-45e5-9e98-0fa92cc64014	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	414ef850-468d-4775-8f69-9d6b445515f6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	66ba4a48-7630-4ff4-8074-b22f3cd667a5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f0bbf9aa-9a56-42dc-8211-8092a0c2c4e0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	76f15e54-cbdd-435b-9674-a382aecf952d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	37359d83-d5f8-4bd3-9472-0f2faf5f04a1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	55ea4b4e-06b1-4c6a-bffe-62f11d3b8f37	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6f027480-1c78-4d9e-9968-2b25ed52d404	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c8f60ebc-38df-414b-83d8-01e551347e90	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3b80ae6b-0c62-486d-9466-d47f9f9aa61e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bcf0e340-cecf-4cdd-9931-6a530d48f6cf	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	817f3abf-8b60-4e41-ad3f-116b3491cc2f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	afabc962-6aec-41dd-b62f-15d35f06fb21	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	893a3899-6db1-439c-b6e6-b348a0ce750f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c1f84f46-fb11-4f6e-b482-8d79602426a0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b3c44503-8d14-4940-b8ff-92e12f0330d3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	613aa7b0-bff6-4274-8fb0-d055835f5b67	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e608a054-194d-4b03-bbe8-b136d4e563ff	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7599c635-56eb-4596-843d-8bb7f9e90030	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dde1f05d-951b-437f-83dd-ce3488c922aa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	366229bc-ff89-4a2b-809b-f72dcd98cd64	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	37c957c2-94f3-4a92-a99c-c070a1e3e0d1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1fb8e26f-8700-4ad6-91a5-6d670223264e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7b7c1cd5-c3d0-4e9f-9a16-277e62c997ba	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	49eb6481-e64c-4569-9118-78c24d76409b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	29ffc53c-b93d-4268-ad7c-d43449f79622	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e8187b78-17b3-4db9-bded-6969db485bb7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	02abd9e0-faf0-4ad0-9a6b-b11402fcdaec	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e12ac640-497e-4877-8911-dc8b8429499c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0fc2eeff-f6cf-4b1e-83f6-87e5590fb996	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5951879f-237e-4d16-aaf8-f7b2f91f760f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	83d6a617-bae4-46f5-9d29-c91172b29eb2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9370dc2b-11a8-40a7-b7c9-ca3c512b9969	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f1eef12a-224f-4bfc-b4c0-78f0f4365717	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7284c60f-61b8-4358-bfff-1ad0a28766cf	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7f10e653-23be-48b0-a3cb-a06e0898151b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4f11c6ed-7a00-41bf-8224-46e13b5d9bad	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d84664ce-ae82-49f5-8a53-05c9a4d7cba5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	23c50969-a410-49a0-96a5-1817ece1ba47	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cde49d8a-9c6e-4c97-9582-9b2f9af19916	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ec945b09-9169-4bd6-84b6-bf413e8df431	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	08a7eafd-46a2-47d1-a482-28f7a6d1d6ee	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1d6ce285-d577-43c6-9c72-b9fdb34ad41e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2a2274c4-9add-4720-a052-440bbf48ba4e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d5b39d10-bdfa-4982-b45c-1bbf17d55eed	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9be516cb-913e-4823-b57f-3b641577bd45	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	86bce5a8-1d56-4650-89b4-650ece7b4c2a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7cc0f634-61d1-4ab1-843b-841399c92dbd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cec60167-5fd1-4f27-9897-b722fb54534e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2583dd2f-8591-4c95-b602-372feb3e8477	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	59202f74-f468-4ec3-8819-b1c1e2739762	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e0e6b4a3-5856-40d4-a34d-4d77e3506b4d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c640d369-53ab-4b61-a818-95b60a1b58a9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b322c847-46f8-4169-ae78-162b4d5f944d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	970fbbab-5287-4b95-96cc-6e703f3fc988	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8918e044-f0c6-4981-8112-de8427367969	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f4e6500b-b196-4ab8-97c6-316000f71f2b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8378ac17-4000-477b-9a81-cb34ace6c9ba	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4853e6e1-0c01-4cd1-8321-9c769e12735d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	00080d63-f28b-493c-8e8e-f0f929f46329	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a6aeb533-db2e-4a7f-9fa6-cdd0bed5cb07	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6d214a03-6461-4b89-a2bb-5429ea0a56e7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	49cd8606-84d2-4b74-96e8-71c6a27cdade	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	88e6c1bb-025d-4320-8939-2616f71dcd07	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ec557fbd-dd4b-426f-9802-08f17e53de5b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7859bae3-2f07-49bb-9a0b-95c2f3d44fc1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2bc4a409-d6fa-4711-8ba4-d42ae723a6fc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	00db48de-8483-4b5f-8e00-e2c53a57a33a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9738a126-0112-4e48-a33e-c03f1212713c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b7c7443f-19c2-448d-9acb-82a4770f626e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	30938453-4723-4d6f-967f-4eb7366bf31f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	eb0379d6-cf5e-4138-8296-1d3d26797ce7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	abb57291-1b9e-4528-8aa8-ce1173490c6a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a69ff633-b1d9-4eef-b75c-7d4a19e53275	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1948ee1c-63f3-4172-91b7-4e3b6565f872	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1ed32704-aa8f-40cb-9575-06190a597154	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	44be4839-b13d-4441-8fce-f63d7c1134d4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	81bb7faa-3dcb-4e54-83bf-4ce7849f995e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c562c184-e015-4546-a582-0c7fffed8947	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	44c473b2-e325-4f8d-8c1c-93837945a6af	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	75ac5cce-e9c5-4544-8d5b-72c1fc3622d6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	24759246-4008-4e6a-84e1-b2abf02cbde3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d5d17649-01e6-4d2b-b7ee-2c2275226520	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d1885cc3-f822-4c3a-ade5-bea5c3116d2e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d19ae1a8-c61f-41d4-a91f-91647b934f13	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bf2b5ab6-6669-4c69-b4ab-4ec6d2f1ec98	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	80457de9-b5ff-4126-8b96-71f54746fd40	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bc09003b-7994-4375-8ded-88cd26594627	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d84d44a6-19ca-4bca-93e8-8ac6c47efe95	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a2ffd5d8-bb3f-4208-935c-119ed2595800	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d7383cfa-0340-4b30-9deb-821749cb6652	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e91e6a6f-50c1-47b1-a847-7f3c23cae68a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	101fdf4c-274d-4940-bca5-d9c946a88f35	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	45a8787d-c4fb-41b7-a638-ce30e1acaca5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dc50d5ec-e123-4df1-bdc2-e057bbad5a3a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	58b3df4f-fb0b-49cb-b63a-00a89a9d5b9a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9cb62667-ee23-4912-ba8d-ad2d934ab0d9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fb4498b2-0a0a-45ea-8a03-86e88b97ab87	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1a20d9ac-13f4-40b5-b67f-ba076f50d938	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3f46003b-7a9e-4a87-b9f7-c02dd07d733a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	69048971-72b8-4338-9e25-5b0ddfa88a12	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1087e748-6534-4806-8ddb-bd68027d9b85	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	43c438a3-4897-4dc1-87da-2d8a2c03834f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1b8eb69e-c20e-4dbb-b573-0df704fd632a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	94cb55f4-5d0f-429a-96d5-0e68d24f92aa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	44799ef4-b664-4b1a-95ea-98d49d02f8be	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	06dde5b6-4093-4058-a0d7-5867cfa26a94	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7c8e444d-6dd4-42e0-b6ae-6f8e3cf554ab	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	232afb75-423d-445b-ae5c-5f12238c0be2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3b02fa01-e1ab-4875-b96f-19216052d179	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	658eb2ce-8a38-4c61-8706-95a1e0674067	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b372ac5c-b9e0-4bad-a3cd-9e7d879a6ef1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8e2ccfcf-fe5c-4b18-b512-47956b16926f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	75eea67f-240f-429f-a401-84750e3756f2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	278dc783-e8b4-4a50-8f15-1c04780e6a71	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	febf33da-dd87-4c39-9676-71bc9e78e58d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fcfe77a6-5349-48ce-b3c7-8093730393a7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	40bc4a3c-ff77-44fa-8c5d-6ce4307a18f2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d20125ba-910a-4bfb-a3ff-5f9028f2dcd4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5f9c0a91-658f-41f0-9523-9ab2b3c58929	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	15d576f8-a39c-4ec7-bf37-f3245f1fb3dc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c84c3478-cba6-40d0-a077-759805f7fc26	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4e0310c4-82c9-493d-a714-f1b67716510b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	de92105e-2042-4e48-ad3d-c8429e70e950	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a418147a-18ea-40e4-bf1d-aa9a02ad20ec	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fafc560a-66f8-4dcb-9b34-81ec34e7485c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f1b2e6bb-e6f5-4178-9796-564cac064aeb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6c0e8343-5b19-498c-b10d-6369a1653919	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f9114ecd-4fec-4dbb-84fc-076055dc106a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7d8f033a-b8dc-4234-a758-5c401c1b69fc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	43413d05-33f5-4196-8fe8-fbeead68cc4e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	88e4530a-d048-4770-aee2-88b210e836d4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	168a10ee-0cd4-4bf6-8050-e4e011d40762	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9b458eb1-3887-4d09-aacf-0c4056f191a4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c7777459-3b55-470c-b4ba-2a923c687a38	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ed24d521-dc32-430a-babb-3b972d27ca5f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	394cc5b5-9357-4162-8fbf-18e50b88d473	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	48fc858b-c74d-4efc-a305-e347e53cce48	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a93574bc-243f-4919-a136-3c5451b3099b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	593c95f0-77e3-403b-87fb-400e608c273e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	856e33cd-3581-41cb-8d9c-44cf0528ab0b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	deb3a50e-c197-4ab9-ba23-611cc8014412	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9a658dea-e0dc-407e-b239-c322a0df7edc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d680d4a1-0deb-4555-b977-40639d3390b0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2e5479a1-797c-4d3e-96f0-5b4ac46b9092	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f1e9a303-fa8b-474b-8ce2-d33f78f79a4e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5187300b-a108-4506-b4fc-1a0e36bcc5f5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e430dd64-a3bf-4554-9d98-5e110b89d230	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	78bd3daa-4af1-44b8-8eac-0900ff7cb297	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f1e968e2-4935-43ee-b126-ae55ae053269	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e0d6837e-b854-49a6-ba15-23e29619e81c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1f093cf6-422a-41f4-afb7-0f506087c3b8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	661aa554-93d9-4580-a089-da3c188403aa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	777c9417-2f89-43dd-9176-f6e577a8579d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	37ad2ca7-9188-4af8-9d97-3d459c9b4ec6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e39ba050-965c-4cc1-a6d7-7be396bed06f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	afc7b2a7-fd2d-446a-b3b2-b2869469a55a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7b14c334-7fb1-4758-be33-6b9b02e6e5fa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4e36af96-4097-445f-bae7-fd61c42e44fc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a7f8f58a-d087-42cb-8ea6-61c3e9a07d16	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	51b1fb64-a696-4a71-b474-c5fb55fd7d06	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aa3f9c3c-649a-4056-a5eb-2ddcdfa91d0e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c92527de-ae27-46ac-93db-1c8c96a4fb41	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d5705b38-a0e0-4199-8654-e5e6393f7fa5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0a805f49-09fc-47fa-8cad-aa56c648747f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	04e45746-ec9e-4246-8c99-d307b9319a78	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f1b652f7-08ed-4f89-ba99-3c175c01f115	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0da71896-a82d-4d46-9ba5-48dd04b4f80c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ce453dba-d80e-4771-8d33-59b8341ccd0b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ea81d652-434b-48d9-80b0-631d85cf2903	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f026f048-5b29-4b4e-b95e-ff6eb7267137	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2f99d846-95d6-46d3-bed0-c7ebb9ab0d92	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6e924747-5f61-400a-96f2-d39678c53ebe	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	37652085-c739-4340-981d-06672288e823	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b30a10d4-dd01-4e0a-a5ad-a1ce9d5245f7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a9798a7a-6374-4a5c-9439-2fb10e1adcbe	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aca9a9ae-236e-43fe-b5f8-5987d4fcd819	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b5a0a8da-6a07-4b16-b206-6c502cea7ded	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b03482a2-6040-4faf-97bc-a3f7644f0835	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9a84d23e-75e1-4e32-bb7d-41d4e6a0da62	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c70305b6-2202-43ac-9fef-dfc7a57b5045	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	87532d47-b031-4c33-bd67-219740197598	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c252a2a8-afc2-4317-8726-edfae372e93c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7351a6a3-9e92-4d9c-9a42-0e0b6199c00c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c17c0424-eb48-4764-bd45-1c5ca21b0253	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	728fd516-3774-4f71-8990-d8a51606c38b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1df026cf-4519-4d1c-b857-dcb6e700254e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7e053ee0-763f-4fed-ab98-428845d7c2e2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b8b330a4-4b6c-4ee7-a59f-8947c086fe22	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	21adeaeb-4919-4a28-b04b-e661a6618016	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c3b90803-dd05-492c-8474-905bd25fe7fa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3f5a72bc-3e9d-438e-83dd-ed96959deeb8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c3f4aa2f-0cea-4705-877a-27e969a2682e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	af34ee5e-2497-4802-92f5-bdb634ae828b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d219c621-f386-4fa5-b846-cc578167286f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d85e107d-4e6b-4e82-bdd4-873b80d8e10e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d76b309b-70a1-4935-8fc3-5c609012c3e0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e4834c12-4554-4ff4-a8a4-c5a0c27a55c3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	34afc0ee-4606-459b-94dc-9c7d379105c0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5723409b-ff89-4020-bb52-da7ef3fdf75f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2812f17a-2a84-4dfd-8ecf-f70ee8cc6494	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	045d017d-449e-4fff-9d12-f2dd4bbad635	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	98622c44-196d-49a6-bd4a-4b7e4fd11666	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6aa15c55-13d7-425b-b62e-b1f99966352a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ef38764f-b3a6-4e33-9e99-7de82d4a3d69	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7a57df41-e0ec-4cca-9c94-eba4ca06fe58	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	44f3e8a4-1bcf-4be8-9eef-173178527b73	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4edb86c9-2d44-482e-94ea-7d912fb462e4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f5ff4dcc-ae10-4f4c-bd53-67793f8f37a6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9e69f6d6-1c4b-4b11-8db8-b2409cf29275	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6b51d9ea-d6f0-49aa-9815-ba2676e98129	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0c5349c3-e059-4134-a7f7-57e18ab03b86	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	33745e62-1dbc-476d-a0a0-94bb7ad26eb2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	966e484b-ed28-4914-813e-a71afc555abf	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	01b86ba9-4d13-4f27-9dfa-eca19055186b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a40248d3-6777-43a0-9169-fec2d8c294fb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	513baea3-28e8-4a36-a4e7-beb5c01b2961	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	05b369b2-d6b1-438b-8b08-c937508faeaa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fa30e46d-ad83-41d7-8475-3e4d3408879e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7e3da5e3-4a15-4293-9666-17089f7221aa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6a3efc4c-a6fe-4fb3-9ca1-c5b2cac3251e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c0bce82d-61ea-4d23-bf01-e315cf76e808	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d52b9fcc-2d1d-4284-8871-227ebdca2187	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	474cfbbb-563a-45c8-ac15-7d312796ab85	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e02eb922-9b43-4c78-9c95-23670fabb2db	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	72624182-b481-4779-a41e-b80fa310eb84	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	de37755f-72dd-412d-b342-3e1f3c46e62c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9a090c49-615e-4189-81b7-c68f70588a9a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c3d67379-0ead-42e1-9357-f7bd07869a9e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6def9c3f-c2ac-47e6-be24-270767260bf1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2f8f36f4-6755-47ce-8139-f82e5bf6ab1c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	97ed19db-ed13-4a4f-8d35-205f3d5f1930	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7d5c46e7-f828-474f-8c29-7253136d9871	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7d5ab67c-98b5-42c0-8d14-9e7bf4451014	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4e074869-df5c-4e30-a7cc-dfb680eff1fa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	271b281b-57c5-4631-b187-4a46a85bea6f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	49c143fd-ba12-4367-99e9-fb9b93d16eeb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	df22e30d-4ed2-452f-99bc-cbcdb74e9b82	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ffac61a9-9ac7-4611-b41b-e90cdee8d0db	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a549fb54-39e3-453c-a2b8-be2bf032d196	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	45818393-8aa1-4b91-911a-1afe36d94aa2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dbcfb335-82a9-4afa-859c-71ba034cd839	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fe78983e-74c6-4ebe-86a3-00711dc74175	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	84e88b19-7ea3-4c83-9ae4-b595f42642dc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a859a422-34b9-4702-a7a4-7d06900efaa8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	69d56e64-d6ce-4cf5-b5a8-b5168cc94d74	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e74d0bed-1796-45ec-b90b-139bfe02c93a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a5f015f2-7036-4da0-94f6-a54894f3806f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	13383d43-a6de-4bce-845f-1d53202c5bc1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3e3d4592-c126-4c82-a08e-d792d44cb6c5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	abb116ab-5ae5-4b95-a76d-69f84ef60531	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b3dada46-c85a-4345-9057-569872c36b76	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6e9ef4e4-091a-49f5-ae34-4516d56fa2d1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	faf3128f-d3c6-406e-9dc3-416d8479a9b5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e84e5bc7-1c4c-4d85-9361-fc23da95ceef	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2be70162-7bb7-4d80-a364-b0b21811f6c8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3b9dd14c-fb41-4491-9fc8-2d8576a5c67c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7bf2906e-3608-4419-ba2d-9260dccff270	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	34cc6d5a-d1c6-469c-bde7-6258b4a4c5da	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4eca7254-449f-4597-9df7-57ffec2c690e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cde99b41-2a0d-4f1d-9c45-975637fdae58	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f9856349-66de-44e4-a348-5726f6ad4677	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d9dab3aa-56f9-4842-b667-8d7b5c9d3e02	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3b5154ff-87a4-4e59-9c15-d25e04d341a1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	208b623d-85b5-4324-91e4-03b4417b7f26	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	029132a4-e1dc-4e69-8b6c-b0a4455a00e4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7e292473-2e5d-4234-acf5-b8683e7ff051	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b95075d7-960e-4ab8-adf1-d51900deecc5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7be81cc9-8dd7-4ae5-a8e7-5e094c69b4c6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bedb1e39-a308-490a-ba73-c1507ea219c2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ac116969-5777-401b-a20b-35cd1fe1926c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	48491ed0-e0d3-40dc-b7d9-8534da3dee34	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f09cf8d8-23da-4e62-ae56-61b34820de41	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cef380ce-868f-4537-bc5f-73b390a16702	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	33cfc4df-dd51-4c7b-8b1a-7c15cbb4f7d2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	88263dff-3e83-4a75-9d01-e692c0404a3d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ca683d73-c1d0-4e45-b118-f52a71957d1b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	73e091f3-f678-4548-b7d5-370e4b486655	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ba586539-40b3-413d-9660-7ded48037558	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	79f587ea-df95-4b8a-9831-b0de393ce226	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8a29f576-8679-4d49-ad38-f49468049c59	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f052a97d-8f42-4ef2-bd0a-8c1647fcd040	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	303229b7-b86f-4df8-a02d-d197b4cf0484	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f354b4ef-f930-425c-9f35-8bcef8ba8d4d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	82af438f-777f-4c00-bdf1-53b2aeb289e7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	81d3c9b2-9279-4528-a61b-e4c39522c5c4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ca97156c-f828-42cb-a36c-a83bd2147360	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	219e704e-8616-401b-aabd-dd48d3b13a6b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bdd7cae3-e309-480d-ba9b-1602e16dac04	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fd02f665-2a01-4829-ba04-ca3e7c9de378	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	533497ec-ea83-4f69-b0c7-fba74522f8a7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4f264a35-cfb0-4c52-889a-44590b9b8b8d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	369009df-a3d0-4990-b50d-f0b02af5efd8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cd89f3d7-6ec0-45e7-871f-e62097d491ea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	74b1a124-6b6f-4890-8e6f-b3a082a6780e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8ca422bd-ed92-41be-aa9d-16476426670c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	303bc82d-6530-4fdb-bcf1-37ae7c1fea83	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	411369a8-67dd-4438-88d9-d41a9c4dc5a6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c58700ee-14a5-476c-9a26-7a2e66421ce1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1130f587-8c1d-4f85-822c-119811a2aa61	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f66cc7ec-ecc9-43a7-8f65-6008e4aedb9c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ed034c2b-a527-450e-9268-7d4288a83a50	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	50e08104-c1ee-4229-8429-5101c39b6d79	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8a011a76-e565-459f-ad16-d1e1b261828b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a78504eb-35d5-4358-b063-384b5167979b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c9ca55ff-7006-4bb7-9b7c-c16d1de70405	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	267b9164-aab8-41cf-945f-62354f22bd10	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fc7d6711-4c02-4d31-bb23-196ee3ece6cd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a3e49191-3e1a-4d06-bfa8-eb947a17df9b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1a27610c-e0c6-4fee-9d25-892bb6f4fe10	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2f229a24-baf5-451f-931d-17429fdbcf10	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	519985a7-4bd4-42f6-8035-c89821184328	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	120c66ee-5a1a-45a0-ae9b-0b6616f2b600	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	65376494-25fb-4a72-b02f-0ee381a9988f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cef7d121-7d38-4acd-90f7-596f2eef92f7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8417286d-3d11-452e-a91f-d5fad61b3b16	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5984b868-a5eb-4bba-b6c7-37782c657feb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dc29e592-994c-411c-b42b-b186a5191a17	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	57e887ca-e62a-4666-9395-1af50fc20e33	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dc14fba4-c712-4136-8e76-89b7d7cf9018	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	43f9c115-2ea5-4023-9c8b-46a0e414afb0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4bbb1f4d-3ab1-4f59-a1d7-a41e613e4433	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fd807b2f-5696-4918-a37c-1f8b279f8539	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	13effc0b-81d0-48b4-9c9a-ed2995bd9130	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	21dee80e-d8dc-4409-9372-c60dc1e71cd8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8143ea35-c604-499b-b7a0-a8b8f2e8fd28	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6623accd-dab6-4e3b-a046-d6d94043c3a1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	13658522-b5dc-48f2-8f2a-d7e0debfb19e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a051effe-6568-4ffb-8d80-fa27f462fa19	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8d4dff04-6c17-4796-a7ad-ca556089b374	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9e1e67ee-c0bf-4709-853f-b4c202d4ae01	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a9fcb6aa-3ce8-48ab-a0ea-4c2dd49ffb17	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8469a43b-4c95-44aa-b423-f2c21ea7ac63	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4a8e0cee-b789-4605-8078-f7f833f62e93	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c4c06366-0137-4e4d-bbc4-9c36159df749	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2f2e9393-e4d5-4036-9552-403e66a084c3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aaa2e854-33fd-4132-80d9-11c2e17b5d66	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1a04ca8f-5d4b-48d0-892e-2f4434a2d723	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	656641f6-f723-48ff-b4b0-0d72cac5e1fc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d9ed67f8-d69e-441c-840f-752a6b40bd26	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	685bb93d-1594-4d64-8df3-9ab74108b1dc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d49d9373-ed87-4bbe-8379-fbf55d658832	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ddae4668-cc94-4612-b91d-f91c2060a0bb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	24490971-d0b7-492c-a1c5-942be9b7449b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	addc323d-1303-4ac8-8708-e0b0264a7469	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	016536cd-2144-48fb-a420-18802aff14a4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	df9c7ab0-a0fa-4cf1-b8bd-f46f19121074	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bf5c9fd8-7a08-4e1a-8838-bc69ea3271d9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	67003d99-42ed-4b8c-8999-d85802d0e285	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	794fb74b-0a23-40de-b6f7-13d88c33f55d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	62f418c6-0e01-4f6c-995e-a97da16c11a1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2b19edd6-4c3a-4921-bbc3-24ef8204d606	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	03ec1cea-a4f6-4c00-bb0b-17adaaed14fa	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bef93b63-4a75-4f51-bcc8-a8d343e25fb7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6e961f90-c999-4b5e-93cc-2755f2023f10	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a6d65792-cb28-468b-b386-f507bfa6bc8e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f07328f9-3da8-4478-b74b-70837fdf5abc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b684edce-c6f8-426a-a929-b5d367d7e8d7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	773bdd1d-9a8f-4a83-affb-3c692d6540bd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4c96467d-f886-443a-a248-affa29a7ae19	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	69001fe1-feb3-4341-b0d9-a268b6da6904	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	44e82e3b-4314-406a-b3e1-cc47742da6ee	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3bf67112-270f-493b-b325-fff48a5a9229	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ba3440b7-756f-4128-8968-5dbc298d3a2a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	392abfe3-e8ce-44f9-ba6d-41000d49e3bb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9dc03863-f1bb-4302-b822-a3c8f831b46a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1c4d487a-c653-4b38-9434-1d1d8db8d74c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a39ae325-13b9-4f48-bc54-fd126d4712bd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6bf564bd-2b91-49d6-9365-9b2045af8e8f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	addafe6b-3ed0-4203-a3d1-f49786234367	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c64d3bae-9693-48f3-bb39-1ac8cb1f3fdd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	44be5995-4db6-4193-baee-dec6a9b50e91	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e4ace075-d690-42e8-8430-01a8fa9e13ae	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	94d7636a-6ba0-4498-8dc1-59aebc2010b5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	54006b5a-2ac1-4ab7-95c5-36f43d5d6d7c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	66981a07-954c-4511-83d2-bd6a3e377c39	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	92e9fbf3-c400-4030-b9a4-34c29ebb67dd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7fa6c91c-708d-434a-b58a-2579eaaa6856	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	91af3b5b-d16e-4054-9b31-6b278102778b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0b4ab5d7-8212-45a3-8659-c1c868e2a8df	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e78e5683-e3db-4078-b32c-b6982f436bac	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	20885dd4-e791-40ea-9f9b-4571dd959b83	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cab775e1-2108-4a21-84f6-c37c4e25c4b5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cf1f7b7e-1ea7-4b2b-bfa3-9c26945c42ba	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6946f7c8-a78c-415f-9bde-fe58f20aae42	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e31feacc-4a30-490f-b173-375ead7b2fb3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ae101460-ef29-4327-8c77-18b4bd109320	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6b9f15b6-1c00-429f-9c54-e192facd59e6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	573ad993-551d-443d-954a-20e44767d5cf	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bbc4dcd7-99c0-4148-8915-e06fc6cbc833	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	eabbf099-1303-4434-9bca-17652fa22ca1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d3d4b9d3-2140-4d76-bb32-bce236bd4f0c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	23c6f3bd-dd65-42b3-b57a-c485c70558c2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6f79971c-b230-4a92-ba13-69188108309c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	47923145-e4be-4350-ac74-8cfe890533b2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	24632f0f-ce01-4386-bb3e-2eccb5bcc920	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	67dfc397-b2c5-49cd-b7da-8d8bbc5122eb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	15390d64-f3c0-4127-b008-ea0f1a2bf690	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c41cfb69-6e61-41da-8650-81d3dc4e1fa8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	223105d7-e76b-43ae-9524-0e02ac5a1ac3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6d7a4023-6492-45a1-a8b4-9682b52126d8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9c8c8b63-6f88-461a-a172-dee0ac14cc51	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8d98bc0f-fa2a-40c9-9116-a41b7b08c66c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	88c6b68f-0c2b-4a68-8a48-8672efe0a013	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1cc56556-0648-462c-9730-5686c0264e66	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3ecb2792-67fa-4734-977d-c3b40ad5d05a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	64dafa81-85df-4596-9061-9557146b7382	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	86a4d0cc-cfe9-406a-b80c-e1850f264de3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fbd5c768-6d9f-434c-9ff4-d98bb80277ab	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a7e632e5-fe29-48f8-aea5-67fbb2ef7369	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8a68c851-2105-4a36-bf67-0eab421b8582	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fd2560b3-6d67-4522-a0c9-4f5edd895df5	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	39f25038-14d2-4123-824e-fc20fe6b22f4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5b118c55-e72b-4dbb-9aba-8e716e08a6f7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4f18c700-e7a0-4547-9232-a280ed8c2df4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	647b6492-8b28-4989-85bb-df7223821bcc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9cafeb0e-5448-4467-a62d-742dad34cedb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b370ebcc-ce80-4528-9bfa-2b387bf6ccee	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bf5c2543-ddf2-4d0f-a7e7-cba992ec3127	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f3fbad59-003b-4dfa-80d5-f73a0f708650	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	383db516-cca1-486f-9bd1-7550cea844a7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	707b0352-6829-4f0e-8609-66b370c98a17	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b7d05e03-a561-4d67-8168-90ab4b1cf04a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0d971516-47cf-4ca6-ad37-2a8724a2dfe8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	48a2f41e-3f20-4db9-a75c-2b71971b1f2c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	89f6fe83-a512-4c96-b256-f4f956ea0c08	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3dea6223-95dc-4a61-9d64-d2551968590d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	30a979bd-a09e-482e-b51d-8bd2763e449a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f0f59552-3199-4dac-8b6d-6df0b32e6a9e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7f0ddcea-c48e-4747-af7c-ad08517c247e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0d77d1a7-c5f6-48b1-94dd-e987285c537d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bbfc592d-499c-4483-81da-a0c5ae958063	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4b583b8b-e9d8-4b4d-ae49-402c1b14e569	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5fd9bd0b-5d5d-4bc1-a245-6d8f2217215e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	69505033-3cc0-40db-a954-afe956723692	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1875af07-a87a-4ddf-907c-de3e12d9b434	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	46763a8a-2429-4510-a825-2f8a0b7c9908	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	36bd5c40-d171-42b1-affc-0516465d37ee	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b7923c83-4e59-47ea-b96d-3a67d3ac923e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	70b849cd-5cc4-419c-b14d-5c256dfe7a7d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7badcf9a-2b27-4b35-9c17-6aaddd9eed8f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c96f19df-d062-408d-b5fd-05fa72cb465e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ddeaad4e-f897-4226-8364-46af22178aab	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	42010586-8561-4fce-83a4-863e637a6d9c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	33952e42-e03d-4b19-91a2-0d953fe6e1ba	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4f917038-fc9c-4c90-94e1-250df4bda5b2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	42391cd3-3470-4978-8e11-1bac98bcd0a8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6c391362-1d63-4cc4-94d0-96bfac0849a8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8147ed19-ba6b-4bb1-9d49-160bb1e9e2b3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4b0fcf9f-0416-419a-9861-b20b5c7153e3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	dc7c3a71-fb90-426b-9703-4404f58c01b0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3b664429-cf41-4e2e-9e7a-46c95110c6b4	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	279f9b8a-1713-4a00-bda1-34fb4cb27226	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	88de0358-05fe-4c33-9bb6-300af3cfd748	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	84313eef-a7a7-4306-8afd-9c95673a1d8f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4e3e7c14-1079-42cf-ac2d-b66f531cfbed	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e3f9406e-9950-4ecc-b6a5-fb64b10fc677	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	54a55151-62a6-4c46-bc65-7a863f051b10	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	551f3b81-7e55-409a-af7e-4f51816229a8	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	9fc43219-edbe-4479-8a2b-8462bb644459	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	611bd0d1-e9ae-471f-bc7e-ffa776ee3fcd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4e77bd6b-8e16-4a7d-9875-4afb75c46c8b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1eb391c1-df41-4f4e-b8f6-489bf1c65626	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4416b533-7f9b-4c0a-8fa8-daf56d407a90	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a870eef4-cb4a-4870-b330-1d78f1956c05	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2c624c3e-59d9-43e2-92a0-994ba529f25a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	48c9ec2c-ba09-4f1e-980f-6434bc4bf30a	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4a5a6390-6630-47ad-b5b1-ae88037dc587	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3202458d-597a-4eb8-b9a2-29b98aa25b6f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7d8ddd4e-5c73-4ae8-ab3c-215d18a0d4fd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3fcd6460-d9f1-4496-804f-14597ff7620e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f20b3f2e-e6cf-4e69-ada7-ecf24915ec1e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b78d6f35-ee92-4831-8283-3fc3eed905d1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bd24cb01-82c5-4851-9f7c-d1319dd2effd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	379fd337-d4f4-4bb0-ad9a-dbe2268edacb	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f36b5cdc-cca4-4115-9960-a4a8abe5c98d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ea8b4868-7bbf-44ac-9e79-977f9c5fb5b9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	91c54e37-7f62-4822-b194-28ca25f55062	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a2a9ea71-0d6d-4452-aa83-aa55f41f20c3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8e9531b5-f234-468f-9a25-5a8860701109	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ec93d7ff-3b95-46de-b8a9-512cdd524861	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	04f106e2-2975-42ac-a144-b62a0ae5738d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	aad113ba-a3ae-43cb-adec-2afe23519e7d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bd3288fb-2960-4be5-8776-dbc02cb9ccb1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	188474c2-34e8-48ae-87ab-fcab345b9b95	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	907d69eb-3590-45be-a28e-b391718c6e56	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	33b6bfb7-6c9f-4e4d-a756-4f1e86587c6d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	fee722ff-21b6-4f65-87fe-d67e7e9d2576	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	72c5e40b-997c-4c27-a210-7397eef54dd9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	07f1cbac-a321-4bc0-b6f4-fdf803fd57ae	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2e94c2e2-6bf2-4c3a-a839-77f4e17e3070	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	37e6e627-364c-4bd5-af58-6bdca0b8a847	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5d267a0a-ce17-4427-a02e-0356cac077e0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	81286431-6731-45e0-b874-4cf1bc1caf0c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	24eec346-bc4b-4387-ac07-b3f6c7e596ee	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ceaf56cc-bbbd-459f-9cbb-3a1e77b0bde3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7ee28d50-4c03-4515-9d91-3eb71d4eba53	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ee6c4fa8-797b-4ed0-b6d2-7f78d2fada20	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a8a2fe5f-7a86-4010-878f-187b93a22442	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4f349891-bdbf-4941-941d-08b4c40ab301	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3edb7f96-bb99-464d-a749-7676069ef2c6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e052f81b-07dd-46fd-ac73-f638214ecba1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	136000bf-b5c3-426c-80aa-bed1cd06b968	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	34c08f35-a24b-4235-813e-67b2c4bdf494	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	32c39d9e-b7fb-4923-b064-c64b41e43276	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8e4e60b4-66de-4373-87e6-00ebb5ba47fe	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	64dc19d2-3c93-497f-ae14-38c0d1bcb94b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	0c751837-3a89-4398-8cca-be3ec545f3e7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f1367393-cb31-4103-8177-7fb79d1d5567	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e5570395-9bf2-48e3-bdaa-1caa8810b4c2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bbe66186-90df-4c43-88f8-54ce32dfd20d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c8402f97-7599-4c34-bc17-144b4518324c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	74a37ede-defc-483a-913d-3e0f762cae04	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	941413ed-8ca1-48b9-84e9-8bb1395cdb1d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b9e23e2b-ed1f-4834-a7c9-bfa25ff84cfc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2bfb8102-c606-4931-915f-7e7bbbcffaf3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5c73c8c9-23f0-4930-9a01-ba45778b655b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b7fb70ce-b504-46e5-9e97-23034498d018	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d940bc3a-36de-447f-8d42-3ee20e6ec6e9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7f0e8e33-a778-49ea-9154-41ca1b615438	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	6e2cf085-c106-4cb2-b1a4-50372588f9a0	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	99335c7e-5f9b-48c0-83d0-281c7547cbea	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	00fdeef7-9fbc-48dc-9821-77c1939b82a2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7da73fc8-601a-442b-93c7-5821ab844ff7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	c832dbf0-2d98-4259-8f4d-f560222e26bc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2742d55e-6096-4249-b354-9c6b34c7f7b9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4d1b3ec6-1d98-41cd-be4a-f88717fe6e2b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	3ea53436-19c1-442c-ae10-8b1b28eeea7e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5618c32a-d553-454c-a55e-b4b848951dae	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	54043311-7447-437f-8a99-1e9aee3a4a27	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	04c882bf-8f86-44a6-9b57-59b10386726f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	34790df1-fe58-4615-b425-1ce281aa65e1	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f144910d-6781-402f-b059-1da7e7b6b4cc	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	04917cb1-bb3f-45cb-a481-23a8eabc9254	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	af129ae9-e34e-467a-a475-0f21870ae0bd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	7f89b056-b99f-4de5-9c12-1d5866400326	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2512cfea-743c-4d9c-9b8d-ea0550b480be	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ebe63d56-486f-452b-b6de-b161daaafb39	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	07a960b5-eff6-4215-b520-b5f2454ed483	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	1491b26c-12ec-45b3-b244-445c3f853464	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	07517026-bf6b-4671-80fc-90db2b4a2dce	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	2f57c955-7b0a-4a22-8ec0-c7e0ccc9c841	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	60ccc8c2-67b7-4443-8c4d-e90bbceaa71f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a4a41368-eb60-4ddc-b84f-19cec451b993	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	987b8b58-51f3-4b1f-899d-d8d3542ee47c	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	8332357a-92e5-4805-add4-24f6b031ca46	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	220b0863-9c3e-4d57-b330-78c686c01bbd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	630ded6e-28aa-4b53-a06c-050856caef54	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bc6b1dbf-952e-45cc-a580-4c0dc21c4552	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4a2625b0-e28a-4fab-8a2d-188692d5823e	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	65a587c5-cf86-4c75-919a-6e2f440bba9f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a0d1ee67-68ca-4f4e-a975-b5ed68dca124	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d060d262-07c5-4ee5-813c-142129947bcf	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	66376c2e-4e25-4fc0-aa85-3a6b35e484d3	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ffc788e8-e52b-4ba7-a09d-c0c77317037d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bae8d530-1aed-4f95-b848-e3c44a7ded53	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	bd706b57-6a9e-4361-91c1-63725487d64b	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	763a0958-a245-4179-b189-02ac2c35c2af	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4b6809f7-cbea-4d04-ba42-deaa93770f00	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	4f73d3e8-aa9b-4387-9984-1794868d3fd6	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	ab0da67e-00fe-436c-8af9-de46cc06ef12	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	cf56b722-e4eb-4117-a9ca-d508206facfd	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	81568d56-098a-40b9-9429-97e34b23c278	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	b070a76b-0fbb-44d6-8b9d-5711b3ebd398	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	d0306a25-e4a9-4929-a26c-0498738a74b9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	857a18c7-52e1-4cd3-b9b9-6dc0088bf851	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	e14621c2-64f7-4587-a4f1-bd7b5b47f7e2	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	a9f6b4e6-822b-4b84-851b-a1ffbab3e43f	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	76412a45-a330-4c5d-b980-00eaa4b744a7	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	90e092fa-d69e-4fd6-b2f4-2b1cf2d8a262	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	52703bec-08bc-4ee3-a4f9-682ae741bbf9	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f6027850-7b35-4850-bfd0-b15c19174919	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	f6ce6958-2b21-44aa-bb96-39554ec81604	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	72dc2e76-a39e-406c-8bbc-1559ab645585	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	141b5492-281b-42d2-be27-f8ad5b181a63	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	28a3edea-437f-4365-975a-156ac8a73f8d	2026-11-08 08:26:50.347723+08
0c000000-0000-4000-8000-000000000001	5c5e6265-5a8b-46e8-9bba-15787b9eab28	2026-11-08 08:26:50.347723+08
\.


--
-- Data for Name: core_tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_tenants (id, name, code, tenant_type, plan, license_type, license_expires_at, database_host, database_port, database_name, quota_users, quota_storage_gb, quota_api_calls, quota_plugins, features, status, trial_expires_at, created_at, updated_at, activated_at, suspended_at, deleted_at, tenant_id) FROM stdin;
00000000-0000-0000-0000-000000000001	默认租户	default	shared	basic	subscription	\N	\N	5432	\N	20	10	100000	\N	{}	active	\N	2026-10-26 14:03:20.522714+08	2026-10-26 14:03:20.522714+08	\N	\N	\N	\N
\.


--
-- PostgreSQL database dump complete
--


